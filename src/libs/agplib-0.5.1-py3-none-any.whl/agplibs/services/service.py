import schedule
import logging
import time
from datetime import datetime
import sys
import base64
from agplibs.services.interfaces.i_service import IService, IJob
from agplibs.clients.dorm import DormApiClient


class ServiceStatus:

    SUCESS = "SUCESS"
    FAILED = "FAILED"
    PENDING = "PENDING"

class ServiceSuper(IService,  IJob):

    SERVICE_LOG_FILE = "service.log"
    LOG_FORMAT = 'utf8'

    def __init__(self, name):
        self.name = name
        self.__is_running = False
        self._init_file_logger(".", name)

    def _init_file_logger(self, path, name) -> None:
        logging.basicConfig(level=logging.DEBUG)

        extra = {'s_name':name}

        logger = logging.getLogger(name)
        syslog = logging.FileHandler(filename=ServiceSuper.SERVICE_LOG_FILE)

        formatter = logging.Formatter('%(asctime)s %(s_name)s : %(message)s')
        syslog.setFormatter(formatter)
        logger.setLevel(logging.DEBUG)
        logger.addHandler(syslog)

        self.file_logger = logging.LoggerAdapter(logger, extra)


    def __clear_log_file(self):
        with (open(file=ServiceSuper.SERVICE_LOG_FILE, mode="r+")) as f:
            f.truncate(0)


    def event_start(self, dorm : DormApiClient, date :  datetime ):
        dorm.endpoint("services").put(self.name,
        {
            "name" : self.name,
            "start_date" :  date.strftime("%Y-%m-%dT%H:%M:%S")
        })

    def event_end(self, dorm : DormApiClient, date :datetime):
        dorm.endpoint("services").put(self.name,
        {
            "name" : self.name,
            "end_date" :  date.strftime("%Y-%m-%dT%H:%M:%S")
        })


    def event_status(self, dorm :  DormApiClient, status :str):
        dorm.endpoint("services").put(self.name,
        {
            "name" : self.name,
            "status" : status
        })
        

    def send_log(self, dorm : DormApiClient, clear_file=False):
        
        dorm.endpoint(f"{self.name}/logs").post_file({
               "file" : (f"{self.name}_{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}.txt", open(file=ServiceSuper.SERVICE_LOG_FILE, mode="rb"), 'form-data')
        })

        if(clear_file):
            self.__clear_log_file()


    def job(self):
        """ A virtual implementation of the job method"""
        pass

    def exec(self):
        pass


    def get_is_running(self) -> bool :
        return self.__is_running

    def set_is_running(self, is_running : bool):
        self.__is_running = is_running

    