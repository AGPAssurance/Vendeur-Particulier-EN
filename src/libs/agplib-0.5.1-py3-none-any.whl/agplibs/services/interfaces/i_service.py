import abc


class IJob(metaclass=abc.ABCMeta):
    """ An interface to define a job"""

    @classmethod
    def __subclasshook__(cls, subclass):
        return (hasattr(subclass, 'job') and 
                callable(subclass.job)  or 
                NotImplemented)  


    @abc.abstractmethod
    def job(self):
        """Define a job method"""
        raise NotImplementedError




class IService(metaclass=abc.ABCMeta):
    
    """ An interface to define a service"""

    @classmethod
    def __subclasshook__(cls, subclass):
        return (hasattr(subclass, 'exec') and 
                callable(subclass.exec)  and

                hasattr(subclass, 'get_is_running') and 
                callable(subclass.get_is_running)  and

                hasattr(subclass, 'set_is_running') and 
                callable(subclass.set_is_running)  
                
                or NotImplemented)   

    @abc.abstractmethod
    def exec(self):
        """Define an exec method"""
        raise NotImplementedError

    @abc.abstractmethod
    def get_is_running(self) -> bool :
        """Define an get_is_running method"""
        raise NotImplementedError

    @abc.abstractmethod
    def set_is_running(self, is_running : bool):
        """Define anset_is_running method"""
        raise NotImplementedError





class ILogContainer(metaclass=abc.ABCMeta):
    
    """ An interface to define a logger"""

    @classmethod
    def __subclasshook__(cls, subclass):
        return (hasattr(subclass, 'log') and 
                callable(subclass.log)  and
                
                hasattr(subclass, 'get_logs') and 
                callable(subclass.log)  and

                hasattr(subclass, 'write_to_file') and 
                callable(subclass.log)  and 

                hasattr(subclass, 'clear') and 
                callable(subclass.log)  

                or 
                NotImplemented)


    @abc.abstractclassmethod
    def write_to_file(self):
        raise NotImplementedError

    def clear(self):
        raise NotImplementedError

    @abc.abstractmethod
    def get_logs(self, msg : str):
        """Define a log method"""
        raise NotImplementedError

    @abc.abstractmethod
    def log(self, msg : str):
        """Define a log method"""
        raise NotImplementedError



        
