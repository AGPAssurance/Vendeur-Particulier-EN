import falcon
from wsgiref.simple_server import make_server
from agplibs.services.interfaces.i_api import IServiceApi
from agplibs.services.interfaces.i_service import IService
import threading
from datetime import datetime
import json
import os
import pathlib

import markdown

class APISuper:

    __service = None
    __service_thread  = None
    __app = None



    class Doc(object):
        """ A Doc class ressources """
        def on_get(self, req, resp): 
             resp.status = falcon.HTTP_200
             resp.content_type = 'text/html'
             
             print(pathlib.Path().resolve())

             with open('../README.md', 'r', encoding="utf-8") as f:
                 text = f.read()
                 html = markdown.markdown(text)

                 html = "<head> <meta charset='UTF-8'> </head>" + html

                 resp.body = html


    class Log(object):

        __service_name = None

        def __init__(self, name : str):
            self.__service_name = name

        """ A log class ressources """
        def on_get(self, req, resp): 
            resp.status = falcon.HTTP_200
            resp.content_type = 'text/html'

            
            
            with open("./statics/logs/logs.html", 'r') as f:
                template = f.read()
                
                template = template.format(service_name=self.__service_name)
                
                resp.body = template

        class Script(object):

            """ A log class ressources """
            def on_get(self, req, resp): 
                resp.status = falcon.HTTP_200
                resp.content_type = 'text/javascript'
                
                with open("./statics/logs/scripts.js", 'r') as f:
                    resp.body = f.read()

        class Ajax(object):
            def __init__(self,path):
                self.path = path

            """ A log class ressources """
            def on_get(self, req, resp): 
                resp.status = falcon.HTTP_200

                data = []
                with(open(file=self.path)) as f:
                    
                    data =  f.readlines()

                
                body = data
                
                resp.body = json.dumps(body)

        class Style(object):
            """ A log class ressources """
            def on_get(self, req, resp): 
                resp.status = falcon.HTTP_200                
                resp.content_type = 'text/css'
                
                with open("./statics/logs/style.css", 'r') as f:
                    resp.body = f.read()



    def __init__(self, service : IService): 
        
        self.set_service(service)
        
        #Do at the end
        self.set_server()
 


    def set_server(self): 
        app = falcon.App()
        
        app.add_route('/', APISuper.Doc())
        app.add_route('/logs', APISuper.Log(self.__service.name))
        app.add_route('/ajax/logs', APISuper.Log.Ajax(f"./service.log"))
        app.add_route('/scripts.js', APISuper.Log.Script())
        app.add_route('/style.css', APISuper.Log.Style())
        
        self.__app = app

            
        with make_server('', 80, app) as httpd:
            # Serve until process is killed
            httpd.serve_forever()
        

    def set_service(self, service):
        self.__service = service
        self.__service_thread = threading.Thread(target=self.__service.exec)
        self.__service_thread.daemon = True

        self.start_service()
        self.__service_thread.start()


    def start_service(self):
        self.__service.set_is_running(True)
       
        
    def stop_service(self):
        self.__service.set_is_running(False)




