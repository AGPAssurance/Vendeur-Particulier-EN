import sys 
import subprocess


class DockerManager:
    
    def build_tag(self):
        
        return 'docker build -t '
    
    def image_name(self):
                
        return input("""Enter your image name: """)
    
    def image_tag(self):
        
        tag_choice = input("""
                        A: Git SHA-1
                        B: Custom Tag

                        Enter your choice for image tag: """)
        
        if tag_choice == "A" or tag_choice =="a":
            
            git_command_sha = 'git rev-parse HEAD'
            process = subprocess.Popen(git_command_sha.split(), stdout=subprocess.PIPE)
            output, error = process.communicate()
            
            return (f':{output.decode("utf-8")}')
        
        if tag_choice == "B" or tag_choice =="b":
                
            return (':' + input("""Enter your image tag: """))


class LightsailManager:
     
    def push_image(self):
        
        return 'aws lightsail push-container-image '
    
    def container_region(self):
        
        region_choice = input("""
                        A: us-east-1
                        B: us-east-2
                        
                        Choose your container region: """)
        
        if region_choice == "A" or region_choice =="a":
            
            return '--region us-east-1 '
        
        if region_choice == "B" or region_choice =="b":
            
            return '--region us-east-2 '
        
    def container_name(self):
                
        return ('--service-name ' + input("""Enter your lightsail container name: """) + ' ')
    
    def label(self, name):
        
        return ('--label ' + f'{name} ')
    
    def image(self, name, tag):
        
        return ('--image ' + name + tag)
  
    def create_container(self):
        
        return 'aws lightsail create-container-service '
        
    def power(self):
        
        power_choice = input("""
                        A: Nano [7$ USD] (512 MB RAM, 0.25 vCPUs)
                        B: Micro [10$ USD] (1 GB RAM, 0.25 vCPUs)
                        C: Small [15$ USD] (1 GB RAM, 0.5 vCPUs)

                        Enter your power choice: """)
        
        if power_choice == "A" or power_choice =="a":
        
            return ('--power nano ')
        
        if power_choice == "B" or power_choice =="b":
            
            return ('--power micro ')
        
        if power_choice == "C" or power_choice =="c":
            
            return ('--power small ')
  
    def scale(self):
        
        power_choice = input("""
                        A: 1 (default)
                        B: 2 
                        C: 3 

                        Enter your scale choice: """)
        
        if power_choice == "A" or power_choice =="a":
        
            return ('--scale 1 ')
        
        if power_choice == "B" or power_choice =="b":
            
            return ('--scale 2 ')
        
        if power_choice == "C" or power_choice =="c":
            
            return ('--scale 3 ')
  
    def container_list(self):
        
        return 'aws lightsail get-container-services '
    
    def delete_container(self):
        
        return 'aws lightsail delete-container-service '
  
 
class CLI:
    
    def __init__(self):
        
        self.docker_manager = DockerManager()
        self.lightsail_manager = LightsailManager()
        

    def menu(self):
        print("\n************ Lightsail AGP CLI **************\n")

        choice = input("""
                        A: Create a Docker Image and Push
                        B: Create a Container, Docker Image and Push
                        C: Create Docker Image
                        D: List All Running Containers
                        E: Delete Container
                        Q: Quit

                        Enter your choice: """)

        ## Create a Docker Image and Push
        if choice == "A" or choice =="a":
            
            docker_param = input("""
                        A: Create a Docker Image with Tag

                        Enter your choice: """)
            
            if docker_param == "A" or docker_param =="a":
                
                ### * Create Docker build image
                docker_command = self.docker_manager.build_tag()
                image_name = self.docker_manager.image_name()
                image_tag = self.docker_manager.image_tag()
                create_image = docker_command + image_name + image_tag + ' .'
                print(create_image)
                
                process = subprocess.Popen(create_image.split(), stdout=subprocess.PIPE)
                output, error = process.communicate()
                
                ### * Push Image
                lightsail_command = self.lightsail_manager.push_image()
                region = self.lightsail_manager.container_region()
                container_name = self.lightsail_manager.container_name()
                label = self.lightsail_manager.label(image_name)
                image = self.lightsail_manager.image(image_name, image_tag)
                push = lightsail_command + region + container_name + label + image
                print(push)
                
                process = subprocess.Popen(push.split(), stdout=subprocess.PIPE)
                output, error = process.communicate()

        ## Create a Container, Docker Image and Push
        elif choice == "B" or choice =="b":
            
            ### * Create Container
            container = self.lightsail_manager.create_container()
            container_name = self.lightsail_manager.container_name()
            container_power = self.lightsail_manager.power()
            container_scale = self.lightsail_manager.scale()
            create_container_command = container + container_name + container_power + container_scale
            print(create_container_command)
            
            process = subprocess.Popen(create_container_command.split(), stdout=subprocess.PIPE)
            output, error = process.communicate()
            
            ### * Create Docker build image
            docker_command = self.docker_manager.build_tag()
            image_name = self.docker_manager.image_name()
            image_tag = self.docker_manager.image_tag()
            create_image = docker_command + image_name + image_tag + ' .'
            print(create_image)
            
            process = subprocess.Popen(create_image.split(), stdout=subprocess.PIPE)
            output, error = process.communicate()
            
            ### * Push Image
            lightsail_command = self.lightsail_manager.push_image()
            region = self.lightsail_manager.container_region()
            label = self.lightsail_manager.label(image_name)
            image = self.lightsail_manager.image(image_name, image_tag)
            push = lightsail_command + region + container_name + label + image
            print(push)
            
            process = subprocess.Popen(push.split(), stdout=subprocess.PIPE)
            output, error = process.communicate()

        ## Create Docker Image
        elif choice == "C" or choice =="c":
            
            ### * Create Docker build image
            docker_command = self.docker_manager.build_tag()
            image_name = self.docker_manager.image_name()
            image_tag = self.docker_manager.image_tag()
            create_image = docker_command + image_name + image_tag + ' .'
            print(create_image)
            
            process = subprocess.Popen(create_image.split(), stdout=subprocess.PIPE)
            output, error = process.communicate()
        
        ## List All Running Containers
        elif choice == "D" or choice =="d":
            
            ### * List all running containers
            containers_listing = self.lightsail_manager.container_list()
            print(containers_listing)
            
            process = subprocess.Popen(containers_listing.split(), stdout=subprocess.PIPE)
            output, error = process.communicate()
        
        ## Delete Container 
        elif choice == "E" or choice =="e":
            
            ### * Delete a specific container
            delete = self.lightsail_manager.delete_container()
            name = self.lightsail_manager.container_name()
            delete_container_command = delete + name
            print(delete_container_command)
            
            process = subprocess.Popen(delete_container_command.split(), stdout=subprocess.PIPE)
            output, error = process.communicate()
            
        ## Quit                                  
        elif choice=="Q" or choice=="q":
            sys.exit
            
        else:
            print("\nYou must only select either A or Q")
            print("Please try again")
            self.menu()
  
  
cli = CLI()

cli.menu() 
  
  
  
  
  
  
  
  
            
