from agplibs.clients.sac import SugarApiClient
from agplibs.clients.dorm import DormApiClient
from agplibs.utils.interfaces import Itagger
from agplibs.utils.utils import chunks
import abc
import datetime


class Tag:

    class SourcePrincipale:

        AGENT_PARTICULIER = 'Agent Particulier'
        AGENT_ENTREPRISE = "Agent Entreprise"
        CAVI = 'CAVI'
        CLIC_ASSURE = 'ClicAssure'
        CLIC_ASSURE_TELEPHONIQUE = 'ClicAssure Telephonique'
        COLLECTE_WEB = 'Collecte Web'
        ENTRANTS = 'Entrants'
        SOUMISSION_WEB = 'Soumission Web'
        AUTRES = 'Autres'
        REFERENCEMENT = 'Referencement'
        ERREUR = 'Erreur'
        VIDE = ''

    class SourceSecondaire:
        AGENT_ENTREPRISE = "Agent Entreprise"
        CLIC_ASSURE = 'ClicAssure'
        AUTRES_STATUTS = 'Autres Statuts'
        COLLECTE_WEB = 'Collecte Web'
        NSF = 'NSF'
        REFERENCEMENT = 'Referencement'
        SOUMISSION_WEB = 'Soumission Web'
        SOUMISSION_DECLINEE = 'Soumission Declinee'
        SOUMISSION_DECLINEE_EXCLUE = 'Soumission Declinee Exclue'
        VENDEUR_PARTICULIER = 'Vendeur Particulier'
        AGENT_PARTICULIER = 'Agent Particulier'
        AGENT_PARTICULIER_ANGLAIS = 'Agent Particulier Anglais'
        SUIVI_DE_VENTE = 'Suivi de Vente'
        POLICE_ANNULEE = 'Police Annulee'
        CLIENT_PARTICULIER = 'Client Particulier'
        CLIENT_COMMERCIAL = 'Client Commercial'
        ANNULATION_NON_PAIEMENT = 'Annulation Non Paiement'
        SNV = 'SNV'
        VIDE = ''

    class SourceTertiaire:

        RAPPEL_TRANSFERT = 'Rappel Transfert'
        LONGUE_ATTENTE = 'Longue Attente'
        RENDEZ_VOUS = 'Rendez Vous'
        SUIVI_DE_VENTE = 'Suivi de Vente'
        NSF = 'NSF'
        VIDE = ''


class TagAudit(dict):

    SOURCE_PRINCIPALE = "source_principale_c"
    SOURCE_SECONDAIRE = "source_secondaire_c"
    SOURCE_TERTIAIRE = "source_tertiaire_c"

    def __init__(self, id, source, old_value, new_value):

        self["contact_id"] = id

        self["field_name"] = source

        self["old_value"] = old_value

        self["new_value"] = new_value


class Tagger(Itagger):

    BULK_CREATE_ROUTE = "ressource/sources-audits/bulk-create"

    @staticmethod
    def bulk_create(sac: SugarApiClient,  dorm: DormApiClient,  ids, **kwargs):
        """Mass update d'un contact"""

        payload = {}

        if "source_principale" in kwargs:
            payload["source_principale_c"] = kwargs.get("source_principale")

        if "source_secondaire" in kwargs:
            payload["source_secondaire_c"] = kwargs.get("source_secondaire")

        if "source_tertiaire" in kwargs:
            payload["source_tertiaire_c"] = kwargs.get("source_tertiaire")

        if not payload:
            raise Exception("Aucune source fournie")

        # UPDATE DORM
        tag_infos = []
        for chunk in chunks(ids, 500):

            s_contacts = sac.bulk_get("Contacts", chunk, fields=[
                                      "id", "source_principale_c", "source_secondaire_c", "source_tertiaire_c"])

            for s_contact in s_contacts:
                for key in payload.keys():
                    tag_infos.append(
                        TagAudit(s_contact["id"], key, s_contact[key], payload[key]))

        dorm.endpoint(Tagger.BULK_CREATE_ROUTE).post({
            "tags": tag_infos
        })

        # UPDATE SUGAR
        for key in payload.keys():
            for chunk in chunks(ids, 500):
                sac.mass_update("Contacts", chunk, key, payload[key])

    @staticmethod
    def tag_source(client, contact_id, **kwargs):

        if contact_id == '':

            raise Exception(f"Le contact ID : {contact_id} est invalide!")

        dorm = DormApiClient()
        copie_kwargs = kwargs.copy()
        payload = {}

        call_status = (client.get("Contacts", id=contact_id, fields=[
                       'statut_appel_c']))[0]['statut_appel_c']

        source_principale = kwargs.get("source_principale_c", None)
        if source_principale != None:

            copie_kwargs.pop('source_principale_c')
            payload['source_principale_c'] = source_principale

            dorm.create_source_audits(
                contact_id, "source_principale_c", source_principale, call_status)

        source_secondaire = kwargs.get("source_secondaire_c", None)
        if source_secondaire != None:

            copie_kwargs.pop('source_secondaire_c')
            payload['source_secondaire_c'] = source_secondaire

            dorm.create_source_audits(
                contact_id, "source_secondaire_c", source_secondaire, call_status)

        source_tertiaire = kwargs.get("source_tertiaire_c", None)
        if source_tertiaire != None:

            copie_kwargs.pop('source_tertiaire_c')
            payload['source_tertiaire_c'] = source_tertiaire

            dorm.create_source_audits(
                contact_id, "source_tertiaire_c", source_tertiaire, call_status)

        if len(copie_kwargs) > 0:

            raise Exception(
                f"Les paramètres {copie_kwargs} nes sont pas suportés")

        return client.put("Contacts", contact_id, payload=payload)

    @staticmethod
    def get_current_sources(client, contact_id, source_principale):
        '''
            Deprecated use instead get_current_sources(client, contact_id)
        '''
        if contact_id != '':

            raise Exception(f"Le contact ID : {contact_id} est invalide!")

        return client.get("Contacts", id=contact_id, fields=['source_principale_c', 'source_secondaire_c', 'source_tertiaire_c'])

    @staticmethod
    def get_current_sources(client, contact_id):

        if contact_id != '':

            raise Exception(f"Le contact ID : {contact_id} est invalide!")

        return client.get("Contacts", id=contact_id, fields=['source_principale_c', 'source_secondaire_c', 'source_tertiaire_c'])


# tagger = Tagger()
# sac = SugarApiClient()

# print(tagger.get_contact_status(sac,'23ad0bc2-5c61-11e8-b05d-0699afa2cd79' ))

# print(tagger.get_contact_status('23ad0bc2-5c61-11e8-b05d-0699afa2cd79'))

# print(tagger.get_current_sources("23ad0bc2-5c61-11e8-b05d-0699afa2cd79"))


# tagger.tag_source(sac, "23ad0bc2-5c61-11e8-b05d-0699afa2cd79", source_principale_c = Tag.SourcePrincipale.ENTRANTS, source_secondaire_c = Tag.SourceSecondaire.SUIVI_DE_VENTE  )


# print(tagger.get_current_sources("23ad0bc2-5c61-11e8-b05d-0699afa2cd79"))
