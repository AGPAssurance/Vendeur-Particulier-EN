import abc


class ILogger(metaclass=abc.ABCMeta):
    
    @classmethod
    def __subclasshook__(cls, subclass):
        return (
            
            hasattr(subclass, 'set_logger') and
            callable(subclass.set_logger) and

            hasattr(subclass, 'get_logger') and
            callable(subclass.get_logger) and

            hasattr(subclass, 'log') and
            callable(subclass.log) 
            or NotImplemented)


    @abc.abstractmethod
    def log(self,msg):
        raise NotImplementedError

    @abc.abstractmethod
    def set_logger(self, logger):
        raise NotImplementedError

    @abc.abstractmethod
    def get_logger(self, logger):
        raise NotImplementedError
