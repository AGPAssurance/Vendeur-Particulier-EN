import PureCloudPlatformClientV2 
from pprint import pprint
import json

## TODO: Faire validation expiration Token
class GenesysApiClient:
    
    def __init__(self, client_id, client_secret):

        ## Set the region
        self._region = PureCloudPlatformClientV2.PureCloudRegionHosts.ca_central_1
        PureCloudPlatformClientV2.configuration.host = self._region.get_api_host()
        ## The header object
        self._apiclient = PureCloudPlatformClientV2.api_client.ApiClient().get_client_credentials_token(client_id, client_secret)
        # print(self._apiclient.__dict__)
        
    @property
    def access(self):
        
        return self._apiclient
    
    def outbound_access(self, client):
        
        return PureCloudPlatformClientV2.OutboundApi(client)
        




















