import os.path
import pickle
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow

from google.auth.transport.requests import Request
from datetime import date, datetime
import logging
urllib3_logger = logging.getLogger('urllib3')
urllib3_logger.setLevel(logging.CRITICAL)


class GoogleCalendarClient:

    def __init__(self, creds_dir, calendar_env):

        # If modifying these scopes, delete the file token.pickle.
        self.SCOPES = ['https://www.googleapis.com/auth/calendar']
        self.creds = None
        self.service = None
        
        self.calendar_env = calendar_env
        self.pickle_path = f"{creds_dir}/token.pickle"
        self.creds_path = f"{creds_dir}/credentials.json"

        self.google_auth()



    def google_auth(self):
        if os.path.exists(self.pickle_path):
            with open(self.pickle_path, 'rb') as token:
                self.creds = pickle.load(token)

        if not self.creds or not self.creds.valid:
            if self.creds and self.creds.expired and self.creds.refresh_token:
                self.creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file(self.creds_path, self.SCOPES)
                self.creds = flow.run_local_server(port=0)
            # Save the credentials for the next run
            with open(self.pickle_path, 'wb') as token:
                pickle.dump(self.creds, token)
        try:
            self.service = build('calendar', 'v3', credentials=self.creds)

        except Exception as e:
            print(e)


    def format_event(self, summary, desc, start_time :datetime, end_time :datetime):
        start_time = start_time.strftime("%Y-%m-%dT%H:%M:%S.000")
        end_time = end_time.strftime("%Y-%m-%dT%H:%M:%S.000")
        return  {
                'summary': summary,
                'description': desc,
                'start': {
                    'dateTime': f'{start_time}',
                    'timeZone': 'America/New_York',
                },
                'end': {
                    'dateTime': f'{end_time}',
                    'timeZone': 'America/New_York',
                }
            }


    def create_event(self, event):
        event_response = {"status" : "ERROR"}
        try:
            event_response = self.service.events().insert(calendarId=self.calendar_env,
                                                     body=event).execute()
            return (event_response["status"], event_response.get('id', None))
        except Exception as e:
            return (500, event_response["status"])

    def update_event(self, id, event):
        event_response = {"status" : "ERROR"}
        try:
            event_response = self.service.events().update(calendarId=self.calendar_env,
                                                     body=event, eventId=id).execute()
            return (event_response["status"], event_response.get('id', None))
        except Exception as e:
            return 500, None


    def delete_event(self, id):

        event_response = {"status" : "ERROR"}
        try:
            event_response = self.service.events().delete(calendarId=self.calendar_env, eventId=id).execute()

            return (event_response["status"], event_response.get('id', None))

        except Exception as e:
            return 500, None


