from agplibs.genesys.analytics import QueueListener, QueuesContext
from agplibs.clients.genac import GenesysApiClient
from agplibs.services.service import ServiceSuper
from agplibs.clients.dorm import DormApiClient
from agplibs.utils.slack import log_on_slack

from PureCloudPlatformClientV2.apis import OutboundApi

import traceback
import asyncio
from pprint import pprint
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')


class Handler:
    """Gère l'ouverture et la fermeture des campagnes.
    """


    def __init__(self, outbound_client : OutboundApi, campaigns ):
        self.__outbound_client = outbound_client
        
        self.__campaigns_map = {}
        for campaign in campaigns:
            self.__campaigns_map[campaign.name] = campaign
        
    
    async def open_campaign(self, campaign):

        if campaign not in self.__campaigns_map:
            raise Exception(f"La campagne {campaign} n'existe pas!")
        
        campaign_id = self.__campaigns_map[campaign].id

        print(f"OPEN {campaign_id}")

    async def close_campaign(self, campaign):
        if campaign not in self.__campaigns_map:
            raise Exception(f"La campagne {campaign} n'existe pas!")

        campaign_id = self.__campaigns_map[campaign].id

        print(f"CLOSE {campaign_id}")



class CampaignConf:
    """Abastraction d'une campagne d'appel avec les informations. 

    Note: 
    Classe immutable
    """

    def __init__(self, campaign, data):
        self.__campaign = campaign
        self.__max_waiting_time = data.get("max_waiting_time", None)
        self.__nb_waiting_calls = data.get("nb_waiting_calls", None)


    @property
    def campaign(self):
        return self.__campaign
    @property
    def max_waiting_time(self):
        return self.__max_waiting_time
    @property
    def nb_waiting_calls(self):
        return self.__nb_waiting_calls

class Campaigns:
    """
        Classe statique avec de l'informations sur les campagnes.
    """
    C_AGENT_PARTICULIER = 0
    C_AUTRES_STATUTS = 1,
    C_NSF = 2
    C_VENDEUR_PARTICULIER = 3
    C_SD = 4
    C_CONCOURS = 5
    C_SUIVI_DE_VENTE = 6
    C_RDV = 7
    C_PREVIEW_CONTACTS = 8
    C_PREVIEW_SNV = 9
    C_PREVIEW_SUIVI_DE_VENTE = 10
    C_SNV = 11
    C_LONGUE_ATTENTE = 12
    C_RAPPEL_NA = 13    


class Algorithme:

    """Algorithme de gestion des campagnes.

    Le service est responsable de l'ouverture et la fermeture des campagnes selon certaines conditions.
    """

    def __init__(self, 
                genac : GenesysApiClient,
                queues_context : QueuesContext,
                campaigns : list):

        """CTOR principal

        Args:
            genac (GenesysApiClient) : Client genesys 
            queues_context (QueuesContext): Contexte partagé avec l'information des queues
        """
        self.__queues_context = queues_context            
        self.__handler = Handler(genac, campaigns) 

        self.__queues_map = {}
        for campaign in campaigns:
            self.__queues_map[campaign.queue.name] = campaign

        self.__data_queue_waiting_sc_fr = list(map(lambda key, value: CampaignConf(self.__queues_map[key],value) ), 
                                                    DATA_QUEUES_WAITING_SC_FR.items())

        self.__data_queue_waiting_sc_eng = list(map(lambda key, value: CampaignConf(self.__queues_map[key],value) ), 
                                                    DATA_QUEUES_WAITING_SC_ENG.items())

        
    async def listen(self, interval=10):
        """Prend action à des intervales régulier dépendemment de l'état du contexte.

        Args:
            interval (int, optional): Interval avant de vérifier les données. Defaults to 10.
        """

        try: 
            # CONTACTS
            self.gestion_campagnes_contacts()
            # CONSEILLERS
            self.gestion_campagnes_conseillers()

        except Exception as e:
            errors = traceback.format_exc()
            return errors

        await asyncio.sleep(5)



    def __get_nb_contacts_in_queues(self, queues : list):
        """Retourne le nombre de contacts dans une liste de files.

        Args:
            queues (list(str)): Liste de files

        Returns:
            [type]: [description]
        """

        nb_contacts = 0

        for queue_id in queues:
            data = self.__queues_context.get_queue_data(queue_id)
            nb_contacts += data.nb_contacts_en_attente

        return nb_contacts


    def __get_nb_transferts(self):
        """Retourne le nombre de transferts en attente.

        Returns:
            int : NB transferts en attente.
        """
        
        queues_transferts = [
            Campaigns.C_PREVIEW_CONTACTS,
            Campaigns.C_PREVIEW_SNV,
            Campaigns.C_PREVIEW_SUIVI_DE_VENTE
        ]

        return self.__get_nb_contacts(queues_transferts)

        

    def __appels_sont_en_attente(self, campaigns_confs : list ) -> bool:
        """Retourne vrai si un appel contredit les conditions d'attente.

        Args:
            campaign_conf (list(CampaignConf)): Liste de configurations d'une campagne

        Returns:
            bool: Vrai si un appel contredit les conditions d'attentes. Faux autrement.
        """

        appel_en_attente = False
        index = 0

        while not appel_en_attente and  index < len(campaigns_confs):
            
            campaign_conf = campaigns_confs[index]
            queue_data = self.__queues_context.get_queue_data(campaign_conf.pid)
        

            appel_en_attente = queue_data.nb_contacts_en_attente >= campaign_conf.nb_waiting_calls or \
                               queue_data.max_waiting_time >= campaign_conf.max_waiting_time
        
        return appel_en_attente



    def __appels_de_service_fr_sont_en_attente(self):
        """Retourne vrai si une des campagnes de service FR contredit ses critères d'attentes.
        """
        campaigns_confs = self.__data_queue_waiting_sc_fr

        return self.__appels_sont_en_attente(campaigns_confs)



    def __appels_de_services_eng_sont_sont_attente(self):
        """Retourne vrai si une des campagnes de service ENG contredit ses critères d'attentes.
        """
        campaigns_confs = self.__data_queue_waiting_sc_eng

        return self.__appels_sont_en_attente(campaigns_confs)



    async def gestion_campagnes_contacts(self):
        """Gère l'ouverture et la fermeture du côté contacts.
        """
        
        nb_transferts = self.__get_nb_transferts()
        
        if nb_transferts <= 1:
            
            # À FERMER
            self.__handler.close_campaign(Campaigns.C_AGENT_PARTICULIER)
            self.__handler.close_campaign(Campaigns.C_AUTRES_STATUTS)
            self.__handler.close_campaign(Campaigns.C_NSF)
            self.__handler.close_campaign(Campaigns.C_SUIVI_DE_VENTE)

            # À OUVRIR
            self.__handler.open_campaign(Campaigns.C_VENDEUR_PARTICULIER)
            self.__handler.open_campaign(Campaigns.C_SNV)
            self.__handler.open_campaign(Campaigns.C_SD)
            self.__handler.open_campaign(Campaigns.C_CONCOURS)
            self.__handler.open_campaign(Campaigns.C_RDV)

        elif nb_transferts == 2:

            # À FERMER
            self.__handler.close_campaign(Campaigns.C_VENDEUR_PARTICULIER)

            # À OUVRIR
            self.__handler.open_campaign(Campaigns.C_AGENT_PARTICULIER)
            self.__handler.open_campaign(Campaigns.C_AUTRES_STATUTS)
            self.__handler.open_campaign(Campaigns.C_NSF)
            self.__handler.open_campaign(Campaigns.C_SUIVI_DE_VENTE)
            self.__handler.open_campaign(Campaigns.C_SNV)
            self.__handler.open_campaign(Campaigns.C_SD)
            self.__handler.open_campaign(Campaigns.C_CONCOURS)
            self.__handler.open_campaign(Campaigns.C_RDV)

        elif nb_transferts == 3:

            # À FERMER
            self.__handler.close_campaign(Campaigns.C_VENDEUR_PARTICULIER)
            self.__handler.close_campaign(Campaigns.C_SNV)
            self.__handler.close_campaign(Campaigns.C_SD)
            self.__handler.close_campaign(Campaigns.C_CONCOURS)
         

            # À OUVRIR
            self.__handler.open_campaign(Campaigns.C_AGENT_PARTICULIER)
            self.__handler.open_campaign(Campaigns.C_AUTRES_STATUTS)
            self.__handler.open_campaign(Campaigns.C_NSF)
            self.__handler.open_campaign(Campaigns.C_SUIVI_DE_VENTE)
            self.__handler.open_campaign(Campaigns.C_RDV)


        else:

            # À FERMER
            self.__handler.close_campaign(Campaigns.C_VENDEUR_PARTICULIER)
            self.__handler.close_campaign(Campaigns.C_SNV)
            self.__handler.close_campaign(Campaigns.C_SD)
            self.__handler.close_campaign(Campaigns.C_CONCOURS)
            self.__handler.close_campaign(Campaigns.C_SUIVI_DE_VENTE)
            self.__handler.close_campaign(Campaigns.C_RDV)

            # À OUVRIR
            self.__handler.open_campaign(Campaigns.C_AGENT_PARTICULIER)
            self.__handler.open_campaign(Campaigns.C_AUTRES_STATUTS)
            self.__handler.open_campaign(Campaigns.C_NSF)


    async def gestion_campagnes_conseillers(self):
        """Gèrer l'ouverture et la fermeture du côté des conseillers
        """

        if(self.__appels_de_service_fr_sont_en_attente()):

            # À FERMER
            self.__handler.close_campaign(Campaigns.C_PREVIEW_CONTACTS)
            self.__handler.close_campaign(Campaigns.C_PREVIEW_SNV)
            self.__handler.close_campaign(Campaigns.C_PREVIEW_SUIVI_DE_VENTE)

        elif(self.__appels_de_services_eng_sont_sont_attente()):

            if(self.__appels_longues_attente()):
                #TODO  : Retrait des conseillers longue attente par le biais des assignations.
                pass

            else:
                
                #TODO  : Retrait des conseillers longue attente par le biais des assignations.

                # À OUVRIR
                self.__handler.open_campaign(Campaigns.C_PREVIEW_CONTACTS)
                self.__handler.open_campaign(Campaigns.C_PREVIEW_SNV)
                self.__handler.open_campaign(Campaigns.C_PREVIEW_SUIVI_DE_VENTE)

        elif(self.__appels_longues_attente()):
            # À FERMER
            self.__handler.close_campaign(Campaigns.C_PREVIEW_CONTACTS)
            self.__handler.close_campaign(Campaigns.C_PREVIEW_SNV)
            self.__handler.close_campaign(Campaigns.C_PREVIEW_SUIVI_DE_VENTE)

        else:
            # À OUVRIR
            self.__handler.open_campaign(Campaigns.C_PREVIEW_CONTACTS)
            self.__handler.open_campaign(Campaigns.C_PREVIEW_SNV)
            self.__handler.open_campaign(Campaigns.C_PREVIEW_SUIVI_DE_VENTE)
            

class Service(ServiceSuper):

    NAME = "algorithme"

    def __init__(self):
        ServiceSuper.__init__(self, Service.NAME)
        self.__share_queues_context = QueuesContext()
        

        self.__genac = GenesysApiClient("5b5eb6df-e487-4564-a366-3e3f9de4c231", "RDzlsUEQKHb5ioOOtSA8nS4IT7ILGC3J08TB5NHXCQc")
        self.dorm = DormApiClient()     
        self.__outbound_client = OutboundApi(self.__genac.access)

        campaigns = self.get_campaigns()
        self.__algo = Algorithme(self.__genac, self.__share_queues_context, campaigns)
        self.__listener = QueueListener(self.__genac, self.__share_queues_context, 
                                        list(map(lambda c : c.queue.id, campaigns)))



    def get_campaigns(self):
        raw_data = self.__outbound_client.get_outbound_campaigns()
        return raw_data.entities

    async def job(self):
        # log_on_slack({"Jonathan": "UKXMF9952", "Mathieu" : "U01S1DWCPMH", "Maxime": "U0TNGQHDY"}, f"Vendeur Particulier : Start")

        # error = False

        # try:
        #     self.event_start(self.dorm, datetime.now())
        #     self.event_status(self.dorm, ServiceStatus.PENDING)


            ts_queue_listener = asyncio.create_task(self.__listener.listen(10))
            ts_algo = asyncio.create_task(self.__algo.listen(10))

            
            await ts_queue_listener
            await ts_algo

            
        #     self.event_status(self.dorm, ServiceStatus.SUCESS)
        # except Exception as e:
        #     self.file_logger.error(traceback.format_exc())
        #     self.event_status(self.dorm, ServiceStatus.FAILED)
        #     error = True

        # finally:
        #     self.send_log(self.dorm, True)
        #     self.event_end(self.dorm, datetime.now())

        #     msg = f"{Service.NAME} "
            
        #     if(error):
        #         msg += "FAILED"
        #     else:
        #         msg += "END"

        # log_on_slack({"Jonathan": "UKXMF9952", "Mathieu" : "U01S1DWCPMH", "Maxime": "U0TNGQHDY"}, msg)


    def exec(self):
        self.file_logger.info(f"{Service.NAME} INFO")
        asyncio.run(self.job())  


if __name__ == "__main__":
    service = Service()
    service.exec()

        