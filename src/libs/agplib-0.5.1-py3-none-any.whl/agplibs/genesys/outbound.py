import abc
import json
from datetime import datetime
import time
from agplibs.clients.genac import GenesysApiClient
import requests
import json
from pprint import pprint
import asyncio
from agplibs.utils.utils import chunks



class GenesysContactModel:

    ID = "custom"
    NUMBER = "number"
    FIRSTNAME = "firstname"
    LAST_NAME = "lastname"
    OTHER_1 = "other_1"
    OTHER_2 = "other_2"
    OTHER_3 = "other_3"
    MANDATORIES = ["custom", "number", "firstname", "lastname"]

    def __init__(self,  contact_list_id :str, column_names : list):
        
        if not column_names:
            raise ValueError("column_names ne doit pas être vide")

        for c in GenesysContactModel.MANDATORIES:
            if c not in column_names:
                raise ValueError(f"La colonne `{GenesysContactModel.ID}` est obligatoire dans le modèle.")

        self.__contact_list_id = contact_list_id
        self.__model = dict.fromkeys(column_names)

    def __str__(self):
        number = self.get(GenesysContactModel.NUMBER)
        return str(self.get(GenesysContactModel.ID)) + " " + str(number) + " " + f"(GenesysContactModel)"

    def __repr__(self):
        return self.__str__()

    @property
    def id(self):
        return self.get(GenesysContactModel.ID)

    @property
    def firstname(self):
        return self.get(GenesysContactModel.FIRSTNAME)
    
    @property
    def lastname(self):
        return self.get(GenesysContactModel.LASTNAME)

    @property
    def number(self):
        return self.get(GenesysContactModel.NUMBER)

    @property
    def other_1(self):
        return self.get(GenesysContactModel.OTHER_1)

    @property
    def other_2(self):
        return self.get(GenesysContactModel.OTHER_1)

    @property
    def other_3(self):
        return self.get(GenesysContactModel.OTHER_1)


    @property
    def contact_list_id(self):
        return self.__contact_list_id


    def merge_data_into_model(self, data : dict):

        for key in data.keys():
            if key not in self.__model:
                raise Exception(f"La clée {key} n'est pas présente dans le modèle.")
        
        for key, value in data.items():
            self.__model[key] = value

    def keys(self):
        return self.__model.keys()

    def get(self, column_name : str):
        if column_name not in self.__model:
            raise Exception(f"La colonne {column_name} ne fait pas partie du modèle.")

        return self.__model[column_name]


    def set(self, column_name : str , value : object):
        
        if column_name not in self.__model:
            raise Exception(f"La colonne {column_name} ne fait pas partie du modèle.")

        self.__model[column_name] = value

    def is_complete(self):
        return not any(map(
            lambda value : value is  None or value == "" , self.__model.values()
        ))

    def to_dict(self):
        """Retourne le modèle sous forme de dictionnaire

        Returns:
            dict: Le modèle sous forme de dictionnaire.
        """
        return {
            "data" : self.__model.copy()
        }
        

    def from_model(self, data):
        """Retourne une copie du modèle avec les valeurs merge.

        Returns:
            GenesysContactModel: Une copie du modèle actuel avec les valeurs merge.
        """

        copy = GenesysContactModel(
            self.contact_list_id,
            list(self.__model.keys())
        )

        copy.merge_data_into_model(data)

        return copy


class Outbound:
    
    """
        Classe contenant des méthodes utiles pour la gestion des services de Genesys       
    """
    
    def __init__(self, client_id, client_secret):
        
        self._genac = GenesysApiClient(client_id, client_secret)
        self._outbound = self._genac.outbound_access(self._genac.access)

    def get_model_from_a_contact_list(self, contact_list_id : str):

        columns_name = self._outbound.get_outbound_contactlists_divisionview(contact_list_id).column_names
        
        return GenesysContactModel(contact_list_id, columns_name)
        

    def add_contacts_to_a_contact_list(self, contact_list_id: str, contacts: list):
        """Add contacts to a contact list
        
            Args:
                param1 (str): contact_list_id
                param2 (list(GenesysContact)): contact_ids

            Returns:
                Post all the specify contacts into the contact list

            Examples:
                instance.add_contacts_to_a_contact_list("123", [{"id": "23", "data": {"number": "1234567890","custom": "23"}},]) 
                
            Note:
                All columns need to be in the POST even if they are empty.
        """
        
        for chunk in chunks(contacts, 1000):
        
            self._outbound.post_outbound_contactlist_contacts(contact_list_id, list(map(lambda c: {
                
                **{"id" : c.id },
                **c.to_dict()

            } ,chunk)))
         
         
    def delete_contacts_from_a_contact_list(self, contact_list_id: str, contact_ids: list):
        """Delete contacts from a contact list.
        
            Args:
                param1 (str): contact_list_id
                param2 (list): contact_ids

            Returns:
                Delete all the specify contacts into the contact list

            Examples:
                instance.delete_contacts_from_a_contact_list("123", ['sugar_id', 'sugar_id']) 
                
            Note:
                The PK has to be configured to the custom, to be able to delete by id.
        """
        
        for chunk in chunks(contact_ids, 100):
            
            self._outbound.delete_outbound_contactlist_contacts(contact_list_id, chunk)


    def delete_all_contacts_from_a_contact_list(self, contact_list_id: str):
        """Delete all contacts from a contact list.
        
            Args:
                param1 (str): contact_list_id

            Returns:
                Delete all contacts into the contact list

            Examples:
                instance.delete_all_contacts_from_a_contact_list("123") 
                
            Note:
                Clear the campaign.
                
            Raises:
                AttributeError:
                ValueError: 
        """

        return self._outbound.post_outbound_contactlist_clear(contact_list_id)


    def update_custom_columns(self, contact_list_id : str, contact_id : str, body : dict):
        """Update a custom contact column

        Args:
            contact_list_id (str): Contact list id
            contact_id (str): Contact id
            body (dict): body

        Raises:
            Exception: Si le contact n'est pas dans la liste. 
        """
 
        outbound = self.get_contacts_from_a_contact_list(contact_list_id, [contact_id])

        if(not outbound):
            raise Exception(f"Le contact {contact_id} n'est pas la liste.")

        contact = outbound[0]

        contact.merge_data_into_model(body)

        self.update_a_contact(contact)


    def update_a_contact(self, contact: GenesysContactModel):
        """Update a contact in a contact list.
        
            Args:
                param1 (str): contact_list_id
                param2 (GenesysContactModel): contact
                
            Returns:
                Update a specific contact into the contact list.

            Examples:
                instance.update_a_contact("123", "23oi-04w-1", {'data': {"number":"0000000000", "firstname":"tony"}}) 
                
            Note:
                The PK has to be configured to the custom, to be able to update by id.
                All columns need to be in the PUT.

        """
                
        return self._outbound.put_outbound_contactlist_contact(contact.contact_list_id, contact.id, contact.to_dict())


    def is_contact_exist_in_contact_list(self, contact_list_id: str, contact_id: str):
        """Check if contact exist in a contact list.
        
            Args:
                param1 (str): contact_list_id
                param2 (str): contact_id
                
            Returns:
                Bool

            Examples:
                instance.is_contact_exist_in_contact_list("123", "b484f7oqfdb438") 
                
            Note:
                
            Raises:
                AttributeError:
                ValueError: 
        """
        try:
            response = self._outbound.get_outbound_contactlist_contact(contact_list_id, contact_id)
            return True
        except:
            return False

    
    def get_contacts_from_a_contact_list(self, contact_list_id, contact_ids):
        """Get contacts list.
        
            Args:
                param1 (str): contact_list_id
                param2 (list): contact_ids
                
            Returns:
                A list of dict.

            Examples:
                instance.get_contacts_from_a_contact_list("123", []) 
                
            Note:
                required a list of id.
                
            Raises:
                AttributeError:
                ValueError: 
        """

        model = self.get_model_from_a_contact_list(contact_list_id)
        
        contacts = []
        response = self._outbound.post_outbound_contactlist_contacts_bulk(contact_list_id, contact_ids)
       
        if len(response) > 0:
            contacts = list(map(lambda x: model.from_model(x.data), response))

        return contacts


    async def async_get_all_contacts_from_a_contact_list(self, contact_list_id):
        
        """Get all contacts from a contact list.
        
            Args:
                param1 (str): contact_list_id
                
            Returns:
                A list of dict.

            Examples:
                instance.get_all_contacts_from_a_contact_list("123") 
                
            Note:
                required a list of id.
                
            Raises:
                AttributeError:
                ValueError: 
        """
        
        initiate = self._outbound.post_outbound_contactlist_export(contact_list_id)
        
        await asyncio.sleep(10)
        
        response = requests.request(
            "GET", 
            f"https://api.cac1.pure.cloud/api/v2/outbound/contactlists/{contact_list_id}/export?download=true", 
            headers={
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'authorization': f'Bearer {self._genac.access.access_token}'
            }, 
            data={})
                        
        if response.status_code == 200:
        
            rows = []
            decoded_data = response.text.encode().decode('utf-8-sig')
            rows = decoded_data.split('\n')
                        
            keys = rows[0].replace('"', '' ).split(',')
            initial_dict = dict.fromkeys(keys, '')
            model = GenesysContactModel(contact_list_id,keys)
            
            contacts = []
            for row in rows[1:len(rows)-1]:
            
                values = row.replace('"', '' ).split(',')
                contact = {}
                
                for i, key in enumerate(initial_dict.keys()):
                    
                    contact[key] = values[i]
            
                contacts.append(model.from_model(contact))
                    
            return contacts
        
        if response.status_code == 404:
            
            return {'status':response.status_code,
                   "error":[response.text.encode().decode('utf-8-sig')]}


    def get_all_contacts_from_a_contact_list(self, contact_list_id):
        
        """Get all contacts from a contact list.
        
            Args:
                param1 (str): contact_list_id
                
            Returns:
                A list of dict.

            Examples:
                instance.get_all_contacts_from_a_contact_list("123") 
                
            Note:
                required a list of id.
                
            Raises:
                AttributeError:
                ValueError: 
        """
        
        try:
            initiate = self._outbound.post_outbound_contactlist_export(contact_list_id)
        except:
            pass

        time.sleep(10)

        
        response = requests.request(
            "GET", 
            f"https://api.cac1.pure.cloud/api/v2/outbound/contactlists/{contact_list_id}/export?download=true", 
            headers={
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'authorization': f'Bearer {self._genac.access.access_token}'
            }, 
            data={})
                        
        if response.status_code == 200:
        
            rows = []
            decoded_data = response.text.encode().decode('utf-8-sig')
            rows = decoded_data.split('\n')
                        
            keys = rows[0].replace('"', '' ).split(',')
            initial_dict = dict.fromkeys(keys, '')
            
            model = GenesysContactModel(contact_list_id, keys)
            
            contacts = []
            for row in rows[1:len(rows)-1]:
            
                values = row.replace('"', '' ).split(',')
                contact = {}
                
                for i, key in enumerate(initial_dict.keys()):
                    contact[key] = values[i]


                
                contacts.append(model.from_model(contact))
                    
            return contacts
        
        if response.status_code == 404:
            
            return {'status':response.status_code,
                   "error":[response.text.encode().decode('utf-8-sig')]}


