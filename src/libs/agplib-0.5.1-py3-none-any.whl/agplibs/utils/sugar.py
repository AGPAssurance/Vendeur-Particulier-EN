import abc
import json
from re import T
from agplibs.utils.interfaces import Itagger
from datetime import datetime
import time

class TimeHelper:

    """
        Classe statique contenant des méthodes utiles à la gestion du temps
    """
    @staticmethod
    def format(datetime, audit):
        return datetime.strftime("%Y-%m-%d %H:%M:%S") if audit else datetime.strftime("%Y-%m-%dT%H:%M:%S")


class Contact(Itagger):

    """
        Classe statique contenant des méthodes utiles pour la gestion des contacts dans SugarCRM        
    """

    @staticmethod
    def get_ids_by_phone(client, **kwargs):
        """
            A partir d'un numéro d'un contact,

            retourne les id des éléments
        """
        copie_kwargs = kwargs.copy()

        list = []

        phone_home = kwargs.get("phone_home", "")
        phone_mobile = kwargs.get("phone_mobile", "")

        if(phone_home == "" and phone_mobile == ""):
            raise Exception(f"Les numéros ne doivent pas être vide")

        if(phone_home == "" and phone_mobile != ""):
            phone_home = phone_mobile

        if(phone_home != ""):
            list.append({"phone_home": phone_home})

        if(phone_mobile != ""):
            list.append({"phone_mobile": phone_mobile})

        list.append({
            "phone_other": phone_home
        })

        list.append({
            "phone_fax": phone_home
        })

        filter = {
            "filter": [
                {
                    "$or": [
                        {
                            "phone_home": phone_home
                        },
                        {
                            "phone_mobile": phone_mobile
                        }
                    ]
                }
            ]
        }

        response = client.get("Contacts", filters=filter, fields=["id"])

        return response

    @staticmethod
    def create_contact_sugar(client, person):
        """
            Création d'une contact dans SugarCRM

            Retourne un dictionnaire python
        """

        if("phone_home" in person and person["phone_home"] == ""):
            raise Exception(
                "L'ajout d'un client dans Sugar nécessite un numéro de téléphone")

        if("phone_mobile" in person and person["phone_mobile"] == ""):
            raise Exception(
                "L'ajout d'un client dans Sugar nécessite un numéro de téléphone")

        if("phone_mobile" not in person and "phone_home" not in person):
            raise Exception(
                "L'ajout d'un client dans Sugar nécessite un numéro de téléphone")

        response = client.post("Contacts", payload=json.dumps(person))
        return response

    @staticmethod
    def contact_has_number(person_dict):
        """
            Retourne vrai si le contient  possède un numéro de téléphone
        """
        return (("phone_home" in person_dict and person_dict["phone_home"] != "") or
                ("phone_mobile" in person_dict and person_dict["phone_mobile"] != ""))

    @staticmethod
    def contact_has_rdv(person_dict):
        """
            Retourne vrai si le Contact possède un rendez-vous
        """
        return (("rdv_contact_c" in person_dict and person_dict["rdv_contact_c"] != ""))

    @staticmethod
    def contact_has_statut_appel(person_dict):
        """
            Retourne vrai si le Contact possède un statut d'appel
        """
        return (("statut_appel_c" in person_dict and person_dict["statut_appel_c"] != ""))

    @staticmethod
    def tag_source(client, contact_id, **kwargs):

        copie_kwargs = kwargs.copy()

        payload = {}

        source_principale = kwargs.get("source_principale_c", None)

        if source_principale != None:

            copie_kwargs.pop('source_principale_c')
            payload['source_principale_c'] = source_principale

        source_secondaire = kwargs.get("source_secondaire_c", None)

        if source_secondaire != None:

            copie_kwargs.pop('source_secondaire_c')
            payload['source_secondaire_c'] = source_secondaire

        source_tertiaire = kwargs.get("source_tertiaire_c", None)

        if source_tertiaire != None:

            copie_kwargs.pop('source_tertiaire_c')
            payload['source_tertiaire_c'] = source_tertiaire

        if len(copie_kwargs) > 0:

            raise Exception(
                f"Les paramètres {copie_kwargs} nes sont pas suportés")

        return client.put("Contacts", contact_id, payload=payload)

    @staticmethod
    def get_current_sources(client, contact_id):

        return client.get("Contacts", id=contact_id, fields=['source_principale_c', 'source_secondaire_c', 'source_tertiaire_c'])

    @staticmethod
    def get_statut_appel_value(client, contact_id):

        response = client.get("Contacts", id=contact_id,
                              fields=['statut_appel_c'])

        return response[0]['statut_appel_c']

    @staticmethod
    def reset_preview_transfert(client, contact_id):

        return client.put("Contacts", contact_id, payload={"preview_transfert_c": ""})

    @staticmethod
    def reset_transfert_and_time_stamp_and_reason(client, contact_id, reason):

        time_stamp = (datetime.now()).strftime("%Y-%m-%d %H:%M:%S")

        return client.put("Contacts", contact_id, payload={"retire_du_preview_le_c": f"{time_stamp}", "raison_rappel_c": f"{reason}", "preview_transfert_c": ""})

    @staticmethod
    def put_call_status(client, contact_id, status):

        return client.put("Contacts", contact_id, payload={"statut_appel_c": f"{status}"})


