import abc
import json
from datetime import datetime
import time
from agplibs.clients.genac import GenesysApiClient
import requests
import json
from pprint import pprint
import asyncio
from agplibs.utils.utils import chunks

class Outbound:
    
    """
        Classe statique contenant des méthodes utiles pour la gestion des services de Genesys       
    """
    
    def __init__(self, client_id, client_secret):
        
        self._genac = GenesysApiClient(client_id, client_secret)
        self._outbound = self._genac.outbound_access(self._genac.access)
        

    def add_contacts_to_a_contact_list(self, contact_list_id: str, contact_ids: list):
        """Add contacts to a contact list
        
            Args:
                param1 (str): contact_list_id
                param2 (list): contact_ids

            Returns:
                Post all the specify contacts into the contact list

            Examples:
                instance.add_contacts_to_a_contact_list("123", [{"id": "23", "data": {"number": "1234567890","custom": "23"}},]) 
                
            Note:
                All columns need to be in the POST even if they are empty.
        """
        
        for chunk in chunks(contact_ids, 1000):
        
            self._outbound.post_outbound_contactlist_contacts(contact_list_id, chunk)
         
         
    def delete_contacts_from_a_contact_list(self, contact_list_id: str, contact_ids: list):
        """Delete contacts from a contact list.
        
            Args:
                param1 (str): contact_list_id
                param2 (list): contact_ids

            Returns:
                Delete all the specify contacts into the contact list

            Examples:
                instance.delete_contacts_from_a_contact_list("123", ['sugar_id', 'sugar_id']) 
                
            Note:
                The PK has to be configured to the custom, to be able to delete by id.
        """
        
        for chunk in chunks(contact_ids, 100):
            
            self._outbound.delete_outbound_contactlist_contacts(contact_list_id, chunk)


    def delete_all_contacts_from_a_contact_list(self, contact_list_id: str):
        """Delete all contacts from a contact list.
        
            Args:
                param1 (str): contact_list_id

            Returns:
                Delete all contacts into the contact list

            Examples:
                instance.delete_all_contacts_from_a_contact_list("123") 
                
            Note:
                Clear the campaign.
                
            Raises:
                AttributeError:
                ValueError: 
        """

        return self._outbound.post_outbound_contactlist_clear(contact_list_id)

        
    def update_a_contact(self, contact_list_id: str, contact_id: str, body: dict):
        """Update a contact from a contact list.
        
            Args:
                param1 (str): contact_list_id
                param2 (str): contact_id
                param3 (dict): body
                
            Returns:
                Update a specific contact into the contact list.

            Examples:
                instance.update_a_contact("123", "23oi-04w-1", {'data': {"number":"0000000000", "firstname":"tony"}}) 
                
            Note:
                The PK has to be configured to the custom, to be able to update by id.
                All columns need to be in the PUT.

        """
                
        return self._outbound.put_outbound_contactlist_contact(contact_list_id, contact_id, {'data': body})


    def is_contact_exist_in_contact_list(self, contact_list_id: str, contact_id: str):
        """Check if contact exist in a contact list.
        
            Args:
                param1 (str): contact_list_id
                param2 (str): contact_id
                
            Returns:
                Bool

            Examples:
                instance.is_contact_exist_in_contact_list("123", "b484f7oqfdb438") 
                
            Note:
                
            Raises:
                AttributeError:
                ValueError: 
        """
        try:
            response = self._outbound.get_outbound_contactlist_contact(contact_list_id, contact_id)
            return True
        except:
            return False

    
    def get_contacts_from_a_contact_list(self, contact_list_id, contact_ids):
        """Get contacts list.
        
            Args:
                param1 (str): contact_list_id
                param2 (list): contact_ids
                
            Returns:
                A list of dict.

            Examples:
                instance.get_contacts_from_a_contact_list("123", []) 
                
            Note:
                required a list of id.
                
            Raises:
                AttributeError:
                ValueError: 
        """
        
        response = self._outbound.post_outbound_contactlist_contacts_bulk(contact_list_id, contact_ids)
        response_to_dict = list(map(lambda x: x.to_dict(), response))
        
        return list(map(lambda x: x['data'], response_to_dict))


    async def async_get_all_contacts_from_a_contact_list(self, contact_list_id):
        
        """Get all contacts from a contact list.
        
            Args:
                param1 (str): contact_list_id
                
            Returns:
                A list of dict.

            Examples:
                instance.get_all_contacts_from_a_contact_list("123") 
                
            Note:
                required a list of id.
                
            Raises:
                AttributeError:
                ValueError: 
        """
        
        initiate = self._outbound.post_outbound_contactlist_export(contact_list_id)
        
        await asyncio.sleep(5)
        
        response = requests.request(
            "GET", 
            f"https://api.cac1.pure.cloud/api/v2/outbound/contactlists/{contact_list_id}/export?download=true", 
            headers={
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'authorization': f'Bearer {self._genac.access.access_token}'
            }, 
            data={})
                        
        if response.status_code == 200:
        
            rows = []
            decoded_data = response.text.encode().decode('utf-8-sig')
            rows = decoded_data.split('\n')
                        
            keys = rows[0].replace('"', '' ).split(',')
            initial_dict = dict.fromkeys(keys, '')
            
            contacts = []
            for row in rows[1:len(rows)-1]:
            
                values = row.replace('"', '' ).split(',')
                contact = {}
                
                for i, key in enumerate(initial_dict.keys()):
                    
                    contact[key] = values[i]
            
                contacts.append(contact)
                    
            return contacts
        
        if response.status_code == 404:
            
            return {'status':response.status_code,
                   "error":[response.text.encode().decode('utf-8-sig')]}


    def get_all_contacts_from_a_contact_list(self, contact_list_id):
        
        """Get all contacts from a contact list.
        
            Args:
                param1 (str): contact_list_id
                
            Returns:
                A list of dict.

            Examples:
                instance.get_all_contacts_from_a_contact_list("123") 
                
            Note:
                required a list of id.
                
            Raises:
                AttributeError:
                ValueError: 
        """
        
        initiate = self._outbound.post_outbound_contactlist_export(contact_list_id)
        
        time.sleep(5)
        
        response = requests.request(
            "GET", 
            f"https://api.cac1.pure.cloud/api/v2/outbound/contactlists/{contact_list_id}/export?download=true", 
            headers={
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'authorization': f'Bearer {self._genac.access.access_token}'
            }, 
            data={})
                        
        if response.status_code == 200:
        
            rows = []
            decoded_data = response.text.encode().decode('utf-8-sig')
            rows = decoded_data.split('\n')
                        
            keys = rows[0].replace('"', '' ).split(',')
            initial_dict = dict.fromkeys(keys, '')
            
            contacts = []
            for row in rows[1:len(rows)-1]:
            
                values = row.replace('"', '' ).split(',')
                contact = {}
                
                for i, key in enumerate(initial_dict.keys()):
                    
                    contact[key] = values[i]
            
                contacts.append(contact)
                    
            return contacts
        
        if response.status_code == 404:
            
            return {'status':response.status_code,
                   "error":[response.text.encode().decode('utf-8-sig')]}