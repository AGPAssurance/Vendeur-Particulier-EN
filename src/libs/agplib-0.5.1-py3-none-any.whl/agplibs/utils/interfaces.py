import abc
from datetime import datetime


class Itagger(metaclass=abc.ABCMeta):
    
    
    @classmethod
    def __subclasshook__(cls, subclass):
        return (
            hasattr(subclass, 'tag_source') and
            callable(subclass.tag_source) and
            
            hasattr(subclass, 'get_current_source') and
            callable(subclass.get_current_source) 
            or NotImplemented)
    
    @abc.abstractmethod
    def tag_source(self, contact_id, **kwargs):
        
        raise NotImplementedError
    
    @abc.abstractmethod
    def get_current_sources(self, contact_id):
        
        raise NotImplementedError
       

class IDict(metaclass=abc.ABCMeta):

    @classmethod
    def __subclasshook__(cls, subclass):
        return (
            hasattr(subclass, 'get_field') and
            callable(subclass.get_field) and

            hasattr(subclass, 'set_field') and
            callable(subclass.set_field) and

            hasattr(subclass, 'set_fields') and
            callable(subclass.set_fields) 

            or NotImplemented)

    @abc.abstractmethod
    def set_field(self, key, value):
        raise NotImplementedError
    
    @abc.abstractmethod
    def set_fields(self, dict):
        raise  NotImplementedError()
    
    @abc.abstractmethod
    def get_field(self, key):
        raise NotImplementedError


class IContactModel(metaclass=abc.ABCMeta):
    
    @classmethod
    def __subclasshook__(cls, subclass):
        return (
            hasattr(subclass, 'set_date_renouvellement_habit') and
            callable(subclass.set_date_renouvellement_habit) and
            
            hasattr(subclass, 'get_date_renouvellement_habit') and
            callable(subclass.get_date_renouvellement_habit) and

            hasattr(subclass, 'set_date_renouvellement_auto') and
            callable(subclass.set_date_renouvellement_auto) and
            
            hasattr(subclass, 'get_date_renouvellement_auto') and
            callable(subclass.get_date_renouvellement_auto) and

            hasattr(subclass, 'get_phone_home') and
            callable(subclass.get_phone_home) and
            
            hasattr(subclass, 'set_phone_home') and
            callable(subclass.set_phone_home) and 

            hasattr(subclass, 'get_phone_mobile') and
            callable(subclass.get_phone_mobile) and
            
            hasattr(subclass, 'set_phone_mobile') and
            callable(subclass.set_phone_mobile) and 


            hasattr(subclass, 'get_email') and
            callable(subclass.get_email) and
            
            hasattr(subclass, 'set_email') and
            callable(subclass.set_email) and 

            hasattr(subclass, 'get_last_name') and
            callable(subclass.get_last_name) and
            
            hasattr(subclass, 'set_last_name') and
            callable(subclass.set_last_name) and 

             hasattr(subclass, 'set_first_name') and
            callable(subclass.set_first_name) and  
            
            hasattr(subclass, 'set_first_name') and
            callable(subclass.set_first_name) and 

            hasattr(subclass, 'model_to_dict') and
            callable(subclass.model_to_dict) and
            
            hasattr(subclass, 'get_rdv_contact') and
            callable(subclass.get_rdv_contact) and 

            hasattr(subclass, 'set_rdv_contact') and
            callable(subclass.set_rdv_contact) 

            or NotImplemented)

    
    @abc.abstractmethod
    def model_to_dict(self):
        raise NotImplementedError
    
    @abc.abstractmethod
    def set_date_renouvellement_habit(self, date):
        raise NotImplementedError
    @abc.abstractmethod
    def get_date_renouvellement_habit(self):
        raise NotImplementedError

    @abc.abstractmethod
    def set_date_renouvellement_auto(self, date):
        raise NotImplementedError
    @abc.abstractmethod
    def get_date_renouvellement_auto(self):
        raise NotImplementedError

    @abc.abstractmethod
    def set_phone_mobile(self, phone_mobile: str):
        raise NotImplementedError
    @abc.abstractmethod
    def get_phone_mobile(self):
        raise NotImplementedError


    @abc.abstractmethod
    def set_phone_home(self, phone_home : str):
        raise NotImplementedError
    @abc.abstractmethod
    def get_phone_home(self):
        raise NotImplementedError

    @abc.abstractmethod
    def set_email(self, email : str):
        raise NotImplementedError
    
    @abc.abstractmethod
    def get_email(self):
        raise NotImplementedError

    @abc.abstractmethod
    def set_last_name(self, last_name : str):
        raise NotImplementedError
    
    @abc.abstractmethod
    def get_last_name(self):
        raise NotImplementedError

    @abc.abstractmethod
    def set_first_name(self, first_name : str):
        raise NotImplementedError
    
    @abc.abstractmethod
    def get_first_name(self):
        raise NotImplementedError

    @abc.abstractmethod
    def set_rdv_contact(self, rdv : datetime):
        self.__model[self.Keys.RENDEZ_VOUS_CONTACT] = rdv

    @abc.abstractmethod
    def get_rdv_contact(self, rdv : datetime):
        return self.__model.get(self.Keys.RENDEZ_VOUS_CONTACT, "")


class IFonivaPerson(metaclass=abc.ABCMeta):
    
    @classmethod
    def __subclasshook__(cls, subclass):
        return (
            hasattr(subclass, 'first_name') and
            callable(subclass.first_name) and

            hasattr(subclass, 'last_name') and
            callable(subclass.last_name) and 

            hasattr(subclass, 'number') and
            callable(subclass.number) and

            hasattr(subclass, 'sugar_id') and
            callable(subclass.last_name) 

            or NotImplemented)


    @abc.abstractmethod
    def get_first_name(self, first_name : str):
             raise NotImplementedError
    
    @abc.abstractmethod
    def set_first_name(self, first_name : str):
             raise NotImplementedError

    @abc.abstractmethod
    def get_last_name(self, last_name : str):
             raise NotImplementedError
    
    @abc.abstractmethod
    def set_last_name(self, last_name : str):
             raise NotImplementedError

    @abc.abstractmethod
    def get_number(self, number : int):
             raise NotImplementedError
    
    @abc.abstractmethod
    def set_number(self, number : int):
             raise NotImplementedError

    @abc.abstractmethod
    def get_sugar_id(self, sugar_id : str):
             raise NotImplementedError
    
    @abc.abstractmethod
    def set_sugar_id(self, sugar_id : str):
             raise NotImplementedError
        
        