import requests
from typing import Dict
from agplibs.clients.dorm import DormApiClient
from typing import List
from datetime import datetime


def log_on_slack(channel_list, text):
    for r in channel_list.values():
        data = {
            'token': "xoxb-18763457618-1752581933428-ONiCxXNPeytzMs9AttabU3vQ",
            'channel': f'{r}',
            'as_user': True,
            'text': text
        }
        requests.post(url="https://slack.com/api/chat.postMessage", data=data)


class AlerteJarvisModel:

    # Classe rerprésentant un modèle d'alerte

    def __init__(self, alerte_dict: Dict) -> None:
        self.id = alerte_dict.get("id", "")
        self.name = alerte_dict.get("name", "")
        self.time_interval = int(alerte_dict.get("time_interval", 0))
        self.queue_dbid = str(alerte_dict.get("queue", ""))
        self.msg = alerte_dict.get("msg")
        self.slack_users = {"user": user
                            for user in alerte_dict.get("slack_users", [])}

    def __repr__(self) -> str:
        return f"Alerte - {self.name}"


class AlerteJarvis:

    """
        Classe regroupant les méthodes utiles à la gestion des alertes jarvis
    """

    def __init__(self, dorm: DormApiClient) -> None:
        self._dorm = dorm

    def get_alertes(self) -> List[AlerteJarvisModel]:
        """
            Return a list of alertes
        """
        return list(map(lambda a: AlerteJarvisModel(a),
                    self._dorm.alerte_jarvis.get_all()))

    def check_alerte(self, alerte: AlerteJarvisModel,
                     queue_stats: dict) -> bool:
        """
            Retourne vrai si il faut envoyer une
            alerte aux utilisateurs.
        """
        stats = queue_stats[alerte.queue_dbid]['OLDESTWAITINGCALL_SINCE']

        if(stats != ""):
            return self._waiting_time_is_elpased(int(stats),
                                                 alerte.time_interval)

        return False

    def _waiting_time_is_elpased(self, owcs: int,
                                 max_waiting_time: int) -> bool:
        """
            Retourne vrai si le délai d'attente est supérieur
            au délai désiré.
        """
        oldest_waiting_call = datetime.fromtimestamp(owcs)
        waiting_time = datetime.now() - oldest_waiting_call
        return waiting_time.total_seconds() >= max_waiting_time

    def send_alerte(self, alerte: AlerteJarvisModel) -> None:
        """
            Envoie une alerte jarvis aux utilisateurs
            liés à l'alerte.
        """
        log_on_slack(alerte.slack_users,
                     f"⚠️  {alerte.name}  ⚠️ \r\n - {alerte.msg}")