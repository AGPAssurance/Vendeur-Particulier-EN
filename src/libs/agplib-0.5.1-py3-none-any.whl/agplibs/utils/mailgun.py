import requests 

class Mailgun:
    
    def __init__(self, base_url,  api_key):
       
        self.base_url = base_url
        self.auth = ("api", api_key)
        self.html = 0
   
   
    def serialized_attachments(self, files: list):
                
        attachment = []
                
        for file in files:
            
            f = open(file['path'], "rb")
            attachment.append(("attachment", (f)))
                
        return attachment
                
   
    def data(self, emails: list, subject: str, body: str, tag=None):
        
        if self.html:
        
            return {"from": "AGP Assurance <info@mail.agpassurance.ca>",
                "to": emails,
                "subject": subject,
                "html": body,
                "o:tag": tag}
            
        else:
            return {"from": "AGP Assurance <info@mail.agpassurance.ca>",
                "to": emails,
                "subject": subject,
                "text": body,
                "o:tag": tag}
            
            
    def send_mail(self, emails: list, subject: str, body: str, html: bool, tag='', files=[]):
        
        """
            html body : 1 (In other file, use function that return html)
            text body : 0
            
            example attachments : files = [{"path":"./template1.html"}, {"path":"./template2.html"}]
        
        """
        
        self.html = html
        
        return requests.post(
            self.base_url,
            auth= self.auth,
            files= self.serialized_attachments(files),
            data= self.data(emails, subject, body, tag)
        )
   
