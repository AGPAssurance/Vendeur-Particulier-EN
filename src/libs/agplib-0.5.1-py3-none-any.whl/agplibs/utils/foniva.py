import json
from  agplibs.clients.dorm import DormApiClient
from agplibs.clients.fac import FonivaApiClient

from threading import Thread



class Campaign:
    
    @staticmethod
    def is_phone_exist(client, number, dbid):
        
        """
        Require a client, a number and a dbid

        Return: Bool
        """
        numberlist = []
        for i in client.get_all(dbid):
            
            numberlist.append(i['number'])
            
        if number in numberlist:
            
            return True
        else:
            return False

    @staticmethod 
    def delete_contacts(client : FonivaApiClient, contact_list, dbid):

        nb_delete = 0

        for contact in contact_list:
            client.delete(contact["number"], dbid)
            nb_delete += 1

        return nb_delete


    @staticmethod
    def append_contact(client, contact_list, contact):

        if not Campaign.is_contact_exist_in_list(contact_list, contact):
                client.post(querystring=contact)
                return True

        return False

    @staticmethod
    def find_contact_in_list(contacts_list, contact):
        """
            Détermine si un contact existe dans une campagne par son id Sugar
        """
        for contact_i in contacts_list:
            if( (contact["custom"] != "" and contact["custom"] in contact_i.get("custom", "")) or 
                (contact["number"] != "" and contact["number"] in contact_i.get("number", "" ))):
                
                return contact_i

        return None


    @staticmethod
    def get_contacts_by_dbid(client: FonivaApiClient, dbid):
        contact_list = client.get_all(dbid)
    
        hash_set = []
        unique_list = []

        for contact_i in contact_list:
            number = contact_i["number"] 
            if(number not in hash_set):
                hash_set.append(contact_i["number"])
                unique_list.append(contact_i)

        return unique_list



    @staticmethod
    def is_contact_exist_in_list(contact_list, contact):
        
        """
            Détermine si un contact existe dans une campagne par son id Sugar
        """
        for contact_i in contact_list:
            if( (contact["custom"] != "" and contact["custom"] in contact_i.get("custom", "")) or 
                (contact["number"] != "" and contact["number"] in contact_i.get("number", "" ))):
                
                return True

        return False
    
        

class SkillManager():

    SC_FR = 75
    SC_EN = 76

    class Poste:
        LAB = "LAB", 
        AGENT_DE_SAISIE = "AGENT_DE_SAISIE"
        CONTACT = "CONTACT"
        CONSEILLER =  "CONSEILLER"
    

    def __init__(self, fac :FonivaApiClient, dorm : DormApiClient):
        self._fac =fac
        self._dorm = dorm
            
    class AgentModel():

        def __init__(self, agent_dict):
            
            self.foniva_agent_dbid = agent_dict.get("foniva_agent_dbid","")
            
            if(not isinstance(self.foniva_agent_dbid, int)):
                raise Exception("La dbid de l'agent doit être de type int")

            self.foniva_username = agent_dict.get("foniva_username", "")
            self.poste = agent_dict.get("poste","")
            self.skills = []

            for skill_dict in agent_dict.get("skills", []):
                self.skills.append(SkillManager.SkillModel(skill_dict))

            self.affected_skills = []

        def __hash__(self):
            return hash(self.foniva_agent_dbid)

        def __eq__(self, other):
            return self.foniva_agent_dbid == other.foniva_agent_dbid

        def __str__(self):
            return f"{self.foniva_agent_dbid} - {self.foniva_username}"

        def __repr__(self) -> str:
            return f"{self.foniva_agent_dbid} - {self.foniva_username}"

    class SkillModel():

        def __init__(self, skill_dict):
            self.dbid = skill_dict.get("dbid", "")

            if(not isinstance(self.dbid, int)):
                raise Exception("La dbid de l'agent doit être de type int.")


            self.name = skill_dict.get("name", "")
            self.default_language = skill_dict.get("default_language", "")

        def __hash__(self):
            return hash(self.dbid)

        def __eq__(self, o: object) -> bool:
            return o.dbid == self.dbid
            
        def __repr__(self) -> str:
            return str(self.dbid) + " - " + self.name
    


    def get_agents(self, poste=None):

        params = {}
        if(poste is not None):
            params["poste"] = poste 

        agents_dict = self._dorm.agent.get_all(params=params)
        

        agents= []

        for agent_dict in agents_dict:
            agents.append(SkillManager.AgentModel(agent_dict))

        return agents

        

    def remove_a_skill(self,  agent : AgentModel, skill : SkillModel):
        if(skill in agent.affected_skills):
            self._fac.unset_skill(agent.foniva_username, skill.name)
            agent.affected_skills.remove(skill)
            print(f"DELETE : Skill {skill.name} is now unset to agent {agent.foniva_username}")




    def remove_a_skill_if_assigned(self, agent : AgentModel, skill : SkillModel):
            if(skill in agent.skills):
                self.remove_a_skill(agent,skill)
            else:
                print(f"INFO : Skill {skill.name} is not assign to agent {agent.foniva_username}")



    def async_remove_a_skill_if_assigned(self, agents : AgentModel, skill : SkillModel):
        threads = []
        for agent in agents:
            process = Thread(target=self.remove_a_skill_if_assigned, args=[agent, skill])
            process.start()
            threads.append(process)

        for process in threads:
            process.join()

    
    def add_a_skill(self, agent : AgentModel, skill):
        if(skill not in agent.affected_skills):
            agent.affected_skills.append(skill)
            self._fac.set_skill(agent.foniva_username, skill.name)
            print(f"OK : Skill {skill.name} is now set to agent {agent.foniva_username}")
        else:
            print(f"ERROR : Skill {skill.name} is already affected to agent {agent.foniva_username}.")

    def add_skill_if_assign(self, agent, skill):
        if(skill in agent.skills):
            self.add_a_skill(agent, skill)
        else:
            print(f"INFO : Skill {skill.name} is not assign to agent {agent.foniva_username}")


    def async_add_skill_if_assign(self, agents, skill):
        threads = []
        for agent in agents:
            process = Thread(target=self.add_skill_if_assign, args=[agent, skill])
            process.start()
            threads.append(process)

        for process in threads:
            process.join()


    def restore_default_skills(self, agents):
        for agent in agents:
            for skill in agents.skills:
                self.add_a_skill(agent,skill)


    def keep_only_one_skill(self, agents, skill_to_keep):
        for agent in agents:
            for skill in agents.skills:
                if(skill != skill_to_keep):
                    self.add_a_skill(agent,skill_to_keep)

    def get_skill(self, dbid):
        return SkillManager.SkillModel(self._dorm.skill.get(dbid))





    








            

