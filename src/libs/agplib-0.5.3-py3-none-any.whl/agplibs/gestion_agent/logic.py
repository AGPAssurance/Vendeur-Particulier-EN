from agplibs.clients.fac import FonivaApiClient
from agplibs.clients.sac import SugarApiClient 
from agplibs.utils.sugar import Contact
from agplibs.utils.slack import log_on_slack
import sys
from pprint import pprint
import datetime
from datetime import datetime, date, timedelta
from dateutil.relativedelta import relativedelta


class GestionAgent():
    
    def __init__(self):
        
        self.fac_client = FonivaApiClient()
        self.sac_client = SugarApiClient()
        
        self.past_years = (datetime.now() - relativedelta(years=2)).strftime("%Y-%m-%d")
    
    
    def clear_foniva(self, dbid):
        """
            Delete all from foniva
        """
        
        fonivalist = self.fac_client.get_all(dbid)
        
        for i in fonivalist:
            
            self.fac_client.delete(i['number'], dbid)
      
     
            
    def get_agent_particulier(self, indicatif):
        
        return self.sac_client.get('Contacts', 
                            filters={"filter": [
                                {"source_secondaire_c": "Agent Particulier"},                                
                                {"phone_home": {"$starts":f"{indicatif}"}}
                            ]},
                            fields=['id', 'first_name', 'last_name', 'phone_home', 'statut_appel_c', 'date_modified', 'courriel_c', 'email1'], max_num=5000)
        
        
    def get_autres_statuts(self, indicatif):
        
        return self.sac_client.get('Contacts', 
                            filters={"filter": [
                                {"source_secondaire_c": "Autres Statuts"},                                
                                {"phone_home": {"$starts":f"{indicatif}"}},
                                {"last_date_autres_statuts_c": {"$lte":f"{self.past_years}"}}
                                
                            ]},
                            fields=['id', 'first_name', 'last_name', 'phone_home', 'statut_appel_c', 'date_modified', 'courriel_c', 'email1'], max_num=5000)
        
        
    def get_contacts_by_status(self, dbid, status):
        
        """
            filter by status in Foniva and return [custom,number,firstname,lastname]
        """
        status_contacts = []
        data_from = self.fac_client.get_all(dbid)
    
        for i in data_from:
            
            if i['status'] == status:
                
                status_contacts.append([i['custom'], i['number'], i['firstname'], i['lastname']])
        
        return status_contacts
        
        
    def cut_list(self, contact_list, nb_to_cut):
        
        """
            choose the array length
        """
        if len(contact_list) >= nb_to_cut:
            
            start = 0
            list_cuted = []
                
            for i in contact_list:
            
                list_cuted.append([i[0], i[1], i[2], i[3]])
                
                start += 1
                if start >= nb_to_cut:

                    return list_cuted
                
        else: 

            print('Not enough contact')
                   
        
    def transfer_foniva_contact(self, list_from, dbid_from, dbid_to):
        """
            Create to dbid and delete from dbid
        """
       
        for i in list_from:
            
            self.fac_client.delete(i[1], dbid_from)
            self.fac_client.post(querystring={"number": f"{i[1]}", "dbid": f"{dbid_to}", "custom": f"{i[0]}","firstname": f"{i[2]}", "lastname": f"{i[3]}"})
        
     
            
    
    def filtering_descending(self, contacts_list):
        
        return sorted(contacts_list, key=lambda d: d["date_modified"], reverse=True)
    
    
    def filtering_ascending(self, contacts_list):
        
        return sorted(contacts_list, key=lambda d: d["date_modified"])
        

    def create_to_foniva(self, contacts, dbid):
        
        for i in contacts:
            
            self.fac_client.post(querystring={"number": f"{i['phone_home']}", "dbid": f"{dbid}", "custom": f"{i['id']}","firstname": f"{i['first_name']}", "lastname": f"{i['last_name']}", "old_status": f"{i['statut_appel_c']}"})

    


    def call_status_to_empty(self, contacts):
        
        sugar_ids = []
        try:
            for i in contacts:
                
                sugar_ids.append(i['id'])
                
            self.sac_client.mass_update('Contacts', sugar_ids, 'statut_appel_c', '')
            
        except Exception as e:
            
            log_on_slack({"Jonathan": "UKXMF9952", "Mathieu" : "U01S1DWCPMH"}, f"Gestion Agent : {i}, {e} ")
            
            
     
        
        
    def reset_old_status(self, foniva_list):
        
        for i in foniva_list:
            
            if Contact.get_statut_appel_value(self.sac_client, i['custom']) == '':
                
                Contact.put_call_status(self.sac_client, i['custom'], i['old_status'])
                
                
    def mass_update_field_from_foniva(self, dbid, key, value ):
        foniva_ids = []
        
        for i in self.fac_client.get_all(dbid):  
            
            foniva_ids.append(i['custom'])
                    
        self.sac_client.mass_update('Contacts', foniva_ids, key, value)
    
        
        
    def mass_update_field_from_sugar(self, contacts, key, value):
        sugar_ids = []
        
        for i in contacts:  
            
            sugar_ids.append(i['id'])
                    
        self.sac_client.mass_update('Contacts', sugar_ids, key, value)
    
       
        
    def reset_email_validation(self, contacts):
        
        empty_email_ids = []
        
        for i in contacts:
                    
            if i['email1'] != '':
                
                empty_email_ids.append(i['id'])
                
        if len(empty_email_ids) != 0:
            
            self.sac_client.mass_update('Contacts', empty_email_ids, 'courriel_c', '')
            
                
