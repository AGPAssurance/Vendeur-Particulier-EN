from PureCloudPlatformClientV2.apis import AnalyticsApi

from agplibs.genesys.outbound import Outbound, GenesysApiClient 

import asyncio
import traceback
from dateutil import tz
from datetime import datetime

class Metrics:
    """Classe statique avec des constantes sur les métriques.
    """

    T_ABANDON = "tAbandon"
    N_OFFERED = "nOffered"
    T_ACD = "tAcd"
    O_SERVICE_LEVEL = "oServiceLevel"
    T_WAIT = "tWait"
    O_ALEERTING = "oAlerting"
    O_WAITING = "oWaiting"
    O_INTERACTIG = "oInteracting"

class CampaignData:
    """Encontène l'information d'une campagne.
    """

    def __init__(self, campaign, contacts):
        """CTOR
        """
        self.id = campaign.id
        self.contacts = contacts

    def __str__(self):
        return f"Nb Contacts  : {len(self.contacts)}"

class QueueData:
    """Encontène l'informations d'une queue
    """

    def __init__(self, row_result):
        """Constucteur principal
        """
        self.id = row_result["group"]["queueId"]

        self.nb_contacts_en_attente = 0
        self.max_waiting_time = 0

        for row in row_result["data"]:

            if "metric" in row and row["metric"] == Metrics.O_WAITING:
                self.nb_contacts_en_attente = row["stats"]["count"]

            if "observations" in row and row["observations"] is not None:
                self.max_waiting_time = self.__max_waiting_time(row["observations"])


    def __str__(self):
        return  str(self.nb_contacts_en_attente) + " " + str(self.max_waiting_time)

        
    def __utc_to_east(self, utc_date : datetime):
        """Convertie un objet de type datetime à un fuseau horaire de l'est.

        Args:
            utc_date (datetime): Date avec comme fuseau horaire UTC

        Returns:
            datetime: Date avec comme fuseau horaire EDT
        """

        from_zone = tz.gettz('UTC')
        to_zone = tz.gettz('America/New_York')
        utc = utc_date.replace(tzinfo=from_zone)
        east = utc.astimezone(to_zone)
        return east

    def __max_waiting_time(self, observations):
        """Calcule le temps d'attente le plus long.

        Args:
            observations (dict): Dictionnaire contenant des données sur l'observation.

        Returns:
            int : Le temps d'attente le plus long (en secondes).
        """
        
        current = datetime.now().replace(tzinfo=tz.gettz('America/New_York'))
        
        max_waiting_time = 0
       
        for obs in observations:
            observationDate =  self.__utc_to_east(obs["observation_date"])
            diff = (current - observationDate).total_seconds()
            if diff > max_waiting_time:
                max_waiting_time = diff
            
           
        return int(max_waiting_time)



class Context:

    def __init__(self):
        """CTOR principal
        """
        self.__data  = {}


    def get_data(self, key :  str): 
        # TODO : Write DOC
        """

        Args:
            key (str): [description]

        Raises:
            ValueError: [description]

        Returns:
            [type]: [description]
        """
        
        if(key is None or key.strip() == ""):
            raise ValueError("La valeur de `key` ne peut être vide ou ne référer à rien")

        if key not in self.__data:
            raise ValueError("La valeur de `key` n'est pas dans le dictionnaire.")

        return self.__data.get(key, None)


    def set_data(self, key : str, data):
        # TODO : Write DOC
        """

        Args:
            key (str): [description]
            data ([type]): [description]

        Raises:
            ValueError: [description]
        """
        
        if(data is None):
            raise ValueError("La valeur de `data` ne peut référer à rien.")

        self.__data[key] = data



       
class CampaignListener:
    """Simule un système de notifications en mettant à jour un contexte partagé.

    
    Note:
        Tous les appels sont synchrones et se font par des requêtes HTTP's.
    """

    def __init__(self, outbound : Outbound, campaigns_context : Context, campaigns=[]):

        self.__outbound = outbound
        self.__campaigns =  []
        self.__campaigns_context = campaigns_context

        for campaign in campaigns:
            self.add_campaign(campaign)

    def add_campaign(self, campaign):
        self.__campaigns.append(campaign)

        data = CampaignData(campaign, [])
        self.__campaigns_context.set_data(campaign.id, data)

    def remove_campaign(self, campaign):
        self.__campaigns.remove(campaign)


    async def async_set_contacts(self, campaign):
        contacts = await self.__outbound.async_get_all_contacts_from_a_contact_list(campaign.contact_list.id)

        #TODO : FIX THIS :( 
        if(contacts is not None):   
            data = CampaignData(campaign, contacts)
            self.__campaigns_context.set_data(campaign.id, data)
        #####

        
    async def listen(self, interval : float):
        """Met à jour le contexte partagé selon des intervales réguliers.

        Args:
            interval (float): Nombre de secondes entre chaque appel.

        Raises:
            ValueError : L'`interval` doit être > 0
            Exception : Le nombre de campagnes à écouter doit être suppérieur à 0.
        
        """

        if len(self.__campaigns) == 0: 
            raise Exception("Le nombre de campagnes à écouter doit être suppérieur à 0.")

        if  interval < 0:
            raise ValueError("L`'interval` doit être > 0")

        while True:
            
            await asyncio.gather(*[
                    self.async_set_contacts(campaign) for campaign in self.__campaigns
                ])

            await asyncio.sleep(interval)

class QueueListener:
    """Simule un système de notifications en mettant à jour un contexte partagé.

    Note:
        Tous les appels sont synchrones et se font par des requêtes HTTP's.
    """
    def __init__(self, genac : GenesysApiClient, queues_context : Context, queues=[]):
        """CTOR principal

        Args:
            genac (GenesysApiClient): Cient PureCloud
            queues (list) : Liste des files à écouter
            queues_context (Context): Contexte partagé
        """
        self.__analytics_api = AnalyticsApi(genac.access)

        self.__predicates = []
        self.__queues_context = queues_context

        for queue in queues:
            self.add_queue(queue.id)




    def __build_query(self):
        """Construit la requête selon les files écoutées

        Returns:
            dict: Un dictionnaire sous la forme d'un prédicat PureCloud
        """

        return {
                    "filter": {
                    "type": "and",
                    "clauses": [{
                        "type": "or",
                        "predicates": self.__predicates
                    }],
                    "predicates": [
                    {
                        "type": "dimension",
                        "dimension": "mediaType",
                        "operator": "matches",
                        "value": "voice"
                    }
                    ]
                    },
                    "metrics": [
                    "oWaiting"
                    ],
                    "detailMetrics": [
                    "oWaiting"
                    ]
        }



    def add_queue(self, queue_id : str):
        """Ajoute une file aux files écoutées

        Args:
            queue_id (str): ID de la queue à ajouter
        """
        self.__predicates.append({
            "type"  : "dimension",
            "dimension" : "queueId",
            "operator" : "matches",
            "value" : queue_id
        })

    def remove_queue(self, queue_id : str):
        """Retire une file des files écoutées

        Args:
            queue_id (str): ID de la queue à supprimer
        """
        self.__predicates.remove(queue_id)


    def __parse_data(self, data):
        """Sérialise le fichier JSON en QueueData

        Args:
            data (dict): Dictionnaire contenant l'informations
        """
        
        queues_data = []
        for result in data["results"]:
            queues_data.append(QueueData(result))
        
        return queues_data


    async def listen(self, interval : float):
        """Met à jour le contexte partagé selon des intervales réguliers.

        Args:
            interval (float): Nombre de secondes entre chaque appel.

        Raises:
            ValueError : L'`interval` doit être > 0
            Exception : Le nombre de files à écouter doit être suppérieur à 0.
        
        """

        if len(self.__predicates) == 0: 
            raise Exception("Le nombre de files à écouter doit être suppérieur à 0.")

        if  interval < 0:
            raise ValueError("L`'interval` doit être > 0")

        while True:
            


            body = self.__build_query()

            response = self.__analytics_api.post_analytics_queues_observations_query(body)
            
            queues_data  = self.__parse_data(response.to_dict()) #Parse the response

            for queue_data in queues_data:
                self.__queues_context.set_data(queue_data.id, queue_data)

            await asyncio.sleep(interval)


async def show_update(queues_context : Context):
    """Méthode statique 

    Args:
        queues_context (Context): [description]
    """

    while True:
        try: 
            data = queues_context.get_data("1d3a1e80-d88e-4c2f-b09d-91c2de4ecead")

            if data is not None:
                print("NB CONTACTS : " , data.nb_contacts_en_attente)
                print("TEMPS D'ATTENTES : ", data.max_waiting_time )

        except Exception as e:
            traceback.print_exc()

        await asyncio.sleep(5)


async def main():

    queues_context = Context()
    
    #Base Listener
    listener  = QueueListener("5b5eb6df-e487-4564-a366-3e3f9de4c231", "RDzlsUEQKHb5ioOOtSA8nS4IT7ILGC3J08TB5NHXCQc", 10, queues_context)
    listener.add_queue("1d3a1e80-d88e-4c2f-b09d-91c2de4ecead")
    listener.add_queue("a0cf9c57-4754-407b-b361-8d3c64d99e73")

    ts_queue_listener = asyncio.create_task(listener.listen())
    ts_show_update = asyncio.create_task(show_update(queues_context))


    # DO BEAUTIFULL THINGS :)
    await ts_queue_listener
    await ts_show_update


if __name__ == '__main__':
    asyncio.run(main())  


