DATA_QUEUES_WAITING_SC_FR = {
    "Debordement_Reception" : {
         "max_waiting_time": 480,
        "nb_waiting_calls": 5,
    },

    "Retention_Reception"  : {
        "max_waiting_time": 480,
        "nb_waiting_calls": 4,
    },

     "Particuliers_SC" : {
        "max_waiting_time": 240,
        "nb_waiting_calls": 4,
     },

     "Part_Retention" : {
        "max_waiting_time": 240,
        "nb_waiting_calls": 4
     },


     "Part_Retour_Agent_SC" : {
        "max_waiting_time": 180,
        "nb_waiting_calls": 2,
     },

     "Part_Soum_NA" : {
        "max_waiting_time": 240,
        "nb_waiting_calls": 2,
    },
    
    "Reception_SC_Habit"  : {
        "max_waiting_time": 420,
        "nb_waiting_calls": 3
    }
}

DATA_QUEUES_WAITING_SC_ENG = {
    
    "Anglais_SC_Particuliers" : {
        "nb_waiting_calls": 2,
        "max_waiting_time": 480
    },

    "Anglais_Soumission_NA" : {
        "nb_waiting_calls": 2,
        "max_waiting_time": 240
    },

    "Anglais_Retour_Agent_SC" : {
          "nb_waiting_calls": 2,
        "max_waiting_time": 180
    },
      
    "Anglais_Retention" : {
       "nb_waiting_calls": 2,
        "max_waiting_time": 300
    }
 
}


class GenesysCampaign:
    """
        Classe statique avec de l'informations sur les campagnes.
    """
    C_AGENT_PARTICULIER = "C.AgentParticulier"
    C_AUTRES_STATUTS = "C.AutreStatut"
    C_NSF = "C.NSF"
    C_VENDEUR_PARTICULIER = "C.VendeurParticulier"
    C_SOUMISSION_DECLINEE = "C.SoumissionsDeclinees"
    C_CONCOURS = "C.Concours"
    C_SUIVI_DE_VENTE = "C.SuiviDeVente"
    C_RDV = "C.RendezVous"
    C_PREVIEW_CONTACTS = "C.PreviewContacts"
    C_PREVIEW_SNV = "C.PreviewSNV"
    C_PREVIEW_SUIVI_DE_VENTE = "C.PreviewSuiviDeVente"
    C_SNV = "C.SoumissionsNonVendues"
    C_LONGUE_ATTENTE = "C.TransfertLongueAttente"
    C_RAPPEL_NA = "C.Rappel.NA"
    C_CLIC_ASSURE = "C.ClicAssure"
    C_SOUMISSION_WEB = "C.SoumissionWeb"

