import abc


import json
from datetime import datetime
from agplibs.clients.genac import GenesysApiClient
from PureCloudPlatformClientV2.apis import NotificationsApi
from PureCloudPlatformClientV2 import ChannelTopic

import websockets
import asyncio
from pprint import pprint
import  traceback 
import logging
from dateutil import tz


## TODO : add[delete_outbound_contactlist_contacts,put_outbound_contactlist, put_outbound_contactlist_contact]

class TopicName:
    """Constantes statiques des noms des topics.
    """

    META_DATA = "channel.metadata"
    QUEUES_CONVERSATIONS_CALLS = "v2.routing.queues.{id}.conversations.calls"
    QUEUES_OBESERVATIONS = "v2.analytics.queues.{id}.observations"

    def ___init__(self):
        pass

    
class MediaType:
    """Constantes statiques des MediaTypes.
    """

    VOICE = "voice"

    def __init__(self):
        pass

class Participant:

    class Purpose:
        IVR = "ivr"
        ACD = "acd"
        CUSTOMER = "customer"


    class State:
        CONNECTED = "connected"
        TERMINATED = "terminated"

    def __init__(self, participant):
        self.id = participant["id"]
        self.state = participant["state"]
        self.purpose = participant["purpose"]
        self.connected_time = None

        if "connectedTime" in participant:
            self.connected_time = self.__utc_to_east(participant["connectedTime"])

    def __utc_to_east(self, utc_date):

        from_zone = tz.gettz('UTC')
        to_zone = tz.gettz('America/New_York')
        utc = datetime.strptime(utc_date, "%Y-%m-%dT%H:%M:%S.%fZ")
        utc = utc.replace(tzinfo=from_zone)
        east = utc.astimezone(to_zone)
        return east

    def __eq__(self, other):

        if not isinstance(other, Participant):
            return False

        return self.id == other.id

    def __hash__(self):
        return hash(self.id)

    

class QueueData:
    """Encontène l'informations d'une queue et ses participants
    """

    def __init__(self):
        """Constucteur principal
        """
        self.__participants = set([]) # Empty set

    def update_participants(self, participants : list):

        for p in participants:
            if p.state  == Participant.State.CONNECTED and p not in self.__participants:
                self.__participants.add(p)
            elif p.state == Participant.State.TERMINATED and p in self.__participants:
                self.__participants.remove(p)

    def __str__(self):
        return  str(self.nb_contacts_en_attente) + " " + str(self.max_waiting_time)
    

    @property
    def nb_contacts_en_attente(self):
        return len(self.__participants)

    @property 
    def max_waiting_time(self):
        current = datetime.now().replace(tzinfo=tz.gettz('America/New_York'))
        max_waiting_time = 0
        for p in self.__participants:
            diff = (current - p.connected_time).total_seconds()
            if diff > max_waiting_time:
                max_waiting_time = diff
            
           
        return int(max_waiting_time)


class QueuesContext:
    """Encontène l'information de plusieurs queues.

    En plus de contenir l'information, la classe est responsable de la mise à jour
    des données.

       #TODO : Rendre la classe dynamique ou donner la responsabilité à la classe QueueData
    """

    def __init__(self):
        """Const principal
        """
        self.__queues_data = {}


    def get_queue_data(self, queue_id : str):
        """Récupère l'informations d'une queue.

        Args:
            queue_id (str): ID d'une queue.

        Returns:
            QueueData : L'information de la queue référencé par l'`id`.
        """

        return self.__queues_data.get(queue_id, None)


    def set_queue_data(self, queue_id : str, queue_data : QueueData):

        self.__queues_data[queue_id] = queue_data



class ContextContainer:
    """Conteneur contenant les différents contextes du LiveData
    """

    def __init__(self):
        """Const. principal
        """
        self.__queues_context = QueuesContext()

    @property
    def queues_context(self):
        """Permet d'obtenir le contexte des queues.

        Returns:
           QueuesContext : Le contexte des queues.
        """
        return self.__queues_context
        

class Topic(ChannelTopic):
    """Classe abstraite implémentant un topic.

    Note : 
        Chaque Topic est lié spécifiquement à une queue.
    """
    
    
    def __init__(self, channel_uri : str):
        """Abstraction d'un topic PureCloud (endpoint de Notifications)  

        Args :
            channel_uri (str) : URI du 'topic'.
        
        Raises:
              ValueError : Si le `channel_uri` est None ou vide.   
              ValueError : Si le `dispatch` est None.      
        """

        if(channel_uri is None or channel_uri.strip() == ""):
            raise ValueError("Le channel_uri ne peut être vide ou référer à None")

        ChannelTopic.__init__(self)

        self.id = channel_uri 


    def to_dict(self):
        """Retourne le topic sous forme de dictionnaire.

        Returns:
            dict: Le topic sous forme de dictionnaire.
        """

        return {
            "id" : self.id
        }

    
    def dispatch(self, context_container : ContextContainer, message):
        raise NotImplementedError("La méthode dispatch doit être implémentée.")



class TopicQueuesConversationsCall(Topic):
    """Classe concrètre.

    Ce topic permet d'obtenir l'information sur le temps d'attente des clients dans chaque queue.
    """
    
    def __init__(self, queue_id : str):
        """Constructeur principal

        Args:
            queue_id (str): ID d'une queue
        """

        #TODO  Do DOC

        Topic.__init__(self, TopicName.QUEUES_CONVERSATIONS_CALLS.format(id=queue_id))
        self.__queue_id = queue_id

    class Metric:

        MAX_WAITING_TIME = "max_waiting_time"

   
    class Message:

        def __init__(self, message):
            participants = message["eventBody"]["participants"]
            self.__participants = list(
                                    filter(lambda p : p.purpose == Participant.Purpose.ACD,
                                       map(lambda p : Participant(p) , 
                                         participants)
                                    )
                                )
        @property
        def participants(self):
            return self.__participants


    def dispatch(self, context_container : ContextContainer, message):

        pprint(message)

        message = TopicQueuesConversationsCall.Message(message)
        
        #OlD QUEUE_DATA
        queue_data = context_container.queues_context.get_queue_data(self.__queue_id)

        if queue_data is None:
            queue_data = QueueData()
          
        queue_data.update_participants(message.participants)
        context_container.queues_context.set_queue_data(self.__queue_id,queue_data)
        
            

class TopicQueuesObservationsCall(Topic):

    class Metrics:

        T_ABANDON = "tAbandon"
        N_OFFERED = "nOffered"
        T_ACD = "tAcd"
        O_SERVICE_LEVEL = "oServiceLevel"
        T_WAIT = "tWait"
        O_ALEERTING = "oAlerting"
        O_WAITING = "oWaiting"
        O_INTERACTIG = "oInteracting"

 
    class Message:

        def __init__(self, message):
            self.mediaType = message["eventBody"]["group"]["mediaType"]
            self.data =  list(map(lambda data: data, message["eventBody"]["data"]))

        def get_stats(self, metric_name : str):

            stats = None

            for data in self.data:
                for metric in data["metrics"]:
                    if metric["metric"] == metric_name:
                        stats = metric["stats"]

            return stats

    
    def __init__(self, queue_id : str):

        #TODO  Do DOC

        Topic.__init__(self, TopicName.QUEUES_OBESERVATIONS.format(id=queue_id))
        self.__queue_id = queue_id



    def dispatch(self, context_container : ContextContainer, message):

        pprint(message)
        
        message = TopicQueuesObservationsCall.Message(message)

        if message.mediaType == MediaType.VOICE:

            o_waiting_stats = message.get_stats(TopicQueuesObservationsCall.Metrics.O_WAITING)
            if o_waiting_stats != None:
                context_container.queues_context.update_nb_contacts_en_attente(self.__queue_id, int(o_waiting_stats["count"]))



class Notifications:

    """Gestionnaire de canaux Purecloud

        Les notifications Purecloud utilise une connexion bidirectionnel 
        implémentant ainsi le protocole WebSocket (une abstrc. au TCP).

        (Doc. externe) https://developer.genesys.cloud/api/rest/v2/notifications/notification_service

        Important: 
            - Purecloud limite à un maximum de de 20 canaux par utilisateur et application.
            - Un canal reste actif pour 24 heures. Il faut se réinscrire aux 'topics'.
            - Il y a une limitation de 10000 'topics' par socket. 
            - Chaque canal est limité à un WebSocket à la fois.
        
        Note :
            Une instance de la classe notification représente 1 websocket.

    """

    def  __init__(self, client_id : str, client_secret : str, context_container : ContextContainer):

        #TODO : Documenter le constructeur
        
        self.__genac = GenesysApiClient(client_id, client_secret)
        self.__notification_api = NotificationsApi(self.__genac.access)
        self.__canal = self.__notification_api.post_notifications_channels() # Canal 
        
        self._subscribtions = {} # Map de la liste des topics inscrit.
        self._subscribtions[TopicName.META_DATA] = None
        
        self.logger = logging.getLogger("NOTIFICATIONS")

        self.__context_container = context_container # Contexte partagé par l'instance


    def is_subscribed(self, topic_name : str):
        """Retourne vrai si l'instance est inscrite au topics

           Returns: 
                bool: Retourne True si l'instance est inscrite au topic, False autrement.

           Raises:
                ValueError : Si le `topic_name` est vide ou ne réfère à rien.
        """

        if(topic_name is None or topic_name.strip() == ""):
            raise ValueError("Le `topic_name` ne peut être vide ou ne référer à rien.")

        return topic_name in self._subscribtions

    def subscribe_to_topics(self, topics : list):
        """Enregistre le canal à une liste de topics.

        Returns:
            bool: Retourne True si l'enregistrement est un succès, False autrement.

        Raises:
            ValueError : Si la liste `topics` est None ou vide.
        """

        if(topics is None or len(topics) == 0):
            raise ValueError("La liste de topics ne peut être vide ou référer à None")

        for topic in topics:
            self._subscribtions[topic.id] = topic
        
        json_topics = list(map(lambda t: t.to_dict(), topics ))
        self.__notification_api.put_notifications_channel_subscriptions(self.__canal.id, json_topics)

            

        
    async def listen(self):
        """Ouvre un web socket et écoute sur les 'topics' enregistrées
        """ 

        self.logger.info("START LISTENNING")

        async with websockets.connect(self.__canal.connect_uri) as websocket:

            async for message in websocket:

                message = json.loads(message)
                topic_name = message['topicName'].lower()

                if topic_name == TopicName.META_DATA:
                    self.logger.info(f"HEARTBEAT {datetime.now()}")
                elif not self.is_subscribed(topic_name):
                    self.logger.error("Une notification non attendue a été déclenchée.")
                else:
                    self.logger.debug(f"Message reçu du topic : {self._subscribtions.get(topic_name)}")
                    self._subscribtions.get(topic_name).dispatch(self.__context_container, message)

    # TODO : Close a connection to a web socket

    # TODO : Subscribe to a specific channel 

    # TODO : Unsubscribe to a specific channel 


async def show_update(context_container : ContextContainer):

    while True:
        try: 
            data = context_container.queues_context.get_queue_data("1d3a1e80-d88e-4c2f-b09d-91c2de4ecead")

            if data is not None:
                print("NB CONTACTS : " , data.nb_contacts_en_attente)
                print("TEMPS D'ATTENTES : ", data.max_waiting_time )

        except Exception as e:
            traceback.print_exc()

        await asyncio.sleep(5)

# Call à l'API

async def main():

    #Base Listener
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s')

    context_container = ContextContainer() # Contextes partagées !Attention

    notifications = Notifications("5b5eb6df-e487-4564-a366-3e3f9de4c231", "RDzlsUEQKHb5ioOOtSA8nS4IT7ILGC3J08TB5NHXCQc", context_container)
    
    topics = [
        TopicQueuesConversationsCall("1d3a1e80-d88e-4c2f-b09d-91c2de4ecead"), # Débordement réception
    ]

    notifications.subscribe_to_topics(topics)

    # TASKS INIT
    ts_notification_listener = asyncio.create_task(notifications.listen())
    ts_show_update = asyncio.create_task(show_update(context_container))
    

    # DO BEAUTIFULL THINGS :)
    await ts_notification_listener
    await ts_show_update


asyncio.run(main())  
