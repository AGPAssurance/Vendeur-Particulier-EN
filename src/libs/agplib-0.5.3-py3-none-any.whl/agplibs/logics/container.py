from agplibs.clients.sac import SugarApiClient
from agplibs.clients.dorm import DormApiClient
from agplibs.logics.tag import Tagger
from agplibs.utils.utils import chunks
from datetime import datetime, timedelta
from queue import Queue
import time
import traceback
import logging


class TimeHelper:

    """
        Classe statique contenant des méthodes utiles à la gestion du temps
    """
    @staticmethod
    def format(datetime, audit):
        return datetime.strftime("%Y-%m-%d %H:%M:%S") if audit else datetime.strftime("%Y-%m-%dT%H:%M:%S")


class ContactModel:

    """
        Modèle regroupant les différentes informations d'un entité sugar 
    """

    def __init__(self,  contact_dict):

        if(contact_dict is None or contact_dict == {}):
            raise Exception(
                "Le dictionnaire ne peut être vide ou correspondre à None")

        if (contact_dict.get("id", "").strip() == ""):
            raise Exception(
                "Le dictionnaire doit contenir un champ id et ne peut être vide"
            )

        if("phone_home" in contact_dict):
            contact_dict["phone_home"] = contact_dict["phone_home"].replace(
                "-", "")

        self.contact = contact_dict
        self.opps = []
        self.transactions = []
        self.polices = []
        self._events = Queue()

    def insert_events(self, action):
        self._events.put(action)

    def get_last_event(self):
        return self._events.get()

    @property
    def have_events(self):
        return not self._events.empty()

    @property
    def id(self):
        return self.contact["id"]

    @property
    def phone_home(self):
        return self.contact.get("phone_home", "")

    @property
    def first_name(self):
        return self.contact.get("first_name", "")

    @property
    def last_name(self):
        return self.contact.get("last_name", "")

    @property
    def source_secondaire(self):
        return self.contact.get("source_secondaire_c", "")

    @property
    def source_principale(self):
        return self.contact.get("source_principale_c", "")

    @property
    def opps_ids(self):
        return map(lambda opp: opp.get("id"),  self.opps)

    def __repr__(self):
        return f"{self.id}"

    def __str__(self):
        return f"{self.id}"

    def __eq__(self, other):
        return self.contact.get("phone_home", None) == other.contact.get("phone_home", None)

    def __hash__(self):
        return hash(self.contact.get("phone_home", None))


class LinkRessource:
    POLICE = "POLICE"
    TRANSACTION = "TRANSACTION"
    SOUMISSION = "SOUMISSION"


class LinksToContact:

    """Classe agissant comme conteneur de contacts"""

    AUDITS_LOGGER = "AUDITS_LOGGER"

    def __init__(self,
                 sac: SugarApiClient,
                 dorm: DormApiClient,
                 opps_dicts=None,
                 polices_dicts=None,
                 contacts_dicts=None,
                 contacts=None,
                 fields=None,
                 audits_fields=[]):

        self.contacts = []
        self.sac = sac
        self.dorm = dorm
        self.audits_fields = audits_fields

        if(contacts is not None):
            contacts = filter(lambda c: not self.__contact_exist(c), contacts)
            self.contacts.extend(contacts)

        if(contacts_dicts is not None):
            models = self.__dicts_to_model(contacts_dicts)
            contacts = list(
                filter(lambda c: not self.__contact_exist(c), models))
            self.contacts.extend(contacts)

        if(opps_dicts is not None):
            self.contacts = self.get_contacts_by_opportunities(opps_dicts, fields)

        if(polices_dicts is not None):
            self.contacts = self.get_contacts_by_polices(polices_dicts, fields)

        self.__sw_ressources = {
            "POLICE": self.__set_polices_links_to_contacts,
            "TRANSACTION":  self.__set_transactions_links_to_contacts,
            "SOUMISSION": self.__set_soumissions_links_to_contacts
        }

    @property
    def ids(self):
        return list(map(lambda c: c.id, self.contacts))

    @property
    def opps_ids(self):
        opps_ids = []
        for contact in self.contacts:
            opps_ids.extend(list(map(lambda o: o["id"], contact.opps)))
        return opps_ids

    def mass_update(self, field_name, field_value):
        for chunk in chunks(self.ids, 500):
            self.sac.mass_update("Contacts", chunk, field_name, field_value)

    def tag(self, **kwargs):
        Tagger.bulk_create(self.sac, self.dorm, self.ids, **kwargs)

    def chunks(self, lst, n):
        for i in range(0, len(lst), n):
            yield lst[i:i + n]

    def filter(self, method, args=None):

        if(args is not None):

            return LinksToContact(self.sac,
                                  self.dorm,
                                  contacts=list(
                                      filter(lambda c: method(
                                          c, args), self.contacts)
                                  )
                                  )

        return LinksToContact(self.sac,
                              self.dorm,
                              contacts=list(
                                  filter(method, self.contacts)
                              )
                              )

    def listen(self, interval: int, actions: dict, final=None,
               from_date=None, to_date=None, update_contact=True):
        """ Écoute les audits et effectue les actions

            interval : int
            Nb de secondes entre chaque fetch

            actions : {
                "nom du champ" : callable(contact, audit), 
                ...
            }, 
            Dictionnaire mappant chaque changement sur un champ
            et une action prennant en paramètre le contact et l'audit

            from_date : datetime
            Lors du premier appel, positionne la date de début

            to_date : datetime
            Lors du premier appel, positionne la date de fin

            update_contact : Met à jour les infos des contacts déjà présent dans le conteneur

        """

        audit_logger = logging.getLogger(self.AUDITS_LOGGER)
        if(from_date is None):
            from_date = datetime.now()

        if(to_date is None):
            to_date = datetime.now()

        while True:
            try:
                time.sleep(interval)
                to_date = datetime.now()
                audit_logger.debug(
                    f"FETCH AUDIT BETWEEN {from_date} - {to_date}")

                audits = self.fetch_audits(from_date, to_date)
                if len(audits) > 0:
                    self.__set_audits_to_contacts(audits, update_contact)
                    self.do_actions(actions)
                    if(final is not None):
                        final(self)
                    from_date = to_date + timedelta(seconds=1)

                elif(final is not None):
                    final(self)

            except Exception as e:
                log = traceback.format_exc()
                return log, from_date, to_date

    def do_actions(self, actions: dict):

        for contact in self.contacts:

            while contact.have_events:
                event = contact.get_last_event()
                name = event["field_name"]
                if name in actions.keys():
                    actions[name](contact, event)

        return self

    def to_dicts(self):
        return list(map(lambda c: c.contact, self.contacts))

    def include(self, ressource_name, fields=None):
        callback = self.__sw_ressources.get(ressource_name, None)

        if(callback is None):
            raise Exception(
                f"La ressource {ressource_name} not found'existe pas")


        callback(fields)

        return self

    def mix_lists(self, o, ratio):

        if(not isinstance(o, LinksToContact)):
            raise ValueError(
                f"L'objet à comparer doit être de type {type(self)}")

        count_intact = round(len(o.contacts) * ratio)
        calcul = round(len(self.contacts) / count_intact)
        index = calcul

        for i in o.contacts[:count_intact]:
            self.contacts.insert(index, i)
            index += calcul

        # Remove duplicates
        self.contacts = list(dict.fromkeys(self.contacts))

        return self

    def __add__(self, o):
        if(not isinstance(o, LinksToContact)):
            raise ValueError(
                f"L'objet à comparer doit être de type {type(self)}")

        return LinksToContact(self.sac, self.dorm, contacts=list(set(self.contacts + o.contacts)))

    def __max_list(self, l1, l2):

        if(len(l1) > len(l2)):
            return l1, l2

        return l2, l1

    def __contact_exist(self, contact):

        if(not isinstance(contact, ContactModel)):
            raise Exception(
                f"Le contact {contact} n'est pas de type {type(ContactModel)}")

        return contact in self.contacts

    def __find_contact(self, contact_dict):

        for contact in self.contacts:
            if contact_dict["id"] == contact.id:
                return contact

        return None

    def __dicts_to_model(self, contacts_dicts):
        return list(map(lambda contact_dict: ContactModel(contact_dict), contacts_dicts))

    def __exist_in_bucket(self, item, bucket):
        ids = list(map(lambda i: i["id"], bucket))
        id = item.get("id", None)

        return id in ids

    def __set_soumissions_links_to_contacts(self, fields=None):
        chunks = self.chunks(self.contacts, 500)
        responses = []

        for chunk_contacts in chunks:

            responses.extend(
                self.sac.bulk_get_by_link('Contacts', list(map(lambda contact: contact.id, chunk_contacts)), 'opportunities', fields))

        for response, contact in zip(responses, self.contacts):
            if(len(response["records"]) > 0):
                for record in response["records"]:
                    if ("id" in record and
                            not self.__exist_in_bucket(record, contact.opps)):
                        contact.opps.append(record)

    def __set_polices_links_to_contacts(self, fields=None):
        chunks = self.chunks(self.contacts, 500)
        responses = []

        for chunk_contacts in chunks:

            responses.extend(
                self.sac.bulk_get_by_link('Contacts', list(map(lambda contact: contact.id, chunk_contacts)), 'po_polices_contacts'))

        for response, contact in zip(responses, self.contacts):
            if(len(response["records"]) > 0):
                for record in response["records"]:
                    if ("id" in record and
                            not self.__exist_in_bucket(record, contact.polices)):
                        contact.polices.append(record)

    def __set_transactions_links_to_contacts(self, field=None):
        chunks = self.chunks(self.contacts, 500)
        responses = []

        for chunk_contacts in chunks:

            responses.extend(
                self.sac.bulk_get_by_link('Contacts', list(map(lambda contact: contact.id, chunk_contacts)), 'calls'))

        for response, contact in zip(responses, self.contacts):
            if(len(response["records"]) > 0):
                for record in response["records"]:
                    if ("id" in record and
                            not self.__exist_in_bucket(record, contact.transactions)):
                        contact.transactions.append(record)

    def __set_audits_to_contacts(self, audits: list, update_contact=True):
        """ Ajoute une liste d'évènement aux contacts selon une liste d'audits

            audits : list(dict)
            Liste de dictionnaire d'audits

            Si Vrai, met à jour les contacts déjà existant       
        """

        chunks = self.chunks(audits, 500)
        responses = []

        for chunk_audits in chunks:
            responses.extend(
                self.sac.bulk_get(
                    "Contacts",
                    list(map(lambda a: a["contact_id"], chunk_audits)),
                    [
                        "id",
                        "phone_home",
                        "first_name",
                        "last_name",
                        "source_principale_c",
                        "source_secondaire_c"
                    ]
                ))

        for contact_dict, audit in zip(responses, audits):

            contact = self.__find_contact(contact_dict)

            if contact is None:
                contact = ContactModel(contact_dict)
                self.contacts.append(contact)
            elif update_contact:
                contact.contact = contact_dict

            contact.insert_events(audit)

    def fetch_audits(self, start_time: datetime, end_time: datetime):
        """
            Récupère une liste d'audits selon les modifications faites sur les champs
        """

        if start_time > end_time:
            raise Exception(
                "Le paramètre start_time ne peut être plus grand que end_time")

        start_time = TimeHelper.format(start_time, True)
        end_time = TimeHelper.format(end_time, True)

        audits = []

        for audit in self.audits_fields:

            audits.extend(self.sac.get_audits(
                "Contacts",
                from_date=start_time,
                to_date=end_time,
                field_name=audit
            ))

        return audits

    def get_contacts_by_polices(self, polices_dicts, fields=None):
        chunks = self.chunks(polices_dicts, 500)
        responses = []

        for chunk_polices in chunks:
            responses.extend(
                self.sac.bulk_get('Contacts', list(map(lambda police: police["po_polices_contactscontacts_ida"], chunk_polices)), fields))

        # Dict
        contacts = {}

        for record, police_dict in zip(responses, polices_dicts):
            if "id" in record:
                contact = ContactModel(record)

                if(contact.id not in contacts):
                    contacts[contact.id] = contact
                else:
                    contact = contacts[contact.id]

                contact.polices.append(police_dict)

        return list(contacts.values())

    def get_contacts_by_opportunities(self, opps_dicts, fields=None):
        chunks = self.chunks(opps_dicts, 500)
        responses = []

        for chunk_opps in chunks:
            responses.extend(
                self.sac.bulk_get_by_link('Opportunities', list(map(lambda opp: opp["id"], chunk_opps)), 'contacts', fields))

        # Dict
        contacts = {}

        for response, opp_dict in zip(responses, opps_dicts):
            if(len(response["records"]) > 0):
                record = response["records"][0]
                contact = ContactModel(record)

                if(contact.id not in contacts):
                    contacts[contact.id] = contact
                else:
                    contact = contacts[contact.id]

                contact.opps.append(opp_dict)

        return list(contacts.values())

