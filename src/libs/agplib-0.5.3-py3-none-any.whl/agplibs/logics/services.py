import logging
import os
import sys
import random
import subprocess
import threading
import time
import psutil
import random
import json

from datetime import date, datetime, timedelta
from agplibs.utils.slack import log_on_slack
from agplibs.clients.dorm import DormApiClient



class Process:

    def exec(self):
        raise Exception("Must be override")


class Service:

    """
        Define a service that run separately on its own thread.
    """

    def __init__(self, dorm, process, name):

        self.dorm = dorm

        if(not isinstance(process, Process) or process == None):
            raise Exception("A process need to implement the exec method.")

        self.name = self._format_name(name)

        if(len(sys.argv) > 1):
            
            commands = set(sys.argv[1:])
            
            if "-s" in commands:
                 self.stop_services()

        else:

            self._add_process_to_env()
            process.exec()
    

    def _format_name(self, name):
        return name[:-3].upper()


    def _add_process_to_env(self):
        pid = os.getpid()
        self.dorm.create_service_identity({"name" : self.name, "pid" :  pid})


    def stop_services(self):
        instances =  self.dorm.get_service_identities(self.name)
        for instance in instances:
            pid = instance["pid"]
            if(self.name == instance["name"] and pid != "" and pid != None):
                try:
                    os.kill(int(pid), 9)
                    print(f"KILL PID {pid}")
                except:
                    print(f"PID {pid} of services is not currently running on this instance")
                    self.dorm.delete_service_identity(pid)






        

CHANNEL_LIST = {"Mathieu" : "U01S1DWCPMH"}



class UnkillableService(Process):

    def exec(self):
        while True: 
                print('I wont stop even if you kill me')
                time.sleep(5) 





         

