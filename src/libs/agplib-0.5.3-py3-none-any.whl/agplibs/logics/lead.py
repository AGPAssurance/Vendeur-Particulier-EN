from typing import Tuple
from agplibs.clients.fac import FonivaApiClient
from agplibs.clients.sac import SugarApiClient
from  agplibs.utils.sugar import  Contact
from  agplibs.utils.models import  ContactModel
from agplibs.utils.foniva import Campaign



class LeadModel: 

    class Status:
        NOUVEAU_LEAD = 0
        LEAD_EXISTANT = 1
        LEAD_MULTIPLE = 2


    def __init__(self, lead_dict) -> None:
        self.first_name = lead_dict.first_name
        self.last_name = lead_dict.last_name
        self.phone_number = lead_dict.phone_number
        self.email = lead_dict.email
        self.callback_date = lead_dict.callback_date
        
    

class LeadMaper:

    def __init__(self, sac : SugarApiClient, fac : FonivaApiClient):
        self.__sac = sac
        self.__fac = fac


    
    def map_lead_to_sugar_contact(self, lead):
        """
            Converti un lead Sugar en modèle contact du CRM Sugar
        """
        model = ContactModel()

        model.set_first_name(lead.first_name)
        model.set_last_name(lead.last_name)
        model.set_phone_home(lead.phone_number)
        model.set_email(lead.email)

        return model

    
    def get_contact(self, lead, fields=["id"]) -> Tuple[LeadModel.Status, ContactModel]:


        ids  = Contact.get_ids_by_phone(self.__sac, phone_home=lead.phone_number)
        
        status = LeadModel.Status.NOUVEAU_LEAD
        first = None

        if(len(ids) == 1):
            id = ids[0]["id"]
            first = self.__sac.get("Contacts", id=id, fields=fields)[0]
            status = LeadModel.Status.LEAD_EXISTANT

        elif(len(ids) > 1):
            id = ids[0]["id"]
            first = self.__sac.get("Contacts", id=id, fields=fields)[0]
            status = LeadModel.Status.LEAD_MULTIPLE
        
        return (status, first)

    
    def integration_to_fonvia(self, lead, dbid, sugar_id=None):

        query_string = {"number": f"{lead.phone_number}", 
                        "dbid": f"{dbid}", 
                        "firstname": f"{lead.first_name}",
                        "lastname" : f"{lead.last_name}",
                        "custom" : sugar_id,
                        "status" : "CALLBACK",
                        "callback_date" : {lead.callback_date.strftime("%Y-%m-%d %H:%M:%S")}}

        if(sugar_id != None):
            query_string["custom"] = sugar_id

        if Campaign.is_phone_exist(self.__fac, lead.phone_number, dbid):
            self.__fac.delete(lead.phone_number, dbid)

        
        self.__fac.post(querystring=query_string)

    
    def integration_to_sugar(self, lead):
        raise Exception("La méthode n'est pas implémentée")


