class GoogleCalendarClient:

    def __init__(self, creds_dir, calendar_env):

        # If modifying these scopes, delete the file token.pickle.
        self.SCOPES = ['https://www.googleapis.com/auth/calendar']
        self.creds = None
        self.service = None
        
        self.calendar_env = calendar_env
        self.pickle_path = f"{creds_dir}/token.pickle"
        self.creds_path = f"{creds_dir}/credentials.json"

        self.google_auth()



    def google_auth(self):
        if os.path.exists(self.pickle_path):
            with open(self.pickle_path, 'rb') as token:
                self.creds = pickle.load(token)

        if not self.creds or not self.creds.valid:
            if self.creds and self.creds.expired and self.creds.refresh_token:
                self.creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file(self.creds_path, self.SCOPES)
                self.creds = flow.run_local_server(port=0)
            # Save the credentials for the next run
            with open(self.pickle_path, 'wb') as token:
                pickle.dump(self.creds, token)
        try:
            self.service = build('calendar', 'v3', credentials=self.creds)

        except Exception as e:
            print(e)