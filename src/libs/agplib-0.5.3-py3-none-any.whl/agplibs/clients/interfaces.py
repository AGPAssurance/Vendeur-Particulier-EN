import abc
from datetime import datetime
import requests
import json
import logging
urllib3_logger = logging.getLogger('urllib3')
urllib3_logger.setLevel(logging.CRITICAL)

class IRouter(metaclass=abc.ABCMeta): 

    @classmethod
    def __subclasshook__(cls, subclass):
        return (
            hasattr(subclass, 'get') and
            callable(subclass.get) and
            
            hasattr(subclass, 'get_all') and
            callable(subclass.get_one) and

            hasattr(subclass, 'put') and
            callable(subclass.put) and
                  
            hasattr(subclass, 'delete') and
            callable(subclass.delete) and

            hasattr(subclass, 'post') and
            callable(subclass.post) and

            hasattr(subclass, 'get_base_route') and
            callable(subclass.get_base_route) and

            hasattr(subclass, 'set_base_route') and
            callable(subclass.set_base_route) and

            hasattr(subclass, 'get_token') and
            callable(subclass.get_token) and

            hasattr(subclass, '_set_token') and
            callable(subclass._set_token) 

            or NotImplemented)

    @abc.abstractmethod
    def _set_base_route(self):
        raise NotImplementedError

    @abc.abstractmethod
    def get_base_route(self):
        raise NotImplementedError


    @abc.abstractmethod
    def _set_token(self):
        raise NotImplementedError

    @abc.abstractmethod
    def get_token(self):
        raise NotImplementedError
    
    @abc.abstractmethod
    def get(self):
        raise NotImplementedError
    
    @abc.abstractmethod
    def get_all(self, id):
        raise NotImplementedError
    
    @abc.abstractmethod
    def put(self, id, payload):
        raise NotImplementedError

    @abc.abstractmethod
    def delete(self, id):
        raise NotImplementedError

    @abc.abstractmethod
    def post(self, payload):
        raise NotImplementedError



class SuperRouter(IRouter):

    def __init__(self,  base_url, base_route, token):
        super().__init__()
        self._set_base_route(f"{base_url}/{base_route}")
        self._set_token(token)

    def _set_token(self, token):
        self.token = token

    def get_token(self):
        return self.token

    def _set_base_route(self, base_route):
        self.base_route = base_route

    def get_base_route(self):
        return self.base_route
        
    def get_all(self, **kwargs):

        params = kwargs.get("params", {})
        
        response = requests.request(
            "GET", 
            f"{self.base_route}",
            params=params,
            headers={
            'Authorization': f'Bearer {self.token.access_token}',
            'Content-Type': 'application/json'
            }
        )
        
        return json.loads(response.text)


    def get(self, id):
        response = requests.request(
            "GET", 
            f"{self.base_route}/{id}", 
            headers={
            'Authorization': f'Bearer {self.token.access_token}',
            'Content-Type': 'application/json'
            }
        )

        return json.loads(response.text)

    def post_file(self, files):
        
        response = requests.request(
            "POST", 
            f"{self.base_route}", 
            headers={
            'Authorization': f'Bearer {self.token.access_token}',
            }, 
            files=files
        )

        return response


    def post(self, payload):

        response = requests.request(
            "POST", 
            f"{self.base_route}", 
            headers={
            'Authorization': f'Bearer {self.token.access_token}',
            'Content-Type': 'application/json'
            }, 
            
            data=json.dumps(payload)
        )

        return response.text
        
    def put(self, id, payload):
        response = requests.request(
            "PUT", 
            f"{self.base_route}/{id}", 
            headers={
            'Authorization': f'Bearer {self.token.access_token}',
            'Content-Type': 'application/json'
            }, 
            
            data=json.dumps(payload)
        )

        return response.text

    def delete(self, id, token):
        response = requests.request(
            "DELETE", 
            f"{self.base_route}/{id}", 
            headers={
            'Authorization': f'Bearer {self.token.access_token}',
            'Content-Type': 'application/json'
            }, 

        )

        return response.text