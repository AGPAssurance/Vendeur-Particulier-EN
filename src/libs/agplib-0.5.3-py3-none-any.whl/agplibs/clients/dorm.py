import json
from typing import Text
import requests
import time
from pprint import pprint
from datetime import *
from datetime import datetime, date, timedelta
from dateutil.relativedelta import SU, relativedelta
from agplibs.clients.interfaces import IRouter, SuperRouter
from agplibs.utils.sugar import Contact
from agplibs.clients.sac import SugarApiClient
import logging
urllib3_logger = logging.getLogger('urllib3')
urllib3_logger.setLevel(logging.CRITICAL)

class Token:
    
    def __init__(self):
        self.base_url = ''
        self.__access_token = None
        self.exp_access = ''
        self.refresh_token = None
        self.exp_refresh = ''
        
        self.access_token_expired_time = ''
        self.refresh_token_expired_time = ''
        

    

    def __login(self):
                 
        response = requests.request(
            "POST", 
            f"{self.base_url}/auth/login", 
            headers={
                'Content-Type': 'application/json'
            }, 
            data=json.dumps({
                "email": "test@test.ts",
                "password": "@xY$$cEW!9vVpyu)"
            })
        )
        self.access_token_expired_time = (json.loads(response.text))['exp_access']
        self.refresh_token_expired_time = (json.loads(response.text))['exp_refresh']
        
        self.__set_values((json.loads(response.text))['access'], 
                        (json.loads(response.text))['refresh'] )
                        
    
    def __is_expired(self, exp_date):
        
        return datetime.now() >= exp_date
       
        
    def __check_token(self):
        
        if self.__is_expired(self.exp_access):
                                
            if self.__is_expired(self.exp_refresh):
                
                print('CALL LOGIN')
                self.__login()
 
            else :
                
                print('CALL REFRESH TOKEN')
                self.__refresh_token()

     
    def __refresh_token(self):
        
        response = requests.request(
            "POST", 
            f"{self.base_url}/auth/token/refresh/",
            headers={
                'Content-Type': 'application/json'
            }, 
            data=json.dumps({
                "refresh": f"{self.refresh_token}"
            })
        )

        self.__set_values((json.loads(response.text))['access'], 
                        (json.loads(response.text))['refresh'])
                
    
    def __set_values(self, access_token, refresh_token):
        
        self.__access_token = access_token
        self.exp_access = (datetime.now()) + relativedelta(seconds=self.access_token_expired_time)
        self.refresh_token = refresh_token
        self.exp_refresh = (datetime.now()) + relativedelta(seconds=self.refresh_token_expired_time)
      
    def set_base_url(self, url):
        
        if(url is None or url.strip() == ""):
            raise Exception("base url is invalid")

        self.base_url = url.strip()
        self.__login()


    @property 
    def access_token(self):
        
        self.__check_token()
        
        return self.__access_token         


class DormApiClient():
    
    def __init__(self):
        self.token = Token()
        self.set_base_url('https://api.core.agpassurance.ca/api')
        self._set_super_router()
        self.sac_client = SugarApiClient()


    def _set_base_route(self):
        return super()._set_base_route()


    def endpoint(self, base_route):
        return SuperRouter(self.base_url, base_route, self.token)
    
    
    def _set_super_router(self):
        self.skill = SuperRouter(self.base_url, "foniva/skill", self.token) 
        self.skill_sc = SuperRouter(self.base_url, "foniva/skill/sc", self.token) 
        self.alerte_jarvis = SuperRouter(self.base_url, "alerte-jarvis/alerte", self.token) 
        self.agent = SuperRouter(self.base_url, "foniva/agent", self.token)
        self.longues_attentes  =SuperRouter(self.base_url, "foniva/longues-attentes", self.token)


    def set_base_url(self, url):
        
        if(url is None or url.strip() == ""):
            raise Exception("base url is invalid")

        self.base_url = url.strip()

        self.token.set_base_url(url)

        self._set_super_router()
        

    def get_campaigns(self):
          
        response = requests.request(
            "GET", 
            f"{self.base_url}/foniva/campaigns/", 
            headers={
            'Authorization': f'Bearer {self.token.access_token}',
            'Content-Type': 'application/json'
            }
        )
        
        return json.loads(response.text)


    def get_campaign(self, dbid):
          
        response = requests.request(
            "GET", 
            f"{self.base_url}/foniva/campaigns/{dbid}", 
            headers={
            'Authorization': f'Bearer {self.token.access_token}',
            'Content-Type': 'application/json'
            }
        )

        return json.loads(response.text)


    def get_service_identities(self, name):

        response = requests.request(
            
            "GET", 
            
            f"{self.base_url}/services-models/service-identity/{name}/list", 
            
            headers={
            'Authorization': f'Bearer {self.token.access_token}',
            'Content-Type': 'application/json'
            }
        )

        return json.loads(response.text)
        

    def create_service_identity(self, service):

        response = requests.request(
            
            "POST", 

            f"{self.base_url}/services-models/service-identity/create/", 
            
            headers={
            'Authorization': f'Bearer {self.token.access_token}',
            'Content-Type': 'application/json'
            }, 
            
            data=json.dumps(service)
        )

        return response.text


    def delete_service_identity(self, pid):

        response = requests.request(
            
            "DELETE", 

            f"{self.base_url}/services-models/service-identity/{pid}/delete", 
            
            headers={
            'Authorization': f'Bearer {self.token.access_token}',
            'Content-Type': 'application/json'
            }, 
        
        )

        return response.text


    def create_source_audits(self, contact_id, field_name, new_value, call_status):
        
        get_old_value = Contact.get_current_sources(self.sac_client, contact_id)
        old_value = get_old_value[0][field_name]
        
        response = requests.request(
            "POST", 
            f"{self.base_url}/ressource/sources-audits/create/", 
            
            headers={
            'Authorization': f'Bearer {self.token.access_token}',
            'Content-Type': 'application/json'
            }, 
            
            data=json.dumps({
            "contact_id": f"{contact_id}",
            "field_name": f"{field_name}",
            "new_value": f"{new_value}",
            "old_value": f"{old_value}",
            "call_status": f"{call_status}"
            })
        )

        return response.text
    
    
    def create_UnreacheableRappelTransfert(self, firstname, lastname, number, custom):
        
        response = requests.request(
            "POST", 
            f"{self.base_url}/services-models/unreacheable-rappel-transfert/create/", 
            
            headers={
            'Authorization': f'Bearer {self.token.access_token}',
            'Content-Type': 'application/json'
            }, 
            
            data=json.dumps({
            "first_name": f"{firstname}",
            "last_name": f"{lastname}",
            "phone_number": f"{number}",
            "sugar_id": f"{custom}"
            })
        )

        return response.text
        
    
    def get_user(self, dorm_user_id):
        
        response = requests.request(
            "GET", 
            f"{self.base_url}/auth/users/{dorm_user_id}/", 
            headers={
            'Authorization': f'Bearer {self.token.access_token}',
            'Content-Type': 'application/json'
            }
        )

        return json.loads(response.text)
    
    
    def get_user_by_sugarid(self, sugar_user_id):
        
        response = requests.request(
            "GET", 
            f"{self.base_url}/auth/users/sugar/{sugar_user_id}/", 
            headers={
            'Authorization': f'Bearer {self.token.access_token}',
            'Content-Type': 'application/json'
            }
        )

        return json.loads(response.text)
        
    
