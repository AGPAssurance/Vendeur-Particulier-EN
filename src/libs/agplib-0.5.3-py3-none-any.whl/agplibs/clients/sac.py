import json
import requests
from datetime import *
import time as t
import logging
from pprint import pprint
from agplibs.utils.utils import chunks
import logging
urllib3_logger = logging.getLogger('urllib3')
urllib3_logger.setLevel(logging.CRITICAL)


class Token():

    def is_expired(self):
        return datetime.now() >= self.expires_date

    def __init__(self, access_token, expires_in):
        self.acces_token = access_token
        self.expires_date = datetime.now() + timedelta(seconds=expires_in - 600)



class ISugarApiClient():

    def post(self, ressource_name, **kwargs): 
        raise NotImplementedError
    
    def put(self,ressource_name, ressource_id, **kwargs):
        raise NotImplementedError
    
    def get(self, ressource_name, **kwargs):
        raise NotImplementedError

    def get_audits(self, ressource_name, **args):
        raise NotImplementedError

    def bulk_get():
        raise NotImplementedError



class FakeSugarApiClient(ISugarApiClient):


    def __init__(self):
        self._data = {
            "Contacts" : {
                "data" : {},
                "last_id" : 0
            }
        }

    def _merge_dicts(self, a, b):
        c = a.copy()
        c.update(b)
        return c

    
    def _set_data(self, ressource_name_d, data, id=None):
        
        ressource_name = self._data.get(ressource_name_d, None)

        if ressource_name == None:
            raise Exception(f"La ressource {ressource_name_d} n'existe pas.")

        if id == None:
            ressource_name["last_id"] += 1
            id = ressource_name["last_id"]
            id = str(id)

            elems = ressource_name["data"]

            ressource = {
                "id" : id
            }
            elems[id] = {
                id : ressource
            }

     
        else:
            ressource = ressource_name["data"].get(id, {})
            
        

        ressource = self._merge_dicts(ressource, data)

        ressource_name["data"][id] = ressource

        return id

    
    
    def _get_data(self, ressource_name_d, id):
        ressource_name = self._data.get(ressource_name_d, None)
        
        if(ressource_name == None):
            raise Exception(f"La ressource {ressource_name_d} n'existe pas.")
        
        ressource = ressource_name["data"].get(id, None)

        if(ressource == None):
            raise Exception(f"Le {ressource_name_d} avec l'id {id} n'existe pas.")
        
        return ressource


    def get_dict(self):
        return self._data

    def _find_data(self, ressource_name_d, filter_query):
        ressource_name = self._data.get(ressource_name_d, None)
        
        if(ressource_name == None):
            raise Exception(f"La ressource {ressource_name_d} n'existe pas.")


        i = 0

        data = []
        for i, k in enumerate(ressource_name.items()):
            if(filter_query(ressource_name[k])):
                data.append(ressource_name[i])

        return data

    def _fields(self, fields, data_list):
        
        filter_data = []
        for field in fields:
            for data in data_list:
                new_data = {}
                for key in data:
                    if(key == field):
                        new_data[key] = data[key]
                
                if new_data: 
                    filter_data.append(new_data)

        return filter_data


    def post(self, ressource_name, **kwargs):

        payload = kwargs.get("payload", None)


        if("id" in payload):
            id = self._set_data(ressource_name, payload, payload["id"])
        else:
            id = self._set_data(ressource_name, payload)



        return self._get_data("Contacts", id)   

    def put(self, ressource_name, ressource_id, **kwargs):
        
        ressource_id = int(ressource_id)

        payload = kwargs.get("payload", None)

        self._set_data(ressource_name, payload, ressource_id)

        return self._get_data("Contacts", ressource_id)   

    def get(self, ressource_name, **kwargs):

        data = []

        id = kwargs.get("id", None)
        if id != None:
            data.append(self._get_data(ressource_name, id))
        else: 
            data = self._data[ressource_name]["data"]
        
        data_list = []
        
        for elem in data:
            data_list.append(elem)


        fields = kwargs.get("fields", None)
        if fields != None:
            data_list = self._fields(fields, data_list)

        return data_list





class SugarApiClient:
    """
        Abastraction à l'api Sugar offrant des méthodes de gestions au travers
        des endpoints
    """


    
    def __init__(self):
        
        self.base_url = "https://agp.sugarondemand.com/rest/v11_4"
        self.credential_login = "{\n  \"grant_type\":\"password\",\n  \"client_id\":\"sugar\",\n  \"client_secret\":\"\",\n  \"username\":\"mmoringagnon\",\n  \"password\":\"Collabspotadmin1$\",\n  \"platform\":\"Base\"\n}"
        self.__token = None
        
        self.__set_token()


    def __check_token(self):
        if self.__token.is_expired():
            self.__set_token()


    def __set_token(self):

        for i in range(1, 1000000):

            response = requests.request("POST", 
                f"{self.base_url}/oauth2/token", 
                data=self.credential_login, 
                headers={'Content-Type': "text/plain"}
            )
            response_parsed = json.loads(response.text)

            if "error" not in response_parsed:
                access_token = response_parsed.get("access_token", False)
                if (access_token):
                
                    self.__token = Token(access_token, response_parsed["expires_in"])
                    # print("Token Refresh!")
                    break
            else : 
                print(response_parsed["error"])
                t.sleep(5)

        return self.__token


    def header(self):
        return {'oauth-token': self.__token.acces_token,
                   'Content-Type': 'application/json'}


    def post(self, ressource_name, **kwargs):
        self.__check_token()
        
        print(f"{self.base_url}/{ressource_name}")
        print(kwargs.get("payload", {}))
        print(self.header())
        
        response = requests.request("POST", 
            f"{self.base_url}/{ressource_name}", 
            data=kwargs.get("payload", {}), 
            headers=self.header()
        )
        print(json.loads(response.text))
        return json.loads(response.text)
      

    def put(self, ressource_name, ressource_id, **kwargs):
        self.__check_token()

        url = f"{self.base_url}/{ressource_name}/{ressource_id}"
        payload = json.dumps(kwargs.get("payload", {}))

        response = requests.request("PUT", url, headers=self.header(), data=payload)
        print('Updated in SugarCRM')
        return response.text.encode('utf8')


    def get_audits(self, ressource_name, **args):
        array = []
        for arg_key in args:
            arg_dict = {}
            arg_dict[arg_key] = args[arg_key]
            array.append(arg_dict)

        response = self.get(f"GetAuditLog/{ressource_name}", queries=args)

        records = []
        if(response):
            data = response[0]
            if(data.get("status", "400") == "200"):
                records = data["data"]
        
        return records



    def get(self, ressource_name, **kwargs):
                
        self.__check_token()
        headers = {'oauth-token': self.__token.acces_token}

        params = {}
        payload = {}
        url = f"{self.base_url}/{ressource_name}"

        query_params = kwargs.copy()

        #SET QUERRY
        id = query_params.get("id", None)
        query_params.pop('id', None)
        if(id is not None):
            url = f"{url}/{id}"

        queries = query_params.get("queries", None)
        query_params.pop('queries', None)
        if(queries is not None):
            for query_key in queries:
                params[query_key] = queries[query_key]

        filters = query_params.get("filters", None)
        query_params.pop('filters', None)
        if(filters is not None):
            if isinstance(filters, list): 
                for filter in filters:
                    for filter_key in filter:
                        params[filter_key] = filter[filter_key]
            elif isinstance(filters, dict):
                payload = json.dumps(filters)


        offset = query_params.get("offset", None)
        query_params.pop('offset', None)
        if(offset is not None):
            params["offset"] = offset

        max_num = query_params.get("max_num", None)
        query_params.pop('max_num', None)
        if(max_num is not None):
            params["max_num"] = str(max_num)

        fields = query_params.get("fields", None)
        query_params.pop('fields', None)
        if(fields is not None): 
            params["fields"] = ",".join(fields)
        
        limit = query_params.get("limit", None)
        query_params.pop('limit', None)

        order_by = query_params.get("order_by", None)
        query_params.pop('order_by', None)
        if(order_by is not None):
            params["order_by"] = order_by

        
        if(len(query_params) > 0):
            raise Exception(f"Les paramètres {query_params} nes sont pas suportés")
        
        records =  []
        next_offset = 1

        if(limit is None):

            while next_offset != -1:
                response = requests.request("GET", url=url, headers=self.header(), params=params, data=payload)
                response_parsed = json.loads(response.text)
                if("records" in response_parsed):
                    nb_records = len(response_parsed["records"])
                    # print("Get " + str(nb_records) + " records")
                    records.extend(response_parsed["records"])
                elif("error" not in response_parsed):
                    records.append(response_parsed)
                
                next_offset = response_parsed.get("next_offset", -1)
                params["offset"] = next_offset

        else:

            params["max_num"] = str(limit)
            response = requests.request("GET", url=url, headers=self.header(), params=params, data=payload)
            
            response_parsed = json.loads(response.text)
            if("records" in response_parsed):
                records.extend(response_parsed["records"])
            
        return records

    
    def bulk_get_by_phone(self, phones, fields=None):
        payload = {}
        url = f"{self.base_url}/bulk"


        payload["requests"] = []
        method = "GET"

        request_url = f"v11_4/Contacts"

        if fields != None and len(fields) > 0:
            concatenate = ",".join(fields)
            request_url = f"{request_url}?fields={concatenate}"

        for phone in phones:

            payload["requests"].append({
                "url" : request_url,
                "method" : method,
                "data" : {
                     "filter": [
                            {
                                "phone_home": phone
                            }]
                }

            })
        
        payload = json.dumps(payload)

        response = requests.request("POST", url=url, headers=self.header(), data=payload)
        response_parsed = json.loads(response.text)

        list = []


        for response in response_parsed:
            list.append(response.get("contents", {}).get("records", None))  

        return list
     
    
    def bulk_put(self, ressource_name, data):
        self.__check_token()
        
        url = url = f"{self.base_url}/bulk"

        payload = {}
        payload["requests"] = []
        method = "PUT"

        for request in data:
            request_url = f"v11_4/{ressource_name}/{request['id']}"
            payload["requests"].append(
                {
                    "url" : request_url,
                    "method": method,
                    "data" : request
                }
            )

        payload = json.dumps(payload)     
        response = requests.request("POST", url=url, headers=self.header(), data=payload)
        response_parsed = json.loads(response.text)

        return response_parsed
        
 
    def bulk_get(self, ressource_name, ids : list, fields=None):
        self.__check_token()
        
        payload = {}
        url = f"{self.base_url}/bulk"


        payload["requests"] = []
        method = "GET"

        for id in ids:
            request_url = f"v11_4/{ressource_name}/{id}"

            if fields != None and len(fields) > 0:
                
                concatenate = ",".join(fields)
                request_url = f"{request_url}?fields={concatenate}"


            payload["requests"].append(
                {
                    "url" : request_url,
                    "method" : method
                }
            )

        payload = json.dumps(payload)     
        response = requests.request("POST", url=url, headers=self.header(), data=payload)
        response_parsed = json.loads(response.text)

        list = []
        for responses in response_parsed:

            list.append(responses.get("contents", ""))

        return list


    def bulk_get_by_link(self, ressource_name, ids,  linked_ressource, fields=None):
        
        self.__check_token()
        payload = {}
        url = f"{self.base_url}/bulk"


        payload["requests"] = []
        method = "GET"

        
        for id in ids:
            request_url = f"v11_4/{ressource_name}/{id}/link/{linked_ressource}"


            if fields != None  and len(fields) > 0:
                
                concatenate = ",".join(fields)
                request_url = f"{request_url}?fields={concatenate}"

            payload["requests"].append(
                {
                    "url" : request_url,
                    "method" : method
                }
            )

        payload = json.dumps(payload)     
        response = requests.request("POST", url=url, headers=self.header(), data=payload)
        response_parsed = json.loads(response.text)

        list = []
        for responses in response_parsed:

            list.append(responses.get("contents", ""))

        return list


    def get_by_link(self, ressource_name, ids: list, linked_ressource):
        
        '''
            Requirea list of id 
        '''
        
        linked_list = []
        
        for i in ids:
            
            response = self.get(f"{ressource_name}/{i}/link/{linked_ressource}")
            
            for x in response:
                
                linked_list.append(x)
            
        return linked_list

            
    def bulk_update_field(self, ressource_name, ids : list, key, value):
        self.__check_token()
        
        payload = {}
        payload["requests"] = []
        
        for id in ids:
            
            request_url = f"/v11_4/{ressource_name}/{id}"
            payload["requests"].append(
                {
                    "url" : request_url,
                    "method" : "PUT",
                    "data" : f"{{\"{key}\": \"{value}\"}}"
                })

        payload = json.dumps(payload)   
        print(payload)  
        response = requests.request("POST", url=f"{self.base_url}/bulk", headers=self.header(), data=payload)
        response_parsed = json.loads(response.text)
        
    
    def mass_update(self, ressource_name, ids: list, key, value):
        self.__check_token()
        
        payload = {}
        payload["massupdate_params"] = {"uid": ids, key: value}
        payload = json.dumps(payload) 

        print(payload)
          
        response = requests.request("PUT", url=f"{self.base_url}/{ressource_name}/MassUpdate", headers=self.header(), data=payload)
        response_parsed = json.loads(response.text)
        
        
    def mass_delete(self, ressource_name, ids: list):
        
        for chunk in chunks(ids, 500):
            
            self.__check_token()
            
            payload = {}
            payload["massupdate_params"] = {"uid": ids}
            payload = json.dumps(payload) 

            print(payload)
            
            response = requests.request("DELETE", url=f"{self.base_url}/{ressource_name}/MassUpdate", headers=self.header(), data=payload)
            response_parsed = json.loads(response.text)
        
