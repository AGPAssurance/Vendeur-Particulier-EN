from datetime import date, datetime
import json
from agplibs.clients.gcalc import GoogleCalendarClient
import requests
import time
import logging
urllib3_logger = logging.getLogger('urllib3')
urllib3_logger.setLevel(logging.CRITICAL)

class FonivaApiClient:
    """
    Methods: post({dict}), delete({dict}), get_all(dbid), put_phone(dbid, old_number, new_number)
    """

    def __init__(self):

        self.base_url = "http://agp.fonivacloud.com:9080/api"
        self.header = {
            'Authorization': "Basic YXBpYWdwQGFncDpGdDlzNk10TUJMRkZWN1I0"}

    def post(self, **kwargs):
        """
            Require a {dict} with a number and a dbid, example : {"number": "xxxxxxxxxx", "dbid": "xx", ...}

            Usage: class.post(querystring={"number": "xxxxxxxxxx", "dbid": "xx", "custom": "xxxx-xxxx-xx-xxxxxx"})

            Return: response
        """
        return requests.request("GET",
                                f"{self.base_url}/callinglistaddrecord.json",
                                headers=self.header,
                                params=kwargs.get("querystring", {})
                                )


    def delete(self, number, dbid):
        """
            Require a number and a dbid

            Usage: class.delete("number", "dbid")

            Return: response
        """

        return requests.request("GET",
                                f"{self.base_url}/callinglistdelrecord.json",
                                headers=self.header,
                                params={"number" : str(number), "dbid" : str(dbid) }
                                )
    

    def get_all(self, dbid):
        """
            Require a dbid, example 00

            Usage: class.get_all(xx)

            Return: list
        """
        foniva_list = []
        offset = 0
        
        all_records_are_fetch = False

        while not all_records_are_fetch:

            response = requests.request("GET",
                                        f"{self.base_url}/callinglistgetallrecords.json",
                                        headers=self.header,
                    params={"listdbid": f"{dbid}", "offset": f"{offset}"}
            )
            response_parsed = json.loads(response.text)

            for i in response_parsed:
                foniva_list.append(i)
                offset += 1

            all_records_are_fetch = len(response_parsed) < 100

        return foniva_list


    def put_phone(self, dbid, old_number, new_number):

        return requests.request("GET",
            f"{self.base_url}/callinglistupdaterecord.json?dbid={dbid}&number={old_number}&new-number={new_number}", 
            headers=self.header
        )


    def set_skill(self, username, skill_name, skill_score=None):
        params = {
                "username" : username, 
                "skillname" :skill_name
            }

                    
        if(skill_score is not None):
            params["skillscore"] = skill_score
            print(skill_score)

        return requests.request("GET",
            f"{self.base_url}/agentsetskill.json",
            params=params,
            headers=self.header
        )

    def unset_skill(self, username, skill_name, skill_score=None):

        params = {
                "username" : username, 
                "skillname" :skill_name
            }
        
        if(skill_score is not None):
            params["skillscore"] = skill_score


        return requests.request("GET",
            f"{self.base_url}/agentunsetskill.json",
            params=params,
            headers=self.header
        )

