import sys 
import subprocess
from agplibs.utils.menu import Menu, MenuOption
import json


class DockerManager:
    
    def build_tag(self):
        
        return 'docker build -t '
    
    
    def image_name(self):
                
        return input("""Enter your image name: """)
    
    
    def image_tag(self):
        
        tag_choice = input("""
                        A: Git SHA-1
                        B: Custom Tag

                        Enter your choice for image tag: """)
        
        if tag_choice == "A" or tag_choice =="a":
            
            git_command_sha = 'git rev-parse HEAD'
            process = subprocess.Popen(git_command_sha.split(), stdout=subprocess.PIPE)
            output, error = process.communicate()
            
            return (f':{output.decode("utf-8")}')
        
        if tag_choice == "B" or tag_choice =="b":
                
            return (':' + input("""Enter your image tag: """))


class LightsailManager:
     
    def push_image(self):
        
        return 'aws lightsail push-container-image '
    
    
    def container_region(self):
        
        region_choice = input("""
                        A: us-east-1
                        B: us-east-2
                        
                        Choose your container region: """)
        
        if region_choice == "A" or region_choice =="a":
            
            return '--region us-east-1 '
        
        if region_choice == "B" or region_choice =="b":
            
            return '--region us-east-2 '
      
        
    def container_name(self):
                
        return ('--service-name ' + input("""Enter your lightsail container name: """) + ' ')
    
    
    def label(self, name):
        
        return ('--label ' + f'{name} ')
   
    
    def image(self, name, tag):
        
        return ('--image ' + name + tag)
  
  
    def create_container(self):
        
        return 'aws lightsail create-container-service '
   
        
    def power(self):
        
        power_choice = input("""
                        A: Nano [7$ USD] (512 MB RAM, 0.25 vCPUs)
                        B: Micro [10$ USD] (1 GB RAM, 0.25 vCPUs)
                        C: Small [15$ USD] (1 GB RAM, 0.5 vCPUs)

                        Enter your power choice: """)
        
        if power_choice == "A" or power_choice =="a":
        
            return ('--power nano ')
        
        if power_choice == "B" or power_choice =="b":
            
            return ('--power micro ')
        
        if power_choice == "C" or power_choice =="c":
            
            return ('--power small ')
  
  
    def scale(self):
        
        power_choice = input("""
                        A: 1 (default)
                        B: 2 
                        C: 3 

                        Enter your scale choice: """)
        
        if power_choice == "A" or power_choice =="a":
        
            return ('--scale 1 ')
        
        if power_choice == "B" or power_choice =="b":
            
            return ('--scale 2 ')
        
        if power_choice == "C" or power_choice =="c":
            
            return ('--scale 3 ')
  
  
    def container_list(self):
        
        return 'aws lightsail get-container-services '
  
    
    def delete_container(self):
        
        return 'aws lightsail delete-container-service '
  
  
    def deploy_on_container(self):
        
        deploy_choice = input("""
                        A: Yes
                        B: No

                        Deploy this image on container? """)
        
        if deploy_choice == "A" or deploy_choice =="a":
        
            return ('aws lightsail create-container-service-deployment --cli-input-json file://')
        
        if deploy_choice == "B" or deploy_choice =="b":
            
            sys.exit
  
  
class Logic:
    
    def __init__(self):
        
        self.docker_manager = DockerManager()
        self.lightsail_manager = LightsailManager()
        
        self.image_name = ''
        self.image_tag = ''
        self.container_name = ''
        self.label = ''
        self.image_deployed_name = ''
        
    
    def create_docker_image(self):
        
        ### * Create Docker build images
        docker_command = self.docker_manager.build_tag()
        self.image_name = self.docker_manager.image_name()
        self.image_tag = self.docker_manager.image_tag()
        create_image = docker_command + self.image_name + self.image_tag + ' .'
        print(create_image)
        
        process = subprocess.Popen(create_image.split(), stdout=subprocess.PIPE)
        output, error = process.communicate()
  
        
    def push_image(self):
        
        ### * Push Image
        lightsail_command = self.lightsail_manager.push_image()
        region = self.lightsail_manager.container_region()
        if self.container_name == '':
            self.container_name = self.lightsail_manager.container_name()
            
        if self.image_name == '' and self.image_tag == '': 
            self.image_name = self.docker_manager.image_name()
            self.image_tag = self.docker_manager.image_tag()
            
        if self.label == '':
            self.label = self.lightsail_manager.label(self.image_name)
            
        push = lightsail_command + region + self.container_name + self.label + '--image ' + self.image_name + self.image_tag
        print(push)
        
        process = subprocess.Popen(push.split(), stdout=subprocess.PIPE)
        output, error = process.communicate()
        self.image_deployed_name = (output.decode("utf-8")).split('"')[3]
        

    def create_container(self):
        
        ### * Create Container
        container = self.lightsail_manager.create_container()
        self.container_name = self.lightsail_manager.container_name()
        container_power = self.lightsail_manager.power()
        container_scale = self.lightsail_manager.scale()
        create_container_command = container + self.container_name + container_power + container_scale
        print(create_container_command)
        
        process = subprocess.Popen(create_container_command.split(), stdout=subprocess.PIPE)
        output, error = process.communicate()


    def list_container(self):
        
        ### * List all running containers
        containers_listing = self.lightsail_manager.container_list()
        print(containers_listing)
        
        process = subprocess.Popen(containers_listing.split(), stdout=subprocess.PIPE)
        output, error = process.communicate()
        print(output)
  
        
    def delete_container(self):
        
        ### * Delete a specific container
        delete = self.lightsail_manager.delete_container()
        name = self.lightsail_manager.container_name()
        delete_container_command = delete + name
        print(delete_container_command)
        
        process = subprocess.Popen(delete_container_command.split(), stdout=subprocess.PIPE)
        output, error = process.communicate()
        print(output)
       
         
    def deploy(self):
        
        ### * Deploy an image on a container
        deploy_aws = self.lightsail_manager.deploy_on_container()
        
        if self.container_name == '':
            self.container_name = self.lightsail_manager.container_name()
            
        if self.image_deployed_name == '':
            print("You need to push before deploy")
            self.push_image()
            
        deploy_json = {
                "serviceName": self.container_name.split(' ')[1],
                "containers": {
                        self.container_name.split(' ')[1]: {
                        "image": self.image_deployed_name ,
                        
                    }
                }
            }
        
        out_file = open("deploy.json", "w")
        json.dump(deploy_json, out_file, indent = 6)
        out_file.close()
        
        deploy_command = deploy_aws + "deploy.json"
        process = subprocess.Popen(deploy_command.split(), stdout=subprocess.PIPE)
        output, error = process.communicate()
        print(output)
        
    
class CLI:
    
    def __init__(self):
        
        self.logic = Logic()
        self.docker_manager = DockerManager()
        self.lightsail_manager = LightsailManager()
        
        self._menu = Menu([
            MenuOption('A','Create a Container', self.create_container),
            MenuOption('B','Create a Docker Image', self.create_image),
            MenuOption('C','Push an Image', self.push_image),
            MenuOption('D','Deploy an Image', self.deploy_image),
            MenuOption('E','List All Running Containers', self.list_containers),
            MenuOption('F','Delete Container', self.delete_container)
 
        ],"\n************ Lightsail AGP CLI **************\n")
              

    def menu(self):
        
        self._menu.show_menu()
     
        
    def create_container(self):
        
        ### * Create Container
        self.logic.create_container()

            
    def create_image(self):
        
        ### * Create Image
        self.logic.create_docker_image()
        
        
    def push_image(self):
        
        ### * Push Image
        self.logic.push_image()

      
    def deploy_image(self):
        
        ### * Deploy Image
        self.logic.deploy()
        
 
    def list_containers(self):
        
        ### * List all running containers
        self.logic.list_container()
        
        
    def delete_container(self):
        
        ### * Delete a specific container
        self.logic.delete_container()
       


  

cli = CLI()
cli.menu()
