from typing import Sequence
from agplibs.utils.interfaces import IContactModel, IDict, IFonivaPerson
from datetime import datetime



class FonivaPersonModel(IFonivaPerson, IDict):
    """ 
        Classe représentant une personne du gestionnaire d'appel Foniva
    """

    def __init__(self):
        self.__model = {}
        self.set_field(
            "team_name", [ {
                "id" : 1, 
                "name" : "Global", 
                "name_2" : "",
                "primary" : True
            }]
        )

    def __str__(self):
        return str(self.__model)
    class Keys:
        FIRST_NAME = "first_name"
        LAST_NAME = "last_name"
        NUMBER = "number"
        CUSTOM = "custom"

    def get_sugar_id(self):
        self.__model.get(FonivaPersonModel.Keys.CUSTOM, "")       

    def get_number(self):
        self.__model.get(FonivaPersonModel.Keys.CUSTOM, "")     

    def get_last_name(self):
        return self.__model.get(FonivaPersonModel.Keys.LAST_NAME, "")

    def get_first_name(self):
        return self.__model.get(FonivaPersonModel.Keys.FIRST_NAME, "")

    def set_first_name(self, first_name : str):
        self.__model[FonivaPersonModel.Keys.FIRST_NAME] = first_name

    def set_last_name(self, last_name : str):
         self.__model[FonivaPersonModel.Keys.LAST_NAME] = last_name

    def set_number(self, number : str):
        self.__model[FonivaPersonModel.Keys.NUMBER] = number
    
    def set_sugar_id(self, sugar_id: str):
        self.__model[FonivaPersonModel.Keys.CUSTOM] = sugar_id

    
    def model_to_dict(self):
        """
            Require a {dict} equivalent to the contact model

            Usage: instance.model_to_dict()

            Return: {dict}
        """
        return self.__model

    def set_fields(self, dict):
        for key in dict:
            value = dict[key]
            self.set_field(key, value)

    def set_field(self, key, value):
        self.__model[key] = value

    def get_field(self, key):
        return self.__model[key]
        
        
class ContactModel(IContactModel, IDict):
    
    """ 
        Classe représentant un contact du SugarCRM
    """

    class Values:
        """
            Valeurs correspondant au modèle sugar
        """
        COURRIEL_C = "Autorisation_courriel"


    class Keys: 
        
        """
            Clés correspondant au modèle sugar
        """

        LAST_NAME = "last_name"
        FIRST_NAME = "first_name"
        EMAIL = "email1"
        PHONE_HOME = "phone_home"
        PHONE_MOBILE = "phone_mobile"
        DATE_DE_RENOUVELLEMENT_AUTO = "date_renouvellement_auto_c"
        DATE_DE_RENOUVELLEMENT_HABIT = "date_renouvellement_maison_c"
        COURRIEL_C = "courriel_c"
        RENDEZ_VOUS_CONTACT = "rdv_contact_c"
        VALIDATION = "validation_c"
        TEAM_NAME = "team_name"
        MODIFIED_BY_NAME = "modified_by_name"



    def __init__(self):
        self.__model = {}
        self.set_field(
            self.Keys.TEAM_NAME , [ {
                "id" : 1, 
                "name" : "Global", 
                "name_2" : "",
                "primary" : True
            }]
            
        )

    def __str__(self):
        return str(self.__model)

    def model_to_dict(self):
        """
            Require a {dict} equivalent to the contact model

            Usage: instance.model_to_dict()

            Return: {dict}
        """
        return self.__model

    def set_fields(self, dict):
        for key in dict:
            value = dict[key]
            self.set_field(key, value)

    def set_field(self, key, value):
        self.__model[key] = value

    def get_field(self, key):
        return self.__model[key]

    def get_date_renouvellement_auto(self):
        return self.__model.get(self.Keys.DATE_DE_RENOUVELLEMENT_AUTO, "")
        
    def get_date_renouvellement_habit(self):
        return self.__model.get(self.Keys.DATE_DE_RENOUVELLEMENT_HABIT, "")
        
    def get_email(self):
        return self.__model.get(self.Keys.EMAIL, "")
        
    def get_first_name(self):
        return self.__model.get(self.Keys.FIRST_NAME, "")
        
    def get_phone_home(self): 
        return self.__model.get(self.Keys.PHONE_HOME, "")
        
    def get_phone_mobile(self):
        return self.__model.get(self.Keys.PHONE_MOBILE, "")
        
    def get_last_name(self):
        return self.__model.get(self.Keys.LAST_NAME, "")

    def set_date_renouvellement_auto(self, date_renouvellement_auto):
        self.__model[self.Keys.DATE_DE_RENOUVELLEMENT_AUTO] = date_renouvellement_auto

    def set_date_renouvellement_habit(self, date_renouvellement_habit):
        self.__model[self.Keys.DATE_DE_RENOUVELLEMENT_HABIT] = date_renouvellement_habit

    def set_email(self, email):
        if(email != ""):
            self.__model[self.Keys.COURRIEL_C] = self.Values.COURRIEL_C
        else:
            self.__model[self.Keys.COURRIEL_C] = ""
            
        self.__model[self.Keys.EMAIL] = email

    def set_first_name(self, first_name):
        self.__model[self.Keys.FIRST_NAME] = first_name

    def set_phone_home(self, phone_home): 
        self.__model[self.Keys.PHONE_HOME] = phone_home
        
    def set_phone_mobile(self, phone_mobile):
        self.__model[self.Keys.PHONE_MOBILE] = phone_mobile
        
    def set_last_name(self, last_name):
        self.__model[self.Keys.LAST_NAME] = last_name

    def set_rdv_contact(self, rdv : datetime):
        self.__model[self.Keys.RENDEZ_VOUS_CONTACT] = rdv

    def get_rdv_contact(self, rdv : datetime):
        return self.__model.get(self.Keys.RENDEZ_VOUS_CONTACT, "")

    
    def set_fields(self, dict):
        for key in dict:
            value = dict[key]
            self.set_field(key, value)

    def set_field(self, key, value):
        self.__model[key] = value
    
    def get_field(self, key):
        return self.__model[key]