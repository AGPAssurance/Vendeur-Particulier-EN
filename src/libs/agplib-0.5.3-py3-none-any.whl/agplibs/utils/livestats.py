import logging

import time
import xml.etree.ElementTree as xe
from datetime import datetime
import socket
import logging
import threading
import time
import xml.etree.ElementTree as xe


log = logging.getLogger()




class setInterval():
    def __init__(self, func, sec):
        def func_wrapper():
            self.t = threading.Timer(sec, func_wrapper)
            self.t.start()
            func()
        self.t = threading.Timer(sec, func_wrapper)
        self.t.start()

    def cancel(self):
        self.t.cancel()


class FcClient(threading.Thread):
    #
    #
    #
    def __init__(self):
        self.socket = None
        self.host = ""
        self.port = -1
        self.user = ""
        self.password = ""
        self.domain = ""
        self.ressource = ""
        self.loggedIn = False
        self.activeConnection = False
        self.ignoreWhite = True
        self.closing = False
        self.stopped = False
        self.buffereddata = ""
        self.PROTOCOL_MSG_SEPARATOR_OVER = '<fonivacommprotocol type="COMM-OVER" />'

        self.friends = []
        self.jabberstatus = ""
        self.jabberserverstatus = ""
        self.servername = None

        self.stattypes = []

        self.processingData = ""

        self.serverkeepalivethread = None
        self.serverlastreceivedmessage = datetime.now()

        self.serverkeepalivetimeout = 1*60*1000  # 1 minute
        self.serverkeepalivemax = 5*60  # 5 minutes

        self.onConnectionSuccessEventReceived = None
        self.onIncomingDataEvent = None
        self.onDisconnectionEvent = None
        self.onFcErrorEvent = None
        self.onPresenceEvent = None
        self.onLoginEvent = None
        self.onMessageEvent = None

    #
    #
    #

    def sethost(self, _host):
        self.host = _host

    #
    #
    #
    def setport(self, _port):
        self.port = _port

    #
    #
    #
    def setuser(self, _user):
        self.user = _user

    #
    #
    #
    def setpass(self, _pass):
        self.password = _pass

    #
    #
    #
    def setressource(self, _ress):
        self.ressource = _ress

    #
    #
    #
    def setdomain(self, _domain):
        self.domain = _domain

    #
    #
    #
    def connect(self):
        self.activeConnection = False
        self.loggedIn = False

        self.jabberstatus = 'CONNECTING'

        threading.Thread.__init__(self)

        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.setblocking(True)

        ret = False
        try:
            self.socket.connect((self.host, self.port))
            ret = True
            self.socketConnected()
        except Exception as e:
            log.warn("Unable to connect to host ...")
            log.warn(e)

        self.start_listen()

        return ret

    # def disconnect(self):
    #     log.debug("About to disconnect")
    #     self.closing = True
    #     self.socket.shutdown()
    #     self.socket.close()

    # LISTEN
    def listen(self):
        while not self.closing and not self.stopped and self.socket is not None:
            try:
                #log.debug("About to wait for recv ...")

                message = self.socket.recv(4096)

                if message is None:
                    log.debug("RECV stopped.")
                    self.closing = True
                    break

                encoding = 'utf-8'
                message = message.decode(encoding)

                if message == '':
                    log.debug("No message received ...")
                    break

                self.processingData = self.processingData + message

                self.socketReceivedData()

            except Exception as e:
                log.warn(e)
                self.closing = True

        log.debug("About to exit listening ...")
        self.stopped = True

    def start_listen(self):
        log.debug("About to start listening ...")
        t = threading.Thread(target=self.listen, args=())
        log.debug("thread initted....")
        t.start()
        log.debug("Start listening done.")
        # t.join()

    #
    #
    #
    def disconnect(self):
        if self.socket is not None:
            self.socket.close()
        self.socket = None

    #
    #
    #
    def send(self, _s, display=True):

        if not isinstance(_s, str):
            encoding = 'utf-8'
            _s = _s.decode(encoding)

        if self.socket is not None:
            _s += self.PROTOCOL_MSG_SEPARATOR_OVER

        try:
            if display:
                log.debug("About to send --> " + _s)
            _s = _s.encode()
            self.socket.send(_s)
        except Exception as e:
            log.debug(e)

    #
    #
    #

    def isLoggedIn(self):
        return self.loggedIn

    #
    #
    #
    def isActive(self):
        return self.activeConnection

    #
    #
    #

    def get_jidstring(self):
        return (self.user+"@"+self.domain+"/"+self.ressource)

    #
    #
    #
    def socketConnected(self):
        # self.activeConnection = True
        # var event = new ConnectionSucessEvent()
        # $.event.trigger({type: 'ConnectionSucessEvent', detail: event} )

        #jids = self.user+"@"+self.domain+"/"+self.ressource
        # log.debug(jids)

        log.debug("Inside socketConnected")
        xnode = xe.Element("auth")

        cnode = xe.SubElement(xnode, "username")
        cnode.text = self.user
        cnode = xe.SubElement(xnode, "password")
        cnode.text = self.password
        cnode = xe.SubElement(xnode, "jid")
        cnode.text = self.get_jidstring()
        cnode = xe.SubElement(xnode, "features")
        #cnode.text = self.features
        cnode = xe.SubElement(xnode, "keepalive")
        #cnode.text = self.keepalivenode

        xmlstr = xe.tostring(xnode, encoding='utf8', method='xml')

        self.send(xmlstr, False)

        # var s = (new XMLSerializer()).serializeToString(xnode)
        # self.send(s)
        log.debug("Outside socketConnected")
        pass

    #
    #
    #

    def socketReceivedData(self):
        #log.debug("Inside FcClient.socketReceivedData")

        localstr = self.processingData

        rpos = localstr.rfind(self.PROTOCOL_MSG_SEPARATOR_OVER)

        if rpos > 0:
            localstr = localstr[0:rpos]
            #log.debug("xxxx = %s" %((rpos + len(self.PROTOCOL_MSG_SEPARATOR_OVER))))
            self.processingData = self.processingData[(
                rpos + len(self.PROTOCOL_MSG_SEPARATOR_OVER)):]
        else:
            localstr = ""

        msgs = localstr.split(self.PROTOCOL_MSG_SEPARATOR_OVER)

        for msg in msgs:
            if msg is not None and msg != '':
                xnode = xe.fromstring(msg)

                if xnode.tag == 'auth':
                    self.handleAuth(xnode)
                elif xnode.tag == 'message':
                    self.handleMessage(xnode)
                elif xnode.tag == 'query':
                    self.handleQuery(xnode)
                elif xnode.tag == 'presence':
                    self.handlePresence(xnode)
                else:
                    log.warn("Unsupported node type " + xnode.tag)

        # var xmlstring = ev
        # log.debug("Full received message ")
        # log.debug("============== RAW MESSAGE =================")
        # log.debug(xmlstring)
        # log.debug("=============  END  ================")
        # self.serverlastreceivedmessage = new Date()
        # xmlstring = self.buffereddata + xmlstring /* add old previous messgae */
        # self.buffereddata = ""
        # var messages = xmlstring.split(self.PROTOCOL_MSG_SEPARATOR_OVER)
        # var bytereads = xmlstring.length
        # var byteproceed = 0
        # for(var i = 0 i < messages.length i++)
        # {
        #     var messagestr = messages[i]
        #     byteproceed += messagestr.length + self.PROTOCOL_MSG_SEPARATOR_OVER.length

        #     if(messagestr == "")
        #         continue

        #     log.debug("+++ bytereads["+bytereads+"], byteproceed["+byteproceed+"]")
        #     if(byteproceed > bytereads)
        #     {
        #         log.debug("============= INCOMPLETE MESSAGE =================")
        #         log.debug(" messagestr = " + messagestr)
        #         self.buffereddata += messagestr
        #         log.debug(" self.buffereddata = " + self.buffereddata)
        #         log.debug("============= END OF INCOMPLETE MESSAGE =================")
        #     }
        #     else
        #     {
        #         log.debug("============= OK MESSAGE =================")
        #         log.debug("Received and processing : "+messagestr)
        #         log.debug("============= END OF OK MESSAGE =================")

        #         var xnode = None
        #         var firstNode = None
        #         var nodeName = None

        #         try
        #         {
        #             xnode = $.parseXML(messagestr)
        #             var $xxnode = $(xnode)
        #             nodeName = $xxnode.contents()[0].nodeName
        #         }
        #         catch(myError)
        #         {
        #             log_trace("[ERROR] PARSING ERRROR "+messagestr)
        #             continue
        #         }

        #         var event = new IncomingDataEvent()
        #         //event.data = xmlData
        #         $.event.trigger({type: 'IncomingDataEvent', detail: event} )

        #         log.debug("xxxx nodeName = "+nodeName)

        #         // Read the data and send it to the appropriate parser
        #         nodeName = nodeName.toLowerCase()
        #         log.debug("RECV: " + firstNode)
        #         switch( nodeName )
        #         {
        #             case "query":
        #                 self.handleQuery( xnode )
        #                 break

        #             case "message":
        #                 self.handleMessage( xnode )
        #                 break

        #             case "presence":
        #                 self.handlePresence( xnode )
        #                 break
        #             case "auth":
        #                 self.handleAuth( xnode )
        #                 break
        #             default:
        #                 // silently ignore lack of or unknown stanzas
        #                 // if the app designer wishes to handle raw data they
        #                 // can on "incomingData".

        #                 // Use case: received None byte, XMLSocket parses empty document
        #                 // sends empty document

        #                 // I am enabling this for debugging
        #                 dispatchError( "undefined-condition", "Unknown Condition "+nodeName, "modify", 500 )
        #                 break
        #         }

        #     }

        # }

    #
    #
    #

    def socketClosed(self,  ev):
        log.debug("FcClient.socketClosed")
        # var event = new DisconnectionEvent()
        # $.event.trigger({type:   'DisconnectionEvent', detail: event} )
        pass

    #
    #
    #
    # def onIOError(self, event):
    #     log.debug("FcClient.onIOError : "+event.type+" -- " +event.text)

    #     # this fires the standard dispatchError method. need to add
    #     # the appropriate error code

    #     dispatchError( "service-unavailable", "Service Unavailable", "cancel", 503 )

    #
    #
    #

    def dispatchError(self,  condition, message, type, code):
        # var event = new FcErrorEvent()
        # event.errorCondition = condition
        # event.errorMessage = message
        # event.errorType = type
        # event.errorCode = code
        # $.event.trigger({type:   'FcErrorEvent', detail: event })
        pass

    #
    #
    #

    def handlePresence(self,  node):
        # var n = node.firstChild
        # if(!n)
        #     return

        fromjid = node.attrib['from']
        status = ''

        for child in node:
            xnodename = child.tag

            if xnodename == 'status':
                status = child.text

        log.debug("Status of %s is now %s" % (fromjid, status))

        if "/server" in fromjid:
            self.servername = fromjid
            self.jabberserverstatus = status

            if self.jabberserverstatus == "active":
                self.sendRegisterDomains()
        pass

    #
    #
    #

    def handleMessage(self,  node):
        #log.debug("Inside handleMessage")

        for child in node:
            xnodename = child.tag

            if xnodename == 'body':
                xbodytext = child.text

                if self.onMessageEvent is not None:
                    self.onMessageEvent(xbodytext)
                else:
                    log.warning("No onMessageEvent Provided")

        pass

    #
    #
    #

    def handleQuery(self,  node):
        log.debug("Inside handleQuery")

        # var n = node.firstChild

    #
    #
    #

    def handleAuth(self,  node):
        log.debug("Inside handleAuth ")

        for child in node:
            xnodename = child.tag

            if xnodename == "result":
                self.loggedIn = (child.text == "true")

                if self.loggedIn:
                    log.debug("Authentification connected !")
                    self.sendPresence()
                    self.sendRosterQuery()
                    self.startkeepalive()
                else:
                    log.warning("Authentification failed !")
                    self.disconnect()

            elif xnodename == "features":
                pass

        # for(var i = 0 i < n.childNodes.length i++)
        # {
        #     var xnodeName = n.childNodes[i].nodeName

        #     if(xnodeName == "result")
        #     {
        #         var result = n.childNodes[i].nodeValue
        #         var event = new LoginEvent()
        #         event.loggedin = (result == "True")
        #         $.event.trigger({type:  'LoginEvent', detail: event})

        #         /* then send our presence */

        #         var xnode = $.parseXML("<presence />")
        #         xnode.firstChild.setAttribute('from', self.jid)
        #         cnode = xnode.createElement("status")
        #         cnode.appendChild(document.createTextNode((new Presence()).ACTIVE_TYPE))
        #         xnode.documentElement.appendChild(cnode)

        #         var _initialpres = (new XMLSerializer()).serializeToString(xnode)
        #         self.send(_initialpres)

        #         xnode = $.parseXML("<query />")
        #         xnode.firstChild.setAttribute('from', self.jid)
        #         cnode = xnode.createElement("type")
        #         cnode.appendChild(document.createTextNode("roster:get"))
        #         xnode.documentElement.appendChild(cnode)

        #         var _initialrosterq = (new XMLSerializer()).serializeToString(xnode)
        #         self.send(_initialrosterq)

        #     }
        #     else if(xnodeName == "features")
        #     {
        #         for(var j = 0 j < n.childNodes[i].childNodes.length j++)
        #         {
        #             var ynodeName = n.childNodes[i].childNodes[j].nodeName
        #             if(ynodeName == 'keepalive')
        #                 self.startkeepalive()
        #         }
        #     }
        # }

    def sendPresence(self):
        xnode = xe.Element("presence")

        xnode.set("from", self.get_jidstring())
        cnode = xe.SubElement(xnode, "status")
        cnode.text = "active"

        xmlstr = xe.tostring(xnode, encoding='utf8', method='xml')

        self.send(xmlstr)

    #
    #
    #

    def sendRegisterDomains(self):

        if self.stattypes is not None:
            for stattype in self.stattypes:
                self.sendRegisterDomain(stattype)

    #
    #
    #

    def sendRegisterDomain(self, stattype):

        log.debug("About to register with stat type %s" % (stattype))

        xnode = xe.Element("message")
        xnode.set("from", self.get_jidstring())
        xnode.set("to", self.servername)
        cnode = xe.SubElement(xnode, "body")

        # ccnode = xe.SubElement(cnode, "MSG_STAT_REGISTER")

        # ccnode = xe.SubElement(ccnode, "domain")

        xmlstring = "<MSG_STAT_REGISTER><domain>%s</domain></MSG_STAT_REGISTER>" % (
            stattype)
        cnode.text = xmlstring

        xmlstr = xe.tostring(xnode, encoding='utf8', method='xml')

        self.send(xmlstr)

    def sendRosterQuery(self):
        xnode = xe.Element("query")

        xnode.set("from", self.get_jidstring())
        cnode = xe.SubElement(xnode, "type")
        cnode.text = "roster:get"

        xmlstr = xe.tostring(xnode, encoding='utf8', method='xml')

        self.send(xmlstr)

    #
    #
    #

    def ConnectionSuccessEventReceived(self, e):
        pass

    #
    #
    #
    def IncomingDataEventReceived(self, e):
        pass

    #
    #
    #
    def DisconnectionEventReceived(self, e):
        log.debug("Disconnected from Livestats server.")
        self.jabberstatus = 'NOT_CONNECTED'

    #
    #
    #

    def FcErrorEventReceived(self, e):
        log.debug('e = ' + e)
        pass

    #
    #
    #

    def PresenceEventReceived(self, e):
        # if(e.detail is not None || e.detail.data is not None)
        #     log.warn("Huh !? None presence !? ")
        #     return

        # p = e.detail.data

        # if(p == None)
        # {
        #     log.warn("Huh !? None presence !? ")
        #     return
        # }

        # jid = p.get_from()
        # status = p.get_status()

        # log.debug("Presence received, user : " + jid + ", status : " + status)

        # if (p.get_status() == p.ACTIVE_TYPE):
        #     log.debug(p.get_from() + " is Available (RosterEvent)")
        #     self.addfriend(p.get_from())
        # elif (p.get_status() == p.DISCONNECTED_TYPE):
        #     pass
        # elif (p.get_status() == p.INACTIVE_TYPE):
        #     log.debug(p.get_from() + " is Unavailable (RosterEvent)")
        #     self.removefriend(p.get_from())
        #     break
        # }
        pass

    #
    #
    #

    def LoginEventReceived(self, e):
        pass

    #
    #
    #

    def MessageEventReceived(self, e):
        # if(e.detail is not None || e.detail.data is not None):
        #     log.warn("Huh !? None message !? ")
        #     return

        # var m = e.detail.data
        # if(m == None):
        #     log_error("None message received")
        #     return False

        # var senderjid = m.get_from()
        # var friend = self.getFriend(senderjid)
        # if(friend != None)
        #     friend.messageReceived(m.get_body())

        return True

    #
    #
    #

    def addfriend(self, jid):
        if jid.resource() != "server":
            return

        # var _f = new Server(jid, this)
        # self.friends.push(_f)

        # if(self.friends.length > 0):
        #     self.jabberserverstatus = "SERVER_CONNECTED"
        #     self.jabberstatustxt = self.getjabberstatus()

        # var xnode = $.parseXML("<MSG_STAT_REGISTER />")
        # cnode = xnode.createElement("domain")
        # cnode.appendChild(document.createTextNode(self.stattype))
        # xnode.documentElement.appendChild(cnode)

        # var s = (new XMLSerializer()).serializeToString(xnode)
        # _f.sendchatmessage(s)

    #
    #
    #

    def removefriend(self, jid):
        pass
        # for(var i= 0 i < self.friends.length i++)
        # {
        #     var _f = self.friends[i]
        #     if(String(_f.getJid()) == String(jid))
        #     {
        #         self.friends.splice(i, 1)
        #         break
        #     }
        # }

        # if(self.friends.length <= 0)
        # {
        #     self.jabberserverstatus = "SERVER_NOT_CONNECTED"
        #     self.jabberstatustxt = self.getjabberstatus()
        # }

    #
    #
    #

    def startkeepalive(self):

        log.debug("About to start keep alive thread")
        self.serverkeepalivethread = setInterval(
            self.sendKeepaliveQuery, self.serverkeepalivetimeout)
        pass
        # console.log('keep alive started')
        # if(self.serverkeepalivethread != None)
        #     clearInterval(self.serverkeepalivethread)
        # self.serverkeepalivethread = setInterval('livestatviewer.do_fonivanetwork_checkkeepalive()', self.serverkeepalivetimeout)

    #
    #
    #

    def do_fonivanetwork_checkkeepalive(self):
        pass
        # var curdate = new Date()

        # var diffseconds = (curdate - self.serverlastreceivedmessage) / 1000
        # console.log('[DEBUG] curdate '+curdate+' self.serverlastreceivedmessage '+self.serverlastreceivedmessage+' diffseconds = '+diffseconds)
        # if(diffseconds > self.serverkeepalivemax)
        # {
        #     console.log("[DEBUG] No message received from server since " + self.serverlastreceivedmessage)
        #     self.sendKeepaliveQuery()
        # }

    #
    #
    #

    def sendKeepaliveQuery(self):
        xnode = xe.Element("query")

        xnode.set("from", self.get_jidstring())
        cnode = xe.SubElement(xnode, "type")
        cnode.text = "keepalive:request"

        xmlstr = xe.tostring(xnode, encoding='utf8', method='xml')

        self.send(xmlstr)
        pass

    #
    #
    #

    def getFriend(self, jid):
        # var f = None
        # for(var i = 0 i < self.friends.length i++)
        # {
        #     var _f = self.friends[i]
        #     if(_f.getJid() && _f.getJid().toString() == jid)
        #     {
        #         f = _f
        #         break
        #     }
        # }

        # if(f == None)
        #     log.warn('Friend with jid '+jid+' not found ...')
        # return f
        pass

    #
    #
    #

    def setstattypes(self, s):
        self.stattypes = s



class LiveStatViewer():

    def __init__(self):
        self.fc_client = None
        self.statsdata = {}
        self.server_timedeviance = 0

    def foniva_client_init(self, host, port, domain, user, secret, resource, stattypes):
        self.fc_client = FcClient()
        self.fc_client.sethost(host)
        self.fc_client.setport(port)
        self.fc_client.setdomain(domain)
        self.fc_client.setuser(user)
        self.fc_client.setpass(secret)
        self.fc_client.setressource(resource)
        self.fc_client.setstattypes(stattypes)
        self.stattypes = stattypes

        self.registerEventListeners()

    def is_stopped(self):
        return self.fc_client.stopped

    def foniva_client_connect(self):
        ret = self.fc_client.connect()
        log.debug("foniva_client_connect completed")
        return ret

    def foniva_client_disconnect(self):
        self.fc_client.disconnect()


    def registerEventListeners(self):
        self.fc_client.onMessageEvent = self.onMessageEvent


    def getstat(self, statdomain, dbid, name):
        value = ""
        if statdomain in self.statsdata:
            if dbid in self.statsdata[statdomain]:
                if name in self.statsdata[statdomain][dbid]:
                    value = self.statsdata[statdomain][dbid][name]

        return value

    def get_campaign_answerrate_day(self, campaignid):
        nbdialed = self.getstat(
            "CAMPAIGN_STATS", campaignid, "CALLSRECEIVED_CURDAY")
        nbanswered = self.getstat(
            "CAMPAIGN_STATS", campaignid, "ANSWEREDCALLS_CURDAY")

        if nbdialed == "" or nbanswered == "":
            return ""

        try:
            nbdialed = int(nbdialed)
            nbanswered = int(nbanswered)
            value = nbanswered / nbdialed
        except Exception as e:
            log.warning("Unable to convert nbdialed (%s) and nbanswered (%s)" % (
                nbdialed, nbanswered))
            value = ""

        return value

    def get_campaign_answerrate_hour(self, campaignid):
        nbdialed = self.getstat(
            "CAMPAIGN_STATS", campaignid, "CALLSRECEIVED_CURHOUR")
        nbanswered = self.getstat(
            "CAMPAIGN_STATS", campaignid, "ANSWEREDCALLS_CURHOUR")

        if nbdialed == "" or nbanswered == "":
            return ""

        try:
            nbdialed = int(nbdialed)
            nbanswered = int(nbanswered)
            value = nbanswered / nbdialed
        except Exception as e:
            log.warning("Unable to convert nbdialed (%s) and nbanswered (%s)" % (
                nbdialed, nbanswered))
            value = ""

        return value

    def get_queue_abandonrate_day(self, queueid):
        nbdialed = self.getstat("QUEUE_STATS", queueid, "CALLSRECEIVED_CURDAY")
        nbanswered = self.getstat(
            "QUEUE_STATS", queueid, "CALLSABANDONNED_CURDAY")

        if nbdialed == "" or nbanswered == "":
            return ""

        try:
            nbdialed = int(nbdialed)
            nbanswered = int(nbanswered)
            value = 0 if (nbdialed <= 0) else nbanswered / nbdialed
        except Exception as e:
            log.warning("Unable to convert nbdialed (%s) and nbanswered (%s)" % (
                nbdialed, nbanswered))
            value = ""

        return value

    def get_queue_waitingcalls(self, queueid):
        nbw = self.getstat("QUEUE_STATS", queueid, "NBWAITINGCALLS")
        return nbw

    def get_queue_oldestwaiting_call_since(self, queueid):
        os = self.getstat("QUEUE_STATS", queueid, "OLDESTWAITINGCALL_SINCE")
        return os

    def get_queue_abandonrate_hour(self, queueid):
        nbdialed = self.getstat("QUEUE_STATS", queueid,
                                "CALLSRECEIVED_CURHOUR")
        nbanswered = self.getstat(
            "QUEUE_STATS", queueid, "CALLSABANDONNED_CURHOUR")

        if nbdialed == "" or nbanswered == "":
            return ""

        try:
            nbdialed = int(nbdialed)
            nbanswered = int(nbanswered)
            value = 0 if (nbdialed <= 0) else (nbanswered / nbdialed)
        except Exception as e:
            log.warning("Unable to convert nbdialed (%s) and nbanswered (%s)" % (
                nbdialed, nbanswered))
            log.warning(e)
            value = ""

        return value

    def get_agentgroup_nbagents(self, groupid):
        nbagents = self.getstat("AGENTGROUP_STATS", groupid, "NBAGENTS")

        return nbagents

    def get_server_timedeviance(self):
        return self.server_timedeviance

    def do_fonivanetwork_checkkeepalive(self):
        if self.fc_client is not None:
            self.fc_client.do_fonivanetwork_checkkeepalive()

    def onMessageEvent(self, message):

        if (message is not None) and (message != ''):
            try:

                xmsg = xe.fromstring(message)

                if xmsg is not None:

                    if xmsg.tag == 'MSG_STAT' or xmsg.tag == 'MSG_STAT_UPDATE':

                        datatype = xmsg.attrib['type']
                        generated_at = xmsg.attrib['generated_at']
                        sent_at = xmsg.attrib['sent_at']

                        if not (datatype in self.statsdata):
                            self.statsdata[datatype] = {}

                        for x in xmsg:
                            if x.tag == 'data':
                                dataid = x.attrib['id']

                                if not (dataid in self.statsdata[datatype]):
                                    self.statsdata[datatype][dataid] = {}

                                for el in x:
                                    dataname = el.tag
                                    datavalue = "" if el.text is None else el.text

                                    self.statsdata[datatype][dataid][dataname] = datavalue

                    else:
                        log.warn("Message tag '%s' not supported." %
                                 (xmsg.tag))

            except Exception as e:
                log.warning(e)


