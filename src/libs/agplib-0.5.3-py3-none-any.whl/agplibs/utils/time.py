# import time
# from datetime import datetime, date, timedelta
# from dateutil.relativedelta import relativedelta


# class TimeTools:
    
#     def current_date(self):
#         """
#             return %Y-%m-%d" datetime or str
#         """
#         return (datetime.now()).strftime("%Y-%m-%d")

    
#     def current_datetime(self, data_type):
#         """
#             return str("%Y-%m-%d %H:%M:%S")
#         """
#         if data_type == 'str':
#             return (datetime.now()).strftime("%Y-%m-%d %H:%M:%S")
        
#         if data_type == 'T':
#             return (datetime.now()).strftime("%Y-%m-%dT%H:%M:%S")
    
#     # def current_datetime_str_T(self):
#     #     """
#     #         return str("%Y-%m-%dT%H:%M:%S")
#     #     """
#     #     return (datetime.now()).strftime("%Y-%m-%dT%H:%M:%S")
    
#     # def current_datetime(self):
#     #     """
#     #         return datetime
#     #     """
#     #     return datetime.now()
    
#     # def string_to_datetime(self, string_date):
#     #     """
#     #         return datetime
#     #     """
#     #     return datetime.strptime(string_date, '%Y-%m-%d') 
    
    
#     # def string_T_to_datetime(self, string_date_time):
        
#     #     return datetime.strptime(string_date_time, '%Y-%m-%dT%H:%M:%S') 
    
#     # def current_year_plus(self, year):
#     #     """
#     #         return date
#     #     """
#     #     return datetime.now() + relativedelta(years=year)
        
#     # def current_year_less(self):
#     #     pass
    
#     # def current_month_plus(self):
#     #     pass
    
#     # def current_month_less(self):
#     #     pass
    
#     # def current_day_plus(self):
#     #     pass
    
#     # def current_day_less(self):
#     #     pass
    
#     # def current_hour_plus(self):
#     #     pass
    
#     # def current_time_plus_minutes(self):
#     #     pass
    
#     # def current_time_less_minutes(self):
#     #     pass
    
#     # def current_time_plus_seconds(self):
#     #     pass
    
#     # def current_time_less_seconds(self):
#     #     pass
    
    
    
    
    
    
    
    
    
    
    
# tm = TimeTools()
# print(tm.string_T_to_date_time('2021-05-07T09:00:12'))
# # print(type(tm.string_to_date_time('2021-05-07')))

