
from typing import Any, Type
from collections.abc import Callable
import os
import time


Action = Callable[[], Any]

class ArgValidator:
    
    def _arg_is_str(self, arg) -> bool:
        return isinstance(arg, str)

    
    def _arg_is_list(self, arg) -> bool:
        return isinstance(arg,list)



class MenuOption(ArgValidator): 

    def __init__(self, key : str, text: str, action: Action ) -> None:
        
        if(not self._arg_is_str(key)):
            raise Exception("La clée doit être de type string.")

        if(not self._arg_is_str(text)):
            raise Exception("Le text doit être de type string.")

        if(not callable(action)):
            raise Exception("L'action doit implémenter la méthode __call__ (callable)")

        self.key = key.lower()
        self.text = text
        self.action = action 

    
    def __repr__(self) -> str:
        return f"{self.key} - {self.text}"

    def __str__(self) -> str:
        return f"{self.key} - {self.text}"


    def __hash__(self) -> int:
        return  hash(self.key)

    def __eq__(self, o: object) -> bool:
        return self.key == self.key





        
class Menu(ArgValidator):

    QUIT_VALUE = "q"


    def __init__(self, options : list[MenuOption], title: str, desc="") -> None:
        
        if(not self._arg_is_list(options)):
            raise Exception("L'option doit être de type list.")


        if(not self._arg_is_str(title)):
            raise Exception("Le titre doit être de type str")

        if(not self._arg_is_str(desc)):
            raise Exception("La description doit être de type str")

        
        self.title = title.upper()
        self.desc = desc
        options.append(MenuOption(Menu.QUIT_VALUE, "Quitter", self.__exit))

        options_dict = {}
        for option in options:

            if(option.key in options_dict):
                raise "L'argument key de chaque option doit être unique."
            
            options_dict[option.key]=  option
            
  

        self.options = options_dict

    def _show_menu(self) -> None:
        options = ""
        for key in self.options:
            option = self.options[key]

            options += (f"\r\n{option}")

        print(f"\r\n - {self.title} - \r\n\r\n  {self.desc} \r\n\r\n  Veuillez sélectionner un choix parmis les options suivantes : \r\n {options}")

    def show_menu(self):

        choix = None
        
        while choix != Menu.QUIT_VALUE.lower():
            self._show_menu()
            choix = input().lower()

            if(choix not in self.options):
                self.__clear()
                print("Choix invalide!")

            else:
                self.__clear()
                self.options[choix].action()
            
            input("\r\n Appuyer sur n'importe quel touche pour continuer...")
            self.__clear()

        
        print("Goodbye")


    def __exit(self):
        exit()

    def __clear(self): 
        os.system('clear') 
            
