import xml.etree.ElementTree as ET
import json
import pprint
from datetime import datetime

from  agplibs.utils.sugar import  Contact, TimeHelper
from  agplibs.utils.models import  ContactModel
from agplibs.logics.tag import Tagger, Tag
from agplibs.utils.foniva import Campaign


class LeadMaper:

    def __init__(self, sac, fac):
        self.__sac = sac
        self.__fac = fac

    class Status:
        NOUVEAU_LEAD = 0
        LEAD_EXISTANT = 1
        LEAD_MULTIPLE = 2

    
    def map_lead_to_sugar_contact(self, lead):
        """
            Convertie un lead Sugar en modèle contact du CRM Sugar
        """
        model = ContactModel()

        model.set_first_name(lead.first_name)
        model.set_last_name(lead.last_name)
        model.set_phone_home(lead.phone_number)
        model.set_email(lead.email)

        return model

    
    def get_contact(self, lead):

        ids  = Contact.get_ids_by_phone(self.__sac, phone_home=lead.phone_number)
        
        status = self.Status.NOUVEAU_LEAD
        first = None

        if(len(ids) == 1):
            id = ids[0]["id"]
            first = self.__sac.get("Contacts", id=id)[0]
            status = self.Status.LEAD_EXISTANT

        elif(len(ids) > 1):
            id = ids[0]["id"]
            first = self.__sac.get("Contacts", id=id)[0]
            status = self.Status.LEAD_MULTIPLE
        
        return (status, first)

    
    def integration_to_fonvia(self, lead, dbid, sugar_id=None):

        if not Campaign.is_phone_exist(self.__fac, lead.phone_number, dbid):
            print("ADD TO FONIVA")
            query_string = {"number": f"{lead.phone_number}", 
                                                 "dbid": f"{dbid}", 
                                                 "firstname": f"{lead.first_name}",
                                                 "lastname" : f"{lead.last_name}",
                                                 "custom" : sugar_id,
                                                 "status" : "CALLBACK",
                                                 "callback_date" : {lead.callback_date.strftime("%Y-%m-%d %H:%M:%S")}}

            if(sugar_id != None):
                query_string["custom"] = sugar_id
           
            self.__fac.post(querystring=query_string)

    
    def integration_to_sugar(self, lead):
        
        status, contact = self.get_contact(lead)

        if(status == self.Status.NOUVEAU_LEAD or status == self.Status.LEAD_MULTIPLE):
            print('CREATE Sugar') 
            contact = Contact.create_contact_sugar(self.__sac, self.map_lead_to_sugar_contact(lead).model_to_dict())
            Tagger.tag_source(self.__sac, contact["id"], source_principale_c = Tag.SourcePrincipale.SOUMISSION_WEB, source_secondaire_c = Tag.SourceSecondaire.SOUMISSION_WEB)
               
        elif(status == self.Status.LEAD_EXISTANT):
            print('UPDATE Sugar') 
            contact_call_status = Contact.get_statut_appel_value(self.__sac, contact["id"])

            payload = {
                "validation_c" : ""
            }

            if(contact_call_status not in ['Date Collectee', 'Anglais Dates Collectees', 'Intact Dates Collectees']):
                payload["statut_appel_c"] = ""

            self.__sac.put('Contacts', contact["id"], payload=payload)

            Tagger.tag_source(self.__sac, contact["id"], source_secondaire_c = Tag.SourceSecondaire.SOUMISSION_WEB)

        return contact["id"]








                   
            
 