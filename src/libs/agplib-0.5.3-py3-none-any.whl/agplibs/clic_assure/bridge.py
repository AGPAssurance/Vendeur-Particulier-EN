import xml.etree.ElementTree as ET
import json
import pprint
from  agplibs.utils.models import ContactModel
from  agplibs.utils.sugar import Contact, TimeHelper
from urllib.parse import unquote

class LoadFromXml:
    def __init__(self, xml_node):
        self.load_xml(xml_node)

    def get_el_value(self, key, xml_node):
        el = xml_node.find(key)
        value = ""
        if(el is not None and el.text is not None):
            value = el.text
            

        return value

class CaXmlParser(LoadFromXml):

    def __init__(self, file):
        tree = ET.parse(file)
        self.root = tree.getroot()
        self.parse_person()
        
    def persons_to_dict(self):
        persons = []
        for person in self.persons:
            persons.append(person.model_to_dict())

        return persons
    
    def parse_person(self):
        
        persons_elems = self.root.findall(path="persons/person")
        renewels_elems = self.root.findall(path="policy/renewals/renewal")

        request_elems = self.root.find(path="request")
        policy_elems = self.root.find(path="policy")
  
        self.persons = []

        if(persons_elems is not None):
            for person in persons_elems:
                
                person_dict = CaPerson(person)
                person_dict.set_field("clicassure_url_c", unquote(self.get_el_value('url', request_elems)))
                

                type = self.get_el_value("type", request_elems)


                effectiveDate = self.get_el_value("effectiveDate", policy_elems)

                if(effectiveDate != ""):

                    if(type == "AUTO" ):
                        person_dict.set_date_renouvellement_auto(effectiveDate)

                    elif(type == "HOME"):
                        person_dict.set_date_renouvellement_habit(effectiveDate)


                if(renewels_elems is not None):
                    
                    for i in renewels_elems:
                        
                        renewal_type = self.get_el_value("type", i)
                        
                        if(type != "HOME" and renewal_type == "HOME"):
                            person_dict.set_date_renouvellement_habit(self.get_el_value("date", i))
                            person_dict.set_field("statut_appel_c", "Date Collectee")
                            
                        elif(type != "AUTO" and  renewal_type == "AUTO"):
                            person_dict.set_date_renouvellement_auto(self.get_el_value("date", i))
                            person_dict.set_field("statut_appel_c", "Date Collectee")
                        
                self.persons.append(person_dict)

class CaAddress(LoadFromXml):
    """
        Represent a Clic Assure contact adress informations
    """
    def __init__(self, xml_address):
        self.load_xml(xml_address)
        
    def load_xml(self, xml_node):
        type = self.get_el_value("type", xml_node)
        if(type == "PRINCIPAL"):

            address_array = []

            unit_number = self.get_el_value("unitNumber", xml_node)
            if(unit_number != ""):
                address_array.append(unit_number)
            
            street_number = self.get_el_value("streetNumber", xml_node)
            if(street_number != ""):
                address_array.append(street_number)

            street = self.get_el_value("street", xml_node)
            if(street != ""):
                address_array.append(street)

            self.primary_address_street = ""
            print(address_array)
            if(len(address_array) > 0):
                self.primary_address_street = ", ".join(address_array)
            self.primary_address_city = self.get_el_value("city", xml_node)
            self.primary_address_state = self.get_el_value("province", xml_node)
            self.primary_address_country = self.get_el_value("country", xml_node)
            self.primary_address_postalcode = self.get_el_value("postalCode", xml_node)
   
class CaPhone(LoadFromXml):
    
    """
        Represent a Clic Assure contact phone informations
    """
    location=None
    type=None
    no=None

    def __init__(self, xml_phone):
        self.load_xml(xml_phone)

            
    def load_xml(self, xml_node):
        self.no = self.get_el_value("no", xml_node)
        self.type = self.get_el_value("type", xml_node)

class CaPerson(LoadFromXml, ContactModel):
    """
        Represent a Clic Assure Person with all its informations
    """

    def __init__(self, xml_node):
        ContactModel.__init__(self)
        LoadFromXml.__init__(self,xml_node)
    

    def load_xml(self, xml_node):
        self.set_first_name(self.get_el_value("firstName", xml_node))
        self.set_last_name(self.get_el_value("lastName", xml_node))
        

        salutation= self.get_el_value("gender", xml_node)
        if(salutation == "M"):
            self.set_field("salutation ", "Masculin")
        elif(salutation == "F"):
            self.set_field("salutation ", "Féminin")

        el_contact = xml_node.find("contact")

        if(el_contact):

            el_address = el_contact.find("address")
            if(el_address):
                address = CaAddress(el_address)
                self.set_field("primary_address_street", address.primary_address_street)
                self.set_field("primary_address_city",  address.primary_address_city)
                self.set_field("primary_address_state", address.primary_address_state)
                self.set_field("primary_address_country ", address.primary_address_country)
                self.set_field("primary_address_postalcode",   address.primary_address_postalcode)

            el_phones = el_contact.find("phones")
            if(el_phones):
                for el_phone in el_phones:
                    phone = CaPhone(el_phone)
                    
                    if(phone.type == "MOBILE" ):
                        self.set_phone_mobile(phone.no)
                    elif(phone.type == "PHONE"):
                        self.set_phone_home(phone.no)
                
                if(self.get_phone_home() == ""):
                    phone_mobile = self.get_phone_mobile()
                    self.set_phone_home(phone_mobile)
                    
            self.set_email(self.get_el_value("email", el_contact))
           

