import abc
from .i_service import IService
import sys
import os


class IServiceApi(metaclass=abc.ABCMeta):
    """ 
        An interface to define a api that help to
        interact with services. 
    """

    @classmethod
    def __subclasshook__(cls, subclass):
        return (hasattr(subclass, 'start_service') and 
                callable(subclass.start_service)   and
                
                hasattr(subclass, 'stop_service') and 
                callable(subclass.stop_service)  and 
                

                hasattr(subclass, 'set_service') and 
                callable(subclass.set_service) and

                hasattr(subclass, 'set_log_container') and 
                callable(subclass.set_service) and

                hasattr(subclass, 'append_log_container') and 
                callable(subclass.set_service) and

                hasattr(subclass, 'set_server') and 
                callable(subclass.set_server) 
                or NotImplemented)  


    def set_server(self): 
        """
            Define a  method to set a server for the api
        """
        raise NotImplementedError

    def set_service(self, service : IService, name : str):
        """Define a  method to set a service"""
        raise NotImplementedError



    @abc.abstractmethod
    def start_service(self):
        """Define a  method to start a service"""
        raise NotImplementedError

    @abc.abstractmethod
    def stop_service(self):
        """Define a  method to start a service"""
        raise NotImplementedError

    
    

    


