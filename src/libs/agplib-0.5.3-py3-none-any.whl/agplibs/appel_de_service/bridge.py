from agplibs.clients.sac import SugarApiClient
from agplibs.clients.fac import FonivaApiClient
from agplibs.logics.lead import LeadModel
import xml.etree.ElementTree as ET
import json
from pprint import pprint
from datetime import date, datetime

from  agplibs.utils.sugar import  Contact, TimeHelper
from  agplibs.utils.models import  ContactModel
from agplibs.logics.tag import Tagger, Tag
from agplibs.utils.foniva import Campaign
from agplibs.logics.lead import LeadMaper


class LeadMaper(LeadMaper):

    def __init__(self, sac : SugarApiClient, fac : FonivaApiClient):
        super().__init__(sac, fac)



    def create_transaction(self, name, description, id, payload=None):

        _payload = {
            "name" : name,
            "description" : description,
            "duration_hours": 0,
            "duration_minutes": 30,
            "date_start": f"{TimeHelper.format(datetime.now(), False)}-04:00",
            "parent_id": id,
            "parent_type": "Contacts",
            "team_name": [
                {
                    "id": "1",
                    "name": "Global",
                    "name_2": "",
                    "primary": "true"
                }
            ]
        }



        if(payload is not None):
            _payload.update(payload)


        return self.__sac.post("Calls", 
        payload=json.dumps(_payload))


    def integration_to_sugar(self, lead, fields=["id"]):

        status, contact = self.get_contact(lead, fields)

        if(status == LeadModel.Status.NOUVEAU_LEAD):
            print('CREATE Sugar') 
            
            contact = self.map_lead_to_sugar_contact(lead)
            contact.set_fields({
                "statut_client_c" : "Prospect"
            })

            contact = Contact.create_contact_sugar(self.__sac, contact.model_to_dict())
            Tagger.tag_source(self.__sac, contact["id"], source_principale_c = Tag.SourcePrincipale.COLLECTE_WEB, source_secondaire_c = Tag.SourceSecondaire.COLLECTE_WEB)
       
        
        return status, contact
